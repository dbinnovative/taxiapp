<?php
class Start_Error_Authentication extends Start_Error
{
  public static $TYPE = "authentication";
}
