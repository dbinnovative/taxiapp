<?php
class Start_Error_Processing extends Start_Error
{
  public static $TYPE = "processing";
}
