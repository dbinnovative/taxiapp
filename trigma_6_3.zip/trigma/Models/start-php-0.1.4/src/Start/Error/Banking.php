<?php
class Start_Error_Banking extends Start_Error
{
  public static $TYPE = "banking";
}
