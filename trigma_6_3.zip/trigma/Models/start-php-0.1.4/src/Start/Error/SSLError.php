<?php
class Start_Error_SSLError extends Exception
{
}
