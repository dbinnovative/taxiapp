<?php

class Services_Twilio_Rest_ShortCode
    extends Services_Twilio_InstanceResource
{
}
