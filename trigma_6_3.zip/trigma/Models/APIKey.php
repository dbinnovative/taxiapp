<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of APIKey
 *
 * @author admin@3embed
 */
class APIKey {
    //put your code here
}

?>
