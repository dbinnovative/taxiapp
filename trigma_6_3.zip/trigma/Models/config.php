<?php

/*
 * App specific details
 */

define("APP_NAME", ""); // Will be used for all push notifications, mails, invoices and any other places where app name is needed to display
define("APP_DISTANCE_METERS", "1609.34"); // miles, for KM, 1000
define("APP_DISTANCE_METRIC", "Miles"); // String, Miles / KM
define("APP_SERVER_HOST", "http://52.37.134.30/trigma/");
define("APP_PIC_HOST", "http://52.37.134.30/trigma/pics/");
define("APP_PUBNUB_CHANNEL", "trigma_channel");
define("APP_DRIVER_INACTIVATE_TIME", 300); // seconds for the driver to get inactivated, when there is no update of location from driver application
define("CURRENCY_SYMBOLE", "$");
define('currency', '$');

define('facebookLink', 'http://www.facebook.com');
define('twitterLink', 'http://www.twitter.com');
define('LogoURL', '');


define('MINIMUM_FROUD_BOOKING_ALLOW', 2);

define('AcceptenceRadiou', 200);

define('ServiceFee', 1.25);

define("MAX_AMOUNT_DRIVER_CAN_GET_FROM_CUSTOMER", 50);

define("REFERRAL_CODE_EXPIRY_MONTHS", 120); // number of months a user can be able to share his referral code and get promo codes for each signup

define("Ios_ClientmapKey", "");  // map key for ios pessanger app  
define("And_ClientmapKey", 5);  // map key  for android passenger app

define("And_ClientPlaceKey", 5);  // map key  for android passenger app
define("Ios_ClientPlaceKey", "");  // map key  for android passenger app


define("Ios_MastermapKey", 5);  // map key  for ios driver
define("And_MastermapKey", 5);  // map key  for  android  driver

define("presenseChn", "presenceChn_trigma_channel");

define("stipeKeyForApp", ""); // client stripe key 






define('customerRadius', 50);
//if miles 3959 
// KM 6371
define('customerRadiusUnit', 6371);





define("ALLOW_DRIVER_UPTO", 5);

define("ALLOW_PASSANGER_SIGNUP", 10);

define("PROMOCODE_CODE_EXPIRY_MONTHS", 30); // number of days a user can be able to use his promo code sent via email

define("APP_DRIVER_INACTIVATE_TIME", 900);
/*
 * Payment related things
 */
/*
 * ENABLED -    Will charge the user 2.9 percent + 30 cents extra from the card, while doing the transaction
 *              These are the fees that stripe will take from the transaction amount
 *              If you want to take these charges in the app commission itself leave it DISABLED, if you want to take from the user make it ENABLED
 * DISABLED -   DISABLE the extra charge levied on customer for the card transaction 
 */
define("PAYMENT_CC_FEES", "DISABLED");

/*
 * APP Commission in percentage
 * This is the percentage of amount that you take in every booking
 * The driver earnings are calculated according to this 
 * eg: Total amount = 100.00 Units
 *     App Comm = 10.00 (10% this case)
 *     PG Comm = 2.93 (2.9% + 30 Cents) - STRIPE / BRAINTREE (Only for card payments)
 *     Driver earnings = 87.07 (Card transaction)
 *                       90.00 (Cash transaction)
 */

define("PAYMENT_APP_COMMISSION", 10);

/*
 *  CURRENCY to perform transactions, codes present in the below link are supported
 *  https://support.stripe.com/questions/which-currencies-does-stripe-support
 */

define("PAYMENT_BASE_CURRENCY", "USD");

/*
 * -----------------------------------------------------------------------------
 */
/*
 * Android push api keys
 */

define("ANDROID_DRIVER_PUSH_KEY", "");
define("ANDROID_PASSENGER_PUSH_KEY", ""); //"AIzaSyAbWSsWT5aNJU0QfZopMXf-X56Y6DZNxmc");



define("IOS_DRIVER_PUSH_KEY", "");
define("IOS_PASSENGER_PUSH_KEY", "");

/*
 * -----------------------------------------------------------------------------
 */
/*
 * IOS push cert absolute paths or aws keys
 */

/*
 *  The type of push that should be used in the whole application
 *  Values cab be one of the following
 *  APPLE - (Less efficient) Uses apple native push using pem and password
 *  AMAZON - (More efficient) Uses amazon aws SNS push service, you must have applications created in aws SNS service, for help: https://aws.amazon.com/sns/
 *  PUSHWOOSH - (More efficient) Uses Third party service called pushwoosh for sending push notifications

 *  PUSH ENVIRONMENT
 *  sandbox - Development or debug mode
 *  production - Distribution or production or live mode
 */

define("IOS_PUSH_TYPE", "AMAZON"); //APN_PUSH");//

define("IOS_PUSH_ENVIRONMENT", "production");

/*
 *  IF AMAZON is given in the above constant please fill the below details, else remain as is.
 */

/*
 * --------------------------------------------
 *  These details you will get to see if you create applications in the aws sns panel, application arn is a unique string for each application
 */


define("IOS_PUSH_FOR", "APNS_SANDBOX"); //APN_PUSH");//

if (IOS_PUSH_FOR == "APNS_SANDBOX"){
    define("AMAZON_DRIVER_APPLICATION_ARN", ""); // 
    define("AMAZON_PASSENGER_APPLICATION_ARN", ""); // 
}
else{
    define("AMAZON_DRIVER_APPLICATION_ARN", ""); // 
    define("AMAZON_PASSENGER_APPLICATION_ARN", ""); // 
}


/*
 *  AWS access key, secret and region. For help: http://docs.aws.amazon.com/general/latest/gr/aws-security-credentials.html
 *  These keys can be for root user or a "I AM" user, who must have given access to sns service
 *  Region is the one which you created the applications. For help: http://docs.aws.amazon.com/general/latest/gr/rande.html  
 */

define("AMAZON_AWS_SNS_REGION", "us-east-1");
//Access Key ID:
//AKIAIXZQZBT7DIUZODYQ
//Secret Access Key:
//h+Q30bI0naT12pjRGdEwWIhuFJCLRB4kaEZxazsW

define("AMAZON_AWS_ACCESS_KEY", "");
define("AMAZON_AWS_AUTH_SECRET", "");

/*
 * --------------------------------------
 *  iOS push certificate path and password for driver and passenger, leave password empty if not given while creating the pem certificate
 */
define("IOS_DRIVER_PEM_PATH", "");
define("IOS_DRIVER_PEM_PASS", "");

define("IOS_PASSENGER_PEM_PATH", "");
define("IOS_PASSENGER_PEM_PASS", "");


/* For development certificate use --> ssl://gateway.sandbox.push.apple.com:2195 
 * For distribution / production certificate use --> ssl://gateway.push.apple.com:2195
 */
define("IOS_APPLE_PUSH_SERVER", "ssl://gateway.push.apple.com:2195");

/*
 * -----------------------------------------------------------------------------
 */
/*
 * Mysql specific details
 */
define("MYSQL_HOST", "localhost"); // eg: localhost / xxx.xxx.xxx.xxx
define("MYSQL_USER", "root"); // eg: admin_user
define("MYSQL_PASS", "GVFAP777$$!"); // eg: 
define("MYSQL_DB", "db_taxiappNew"); // eg: taxi_db

/*
 * Mongodb specific details
 */
define("MONGODB_HOST", "localhost"); // eg: localhost / xxx.xxx.xxx.xxx
define("MONGODB_USER", "trigmaUser"); // eg: admin_user
define("MONGODB_PASS", "3EmbedUser@"); // eg: BrBW5M99Xh!g^D@v
define("MONGODB_DB", "db_taxiappNew"); // eg: taxi_db
define("MONGODB_PORT", "27017"); // eg: 27017
/*
 * Mandrill api key
 *  Login/signup to the mandrill account at http://mandrillapp.com/
 *  Move on to settings, create an api key, paste it below here.
 *  yay, its that easy
 * Email id from which the user will see mails from.
 * Domain from which user will see the email from.  
 */


define("MAIL_API_KEY", "");
define("MAIL_API_KEY_URL", "");

define("MANDRILL_FROM_NAME", ""); // eg: Support
define("MANDRILL_FROM_EMAIL", ""); // eg: info@domain.com
define("MANDRILL_FROM_EMAIL_BOOKINGS", ""); // eg: info@domain.com
define("MANDRILL_FROM_WEBSITE", ""); // eg: www.domain.com


/*
 *  Pubnub account keys, publish and subscribe keys
 */

define("PUBNUB_PUBLISH_KEY", "pub-c-5e8b4cc1-8dff-4d09-9581-ef14524d8423");
define("PUBNUB_SUBSCRIBE_KEY", "sub-c-e26582be-f4da-11e6-9c98-02ee2ddab7fe");




/*
 *  Stripe api secret key
 *  If test secret key is used then the app must use the test publish key and same for live keys
 *  If you want to change the keys, you must remove all the stripe ids from slave table of mysql db (Old users will not have their cards, will have to add new cards)
 */

define("STRIPE_API_SECRET_KEY", "");


define("ACCOUNT_SID", ""); // eg: sk_test_xxxxxxxxxxxxxxxxxxx
define("AUTH_TOKEN", ""); // eg: sk_test_xxxxxxxxxxxxxxxxxxx
define("ACCOUNT_NUMBER", ""); // eg: sk_test_xxxxxxxxxxxxxxxxxxx



define('pgComission', 0.03);
define('InvoiceTwoDegit', "AR");



//define("ZDAPIKEY", "cnFiUQ4EaHSwC3tsZsv8x7ViRfAhX7FQWKwDU66O");
//define("ZDUSER", "3embedsoft@gmail.com");
//define("ZDURL", "https://3embedsoft.zendesk.com/api/v2");


