<?php

require_once 'ConDBServices.php';

class campaign {

    private $mongo;
    private $db;
    public $appointmnetTableName = "appointments";

    public function __construct() {
        $this->db = new ConDB();
        $this->mongo = $this->db->mongo;
    }

    /*
     * ent_latitude
     * ent_longitude
     * user_id
     * user_email
     * ent_referral_code
     * 
     */

    public function RewardForNewSignup($args) {

        $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
            'geoNear' => 'Campanians',
            'near' => array(
                (double) $args['ent_latitude'], (double) $args['ent_longitude']
            ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137,
            'query' => array('coupon_type' => 'REFERREL', 'status' => 2))
        );
//        return array('test' => 2);
        $couponsColl = $this->mongo->selectCollection('Campanians');

        $coupon = $this->_createCoupon($couponsColl, "REFERREL");
        $couponsColl->ensureIndex(array("location" => "2d"));

        $insertArray = array(
            'Coupon_code' => $coupon,
            'UserId' => (int) $args['user_id'],
            'UserEmail' => $args['user_email'],
            'UserType' => '2',
            'UserName' => $args['user_name'],
            'Status' => 0,
            'coupon_type' => "USERCAMPAIN",
            "campainId" => "",
            "ParantId" => "",
            "location" => array('latitude' => (double) $args['ent_latitude'], 'longitude' => (double) $args['ent_longitude'])
        );

        if (count($resultArr['results']) <= 0) {
            $couponsColl->insert($insertArray);
            return array('flag' => 1, "msg" => "The Refferrel is not yet started Yet.", 'data' => $insertArray, 'ReferralCode' => $insertArray['Coupon_code']);
        } else {
            $CouponForRefferre = array();
            $CouponForReferred = array();
            $insertArray['Status'] = 1;
            $referralData = $resultArr['results'][0]['obj'];
            $insertArray['campainId'] = (string) $referralData['_id'];

            if ($args['ent_referral_code'] != '') {

                $getParrant = $couponsColl->findOne(array('Coupon_code' => $args['ent_referral_code']));
                $insertArray["ParantId"] = $getParrant['UserId'];
                if ($getParrant['Status'] == 0) {
                    $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
                        'geoNear' => 'Campanians',
                        'near' => array(
                            (double) $args['ent_latitude'], (double) $args['ent_longitude']
                        ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137,
                        'query' => array('coupon_type' => 'REFERREL', 'status' => 2))
                    );


                    if (count($resultArr['results']) > 0) {
                        $referralData = $resultArr['results'][0]['obj'];

//                        $couponsColl->update();
//                        $xridesBenifits = "XridesBenifit" => $XridesBenifit

                        $newdata = array('$set' => array("Status" => 1, 'campainId' => $insertArray['campainId'], 'referred' => array(
                                    'userId' => $args['user_id'],
                                    'counter' => 0,
                                    'amount' => 0,
                                    'status' => 0
                                ))
                        );
                        $couponsColl->update(array("Coupon_code" => $args['ent_referral_code']), $newdata);
                    }
                } else {
                    $newdata = array('$push' => array('referred' => array(
                                'userId' => $args['user_id'],
                                'counter' => 0,
                                'amount' => 0,
                                'status' => 0
                    )));
                    $couponsColl->update(array("Coupon_code" => $args['ent_referral_code']), $newdata);
                }




                if ($referralData['RewardType'] == '1' && $referralData['ReferrelType'] == '1') {
                    $promotionType = 1;
                    if ($referralData['RefferalPromo']['referre'] == '1') {
                        $CouponForRefferre = array(
                            'coupon_type' => "PROMOTION",
                            'PromotionType' => '1',
                            'userId' => $getParrant['UserId'],
                            'userEmail' => $getParrant['UserEmail'],
                            'userName' => $getParrant['UserName'],
                            'status' => 0,
                            'coupon_code' => $this->_createCoupon($couponsColl, "PROMOTION"),
                            'location' => array('latitude' => (double) $args['ent_latitude'], 'longitude' => (double) $args['ent_longitude']),
                            'PromoData' => array(
                                'Amount' => $referralData['RefferalPromo']['amountReferre'],
                                'ZoneSelected' => "0",
                                'ZoneId' => "",
                                'zoneappliedOn' => '0',
                                'PromoappliedOn' => "1",
                                'rewardType' => '1',
                                'rewardTypeExpiryDate' => $referralData['RefferalPromo']['ExpiryDateReferre'],
                                'xrideUnit' => "",
                                'paymentType' => '3',
                                'DiscountType' => $referralData['RefferalPromo']['discountTypeReferre'],
                                'maxDiscount' => $referralData['RefferalPromo']['maxDiscountReferre'],
                                'sartDateNtime' => $referralData['RefferalPromo']['ExpiryDateReferre'],
                                'endTimestamp' => strtotime($referralData['RefferalPromo']['ExpiryDateReferre']),
                            )
                        );
                        $couponsColl->insert($CouponForRefferre);
                    }
                    if ($referralData['RefferalPromo']['referred'] == '1') {
                        $CouponForReferred = array(
                            'coupon_type' => "PROMOTION",
                            'PromotionType' => '1',
                            'userId' => $args['user_id'],
                            'userEmail' => $args['user_email'],
                            'userName' => $args['user_name'],
                            'status' => 0,
                            'campaingType' => "REFERRAL",
                            'coupon_code' => $this->_createCoupon($couponsColl, "PROMOTION"),
                            'location' => array('latitude' => (double) $args['ent_latitude'], 'longitude' => (double) $args['ent_longitude']),
                            'PromoData' => array(
                                'Amount' => $referralData['RefferalPromo']['amountReferred'],
                                'ZoneSelected' => "0",
                                'ZoneId' => "",
                                'zoneappliedOn' => '0',
                                'PromoappliedOn' => "1",
                                'rewardType' => '1',
                                'rewardTypeExpiryDate' => $referralData['RefferalPromo']['ExpiryDateReferred'],
                                'xrideUnit' => "",
                                'paymentType' => '3',
                                'DiscountType' => $referralData['RefferalPromo']['discountTypeReferred'],
                                'maxDiscount' => $referralData['RefferalPromo']['maxDiscountReferred'],
                                'sartDateNtime' => $referralData['RefferalPromo']['ExpiryDateReferred'],
                                'endTimestamp' => strtotime($referralData['RefferalPromo']['ExpiryDateReferred']),
                            )
                        );
                        $couponsColl->insert($CouponForReferred);
                    }
                } else if ($referralData['RewardType'] == '1' && $referralData['ReferrelType'] == '2') {
                    $promotionType = 2;
                    if ($referralData['RefferalWallet']['referre'] == '1') {
                        // insert into wallet
                        $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,CouponCode,exiryDate) values ('" . $getParrant['UserId'] . "',3,'" . round($referralData['RefferalWallet']['amountReferre'], 2) . "',now(),1,'" . $args['ent_referral_code'] . "','" . strtotime($GetReferral['RefferalWallet']['ExpiryDateReferre']) . "')";
                        mysql_query($query, $this->db->conn);
                    }
                    if ($referralData['RefferalWallet']['referred'] == '1') {
                        // inset into wallet
                        $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,CouponCode,exiryDate) values ('" . $args['user_id'] . "',3,'" . round($referralData['RefferalWallet']['amountReferred'], 2) . "',now(),1,'" . $args['ent_referral_code'] . "','" . strtotime($GetReferral['RefferalWallet']['ExpiryDateReferred']) . "')";
                        mysql_query($query, $this->db->conn);
                    }
                } else if ($referralData['ReferrelType'] == '2' && $referralData['RewardType'] == '2') {
                    $promotionType = 2;
                    if ($referralData['xrides']['xrides_ImediateTo'] == '1') {
                        // insert into wallet
                        $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,CouponCode,exiryDate) values ('" . $getParrant['UserId'] . "',3,'" . round($referralData['RefferalWallet']['amountReferre'], 2) . "',now(),1,'" . $args['ent_referral_code'] . "','" . strtotime($GetReferral['RefferalWallet']['ExpiryDateReferre']) . "')";
                        mysql_query($query, $this->db->conn);
                    }
                    if ($referralData['xrides']['xrides_ImediateTo'] == '2') {
                        // inset into wallet
                        $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,CouponCode,exiryDate) values ('" . $args['user_id'] . "',3,'" . round($referralData['RefferalWallet']['amountReferred'], 2) . "',now(),1,'" . $args['ent_referral_code'] . "','" . strtotime($GetReferral['RefferalWallet']['ExpiryDateReferred']) . "')";
                        mysql_query($query, $this->db->conn);
                    }
                } else if ($referralData['ReferrelType'] == '1' && $referralData['RewardType'] == '2') {
                    $promotionType = 1;
                    if ($referralData['xrides']['xrides_ImediateTo'] == '1') {
                        $CouponForRefferre = array(
                            'coupon_type' => "PROMOTION",
                            'PromotionType' => '1',
                            'userId' => $getParrant['UserId'],
                            'userEmail' => $getParrant['UserEmail'],
                            'userName' => $getParrant['UserName'],
                            'status' => 0,
                            'coupon_code' => $this->_createCoupon($couponsColl, "PROMOTION"),
                            'location' => array('latitude' => (double) $args['ent_latitude'], 'longitude' => (double) $args['ent_longitude']),
                            'PromoData' => array(
                                'Amount' => $referralData['RefferalPromo']['amountReferre'],
                                'ZoneSelected' => "0",
                                'ZoneId' => "",
                                'zoneappliedOn' => '0',
                                'PromoappliedOn' => "1",
                                'rewardType' => '1',
                                'rewardTypeExpiryDate' => $referralData['RefferalPromo']['ExpiryDateReferre'],
                                'xrideUnit' => "",
                                'paymentType' => '3',
                                'DiscountType' => $referralData['RefferalPromo']['discountTypeReferre'],
                                'maxDiscount' => $referralData['RefferalPromo']['maxDiscountReferre'],
                                'sartDateNtime' => $referralData['RefferalPromo']['ExpiryDateReferre'],
                                'endTimestamp' => strtotime($referralData['RefferalPromo']['ExpiryDateReferre']),
                            )
                        );
                        $couponsColl->insert($CouponForRefferre);
                    }
                    if ($referralData['xrides']['xrides_ImediateTo'] == '2') {
                        $CouponForReferred = array(
                            'coupon_type' => "PROMOTION",
                            'PromotionType' => '1',
                            'userId' => $args['user_id'],
                            'userEmail' => $args['user_email'],
                            'userName' => $args['user_name'],
                            'status' => 0,
                            'campaingType' => "REFERRAL",
                            'coupon_code' => $this->_createCoupon($couponsColl, "PROMOTION"),
                            'location' => array('latitude' => (double) $args['ent_latitude'], 'longitude' => (double) $args['ent_longitude']),
                            'PromoData' => array(
                                'Amount' => $referralData['RefferalPromo']['amountReferred'],
                                'ZoneSelected' => "0",
                                'ZoneId' => "",
                                'zoneappliedOn' => '0',
                                'PromoappliedOn' => "1",
                                'rewardType' => '1',
                                'rewardTypeExpiryDate' => $referralData['RefferalPromo']['ExpiryDateReferred'],
                                'xrideUnit' => "",
                                'paymentType' => '3',
                                'DiscountType' => $referralData['RefferalPromo']['discountTypeReferred'],
                                'maxDiscount' => $referralData['RefferalPromo']['maxDiscountReferred'],
                                'sartDateNtime' => $referralData['RefferalPromo']['ExpiryDateReferred'],
                                'endTimestamp' => strtotime($referralData['RefferalPromo']['ExpiryDateReferred']),
                            )
                        );
                        $couponsColl->insert($CouponForReferred);
                    }
                }
            }
            $insetedUserData = $couponsColl->insert($insertArray);
        }

        return array('flag' => 0, 'promotionType' => $promotionType, 'parantUser' => $CouponForRefferre, 'CurrentUser' => $CouponForReferred, 'ReferralCode' => $insertArray['Coupon_code']);
    }

    /*
     * response  flag 0 means success and referral code
     * 
     *  #1 In case Refferal is not activated for the city  
     *  
     *   >we'll just generate Referral Code for user  
     *  
     * #2 Promocode or wallet 
     *    > promocode : we'll create promocode for both user
     *      respo :  promotype 1 promo 2 wallet
     *       1) parant user code to use in case promo 
     *       2) currnut user promocode you
     * 
     */

    /*     * ******************* */

    /*
     * ent_latitude
     * ent_longitude
     * 
     */

    public function CheckRefferalForXrides($args) { // when status is 8 we will trigger this service to aknologe
        $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
            'geoNear' => 'Campanians',
            'near' => array(
                (double) $args['ent_latitude'], (double) $args['ent_longitude']
            ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137,
            'query' => array('coupon_type' => 'REFERREL', 'status' => 2))
        );
//        return $resultArr;

        if (count($resultArr['results']) <= 0) {
            return array('flag' => 1, "msg" => "The Refferrel is not yet started Yet.", 'test' => $resultArr);
        } else {
            $referralData = $resultArr['results'][0]['obj'];
            if ($referralData['RewardType'] == "2") {
                if ($referralData['xrides']['xrides_Unit_or_amount'] == $args['PayMentType'] || $referralData['xrides']['xrides_Paytype'] == '3') {
                    return array('flag' => 0, "msg" => "");
                }
            } else {
                return array('flag' => 1, "msg" => "Not Applicable");
            }
        }
    }

    /*
     * ent_latitude
     * ent_longitude
     * user_id
     * user_email
     * ent_referral_code
     * 
     */

    public function triggerRewardForCompletingxrides($args) {
        $couponsColl = $this->mongo->selectCollection('Campanians');
        $result = $couponsColl->findOne(array('UserId' => (int) $args['user_id'], 'coupon_type' => "USERCAMPAIN", "Status" => 1));
        if (count($result) == 0 || $result['campainId'] == "" || $result["ParantId"] == "")
            return array('flag' => 1, "msg" => "The User Is not Capable.");

        $GetReferral = $couponsColl->findOne(array('_id' => new MongoId($result['campainId'])));
        if (!is_array($GetReferral)) {
            return array('flag' => 1, "msg" => "The User Is not Capable.");
        }
        $return = array('flag' => 1);
        $applicable = 0;

        $getData = $couponsColl->aggregate(array('$match' => array('referred.userId' => (int) $args['user_id'], "UserId" => (int) $result["ParantId"])), array('$unwind' => '$referred'), array('$match' => array('referred.userId' => (int) $args['user_id'], 'referred.status' => 1)));
        // here  is status is 1 then return nothing 
        if (!empty($getData['result'])) {
            return array('flag' => 1, "msg" => "prev Occupied");
        }
        //



        $parantData = $couponsColl->findOne(array("UserId" => (int) $result["ParantId"]));
        $appointment = $this->mongo->selectCollection($this->appointmnetTableName);
        if ($GetReferral['xrides']['xrides_Type'] == 1) { // x Rides
            $completeRides = $appointment->find(array('slave_id.slaveId' => (int) $args['user_id'], "PayMentType" => ($args['PayMentType'] == '1' ? '2' : '1'), "status" => array('$in' => [9, 11])));
            if ($completeRides->count() >= $GetReferral['xrides']['xrides_Unit_or_amount'] && ($GetReferral['xrides']['xrides_Paytype'] == $args['PayMentType'] || $GetReferral['xrides']['xrides_Paytype'] == '3')) {
                $applicable = 1;
            } else
                $return = array('flag' => 2, "Xrides_completed" => $completeRides->count(), 'child' => $args['user_id'], "PayMentType" => ($args['PayMentType'] == '1' ? '2' : '1'));
        } else if ($GetReferral['xrides']['xrides_Type'] == 2) { // x amount of rides
            $totalamount = $appointment->aggregate(array('$match' => array('slave_id.slaveId' => (int) $args['user_id'], "PayMentType" => ($args['PayMentType'] == '1' ? '2' : '1'), 'status' => array('$in' => [9, 11]))), array('$unwind' => '$invoice'), array('$group' => array('_id' => null, 'total' => array('$sum' => '$invoice.amount'))));
            if ($totalamount['result'][0]['total'] >= $GetReferral['xrides']['xrides_Unit_or_amount'] && ($GetReferral['xrides']['xrides_Paytype'] == $args['PayMentType'] || $GetReferral['xrides']['xrides_Paytype'] == '3')) {
                $applicable = 1;
            } else
                $return = array('flag' => 2, "Xrides_amount" => $totalamount);
        }



        if ($applicable == 1) {


            if ($GetReferral['ReferrelType'] == '1') {


                if ($GetReferral['xrides']['xrides_ImediateTo'] != '1' && $GetReferral['RefferalPromo']['referre'] == '1' && (strtotime($GetReferral['RefferalPromo']['ExpiryDateReferre']) > time())) {
                    $CouponForRefferre = array(
                        'coupon_type' => "PROMOTION",
                        'PromotionType' => '1',
                        'userId' => $result["ParantId"],
                        'userEmail' => $parantData['UserEmail'],
                        'userName' => $parantData['UserName'],
                        'status' => 1,
                        'TnC' => $GetReferral['TnC'],
                        'coupon_code' => $this->_createCoupon($couponsColl, "PROMOTION"),
                        'location' => array('latitude' => $GetReferral['location']['latitude'], 'longitude' => $GetReferral['location']['longitude']),
                        'PromoData' => array(
                            'Amount' => $GetReferral['RefferalPromo']['amountReferre'],
                            'ZoneSelected' => "0",
                            'ZoneId' => "",
                            'zoneappliedOn' => '0',
                            'PromoappliedOn' => "1",
                            'rewardType' => $GetReferral['ReferrelType'],
                            'rewardTypeExpiryDate' => $GetReferral['RefferalPromo']['ExpiryDateReferre'],
                            'xrideUnit' => $GetReferral['xrides']['xrides_Unit_or_amount'],
                            'paymentType' => $GetReferral['xrides']['xrides_Paytype'],
                            'DiscountType' => $GetReferral['RefferalPromo']['discountTypeReferre'],
                            'maxDiscount' => $GetReferral['RefferalPromo']['maxDiscountReferre'],
                            'sartDateNtime' => $GetReferral['RefferalPromo']['ExpiryDateReferre'],
                            'endTimestamp' => strtotime("+30 days"),
                        )
                    );
                    $couponsColl->insert($CouponForRefferre);
                }
                if ($GetReferral['xrides']['xrides_ImediateTo'] != '2' && $GetReferral['RefferalPromo']['referred'] == '1' && (strtotime($GetReferral['RefferalPromo']['ExpiryDateReferred']) > time())) {

                    $CouponForReferred = array(
                        'coupon_type' => "PROMOTION",
                        'PromotionType' => '1',
                        'userId' => $args['user_id'],
                        'userEmail' => $result['UserEmail'],
                        'userName' => $result['UserName'],
                        'status' => 1,
                        'TnC' => $GetReferral['TnC'],
                        'campaingType' => "REFERRAL",
                        'coupon_code' => $this->_createCoupon($couponsColl, "PROMOTION"),
                        'location' => array('latitude' => $GetReferral['location']['latitude'], 'longitude' => $GetReferral['location']['longitude']),
                        'PromoData' => array(
                            'Amount' => $GetReferral['RefferalPromo']['amountReferred'],
                            'ZoneSelected' => "0",
                            'ZoneId' => "",
                            'zoneappliedOn' => '0',
                            'PromoappliedOn' => "1",
                            'rewardType' => $GetReferral['ReferrelType'],
                            'rewardTypeExpiryDate' => $GetReferral['RefferalPromo']['ExpiryDateReferred'],
                            'xrideUnit' => $GetReferral['xrides']['xrides_Unit_or_amount'],
                            'paymentType' => $GetReferral['xrides']['xrides_Paytype'],
                            'DiscountType' => $GetReferral['RefferalPromo']['discountTypeReferred'],
                            'maxDiscount' => $GetReferral['RefferalPromo']['maxDiscountReferred'],
                            'sartDateNtime' => $GetReferral['RefferalPromo']['ExpiryDateReferred'],
                            'endTimestamp' => strtotime("+30 days"),
                        )
                    );
                    $couponsColl->insert($CouponForReferred);
                }
                $return = array('flag' => 0, 'Type' => 'PROMO', 'parantUser' => $CouponForRefferre['coupon_code'], 'CurrentUser' => $CouponForReferred['coupon_code'], 'referrer' => $CouponForRefferre, 'referred' => $CouponForReferred);
            } else {
                
//                if ($GetReferral['xrides']['xrides_ImediateTo'] != '1' && $GetReferral['RefferalWallet']['referre'] == '1' && strtotime($GetReferral['RefferalWallet']['ExpiryDateReferre']) > time() && ($GetReferral['xrides']['xrides_ImediateTo'] == '0' || $GetReferral['xrides']['xrides_ImediateTo'] != '2')) {
                if ($GetReferral['xrides']['xrides_ImediateTo'] != '1' && $GetReferral['RefferalWallet']['referre'] == '1' && strtotime($GetReferral['RefferalWallet']['ExpiryDateReferre']) > time()) {
                    $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,CouponCode,exiryDate) values ('" . $result["ParantId"] . "',3,'" . round($GetReferral['RefferalWallet']['amountReferre'], 2) . "',now(),1,'" . $args['ent_referral_code'] . "','" . strtotime($GetReferral['RefferalWallet']['ExpiryDateReferre']) . "')";
                    mysql_query($query, $this->db->conn);
                }

//                if ($GetReferral['xrides']['xrides_ImediateTo'] != '2' && $GetReferral['RefferalWallet']['referred'] == '1' && strtotime($GetReferral['RefferalWallet']['ExpiryDateReferred']) > time()&& ($GetReferral['xrides']['xrides_ImediateTo'] == '0' || $GetReferral['xrides']['xrides_ImediateTo'] != '1')) {
                if ($GetReferral['xrides']['xrides_ImediateTo'] != '2' && $GetReferral['RefferalWallet']['referred'] == '1' && strtotime($GetReferral['RefferalWallet']['ExpiryDateReferred']) > time()) {
                    $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,CouponCode,exiryDate) values ('" . $args['user_id'] . "',3,'" . round($GetReferral['RefferalWallet']['amountReferred'], 2) . "',now(),1,'" . $args['ent_referral_code'] . "','" . strtotime($GetReferral['RefferalWallet']['ExpiryDateReferred']) . "')";
                    mysql_query($query, $this->db->conn);
                }
                $return = array('flag' => 0, 'Type' => 'wallet', 'quey' => $query);
            }
            $data = $couponsColl->update(array('UserId' => (int) $result["ParantId"], 'referred.userId' => (int) $args['user_id']), array('$set' => array('referred.$.status' => 1)));
//            return $return;array('update' => $data,'parant' => $result["ParantId"],'cheild' => $args['user_id']);
        }
        return $return;
    }

    /*
     * ent_latitude
     * ent_longitude
     * user_id
     * ent_coupon
     * 
     * ent_from_long
     * ent_from_lat
     * 
     * ent_to_long
     * ent_to_lat
     */

    public function checkCoupons($args) {

        $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
            'geoNear' => 'Campanians',
            'near' => array(
                (double) $args['ent_latitude'], (double) $args['ent_longitude']
            ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137,
            'query' => array('coupon_type' => 'PROMOTION', 'status' => 1, 'coupon_code' => $args['ent_coupon']))
        );
        if (count($resultArr['results']) <= 0) {
            return array('flag' => 1, "msg" => "The promocode is not available.");
        } else {
//            'PromoData.promocode' => $args['ent_coupon']


            $referralData = $resultArr['results'][0]['obj'];
            $referralData['PromoData']['maxUsage'] = (int)$referralData['PromoData']['maxUsage'];
            if($referralData['PromoData']['maxUsage'] != '' && $referralData['PromoData']['maxUsage'] != 0 && $referralData['PromoData']['maxUsage'] <= count($referralData['UsedUser'])){
                return array('flag' => 1, "msg" => "The Coupon Code is not applicable.");
            }

            if ($referralData["campaingType"] == "REFERRAL" && $referralData["userId"] != $args['userId']) {
                return array('flag' => 1, "msg" => "The promocode is not applicable.");
            }

            if ($referralData['PromoData']['ZoneSelected'] == '1') {
                $surg_price = 0;
                if ($referralData['PromoData']['zoneappliedOn'] == '0') {
                    $zonefactor = $this->mongo->selectCollection('couponsZone')->findOne(
                            array("polygons" =>
                                array('$geoIntersects' =>
                                    array('$geometry' =>
                                        array("type" => "Point", "coordinates" => array((double) $args['ent_from_long'], (double) $args['ent_from_lat']))
                                    )
                                )
                            )
                    );

                    if (is_array($zonefactor))
                        $surg_price = 1;
                }
                else if ($referralData['PromoData']['zoneappliedOn'] == '2') {
                    $zonefactor_pickup = $this->mongo->selectCollection('couponsZone')->findOne(
                            array("polygons" =>
                                array('$geoIntersects' =>
                                    array('$geometry' =>
                                        array("type" => "Point", "coordinates" => array((double) $args['ent_to_long'], (double) $args['ent_to_lat']))
                                    )
                                )
                            )
                    );
                    if (is_array($zonefactor_pickup))
                        $surg_price = 1;
                }
                if ($surg_price == 0)
                    return array('flag' => 1, "msg" => "Not belogs to given zone", 'test' => $zonefactor);
            }
            $userdOrNot = $this->multi_in_array($args['userId'], $referralData['UsedUser'], 'userId');

//                if ($userdOrNot == false && !empty($referralData['UsedUser'])) {
//                    return array('flag' => 1, "msg" => "you have used Already.",'test' => $userdOrNot);
//                } else
            if (is_array($userdOrNot)) {
                if ($referralData['PromoData']['PromoappliedOn'] == "1") {
                    return array('flag' => 1, "msg" => "you have used Already.");
                } else if (count($userdOrNot) >= $referralData['PromoData']['xrideUnit']) {
                    return array('flag' => 1, "msg" => "you have used this code " . count($userdOrNot) . ' times.');
                }
            }

            if ($referralData['PromoData']['endTimestamp'] < time())
                return array('flag' => 1, "msg" => "Coupon Code is Expired.");

            return array('flag' => 0, "msg" => "Valide", 'PaymentType' => $referralData['PromoData']['paymentType'], 'count' => $userdOrNot);
        }
    }

    public function checkReferral($args) {
        $couponsColl = $this->mongo->selectCollection('Campanians');
        $data = $couponsColl->findOne(array('Coupon_code' => $args['ent_referral_code']));
        if (is_array($data))
            return array('flag' => 0);
        return array('flag' => 1, 'test' => $args);
    }

    public function multi_in_array($needle, $haystack, $key) {
        $data = array();
        foreach ($haystack as $h) {
            if (array_key_exists($key, $h) && $h[$key] == $needle) {
                $data [] +=1;
            }
        }
        if (count($data) > 0) {
            return $data;
        }
        return false;
    }

    /*
     * ent_latitude
     * ent_longitude
     * user_id
     * ent_coupon
     */

    public function getPromoProfit($args) {
        $cursor = $this->mongo->selectCollection('Campanians');
        $PromoData = $cursor->findOne(array('coupon_type' => 'PROMOTION', 'status' => 1, 'coupon_code' => $args['ent_coupon']));
        if (!is_array($PromoData))
            return array('flag' => 1, 'msg' => 'promo not found');

        $PromoDatacoupns = $PromoData['PromoData'];
        $amount = 0;
        if ($PromoDatacoupns['DiscountType'] == '2') {
            $PromoDatacoupns['Percentage'] = $PromoDatacoupns['Amount'];
            $discount = round(($PromoDatacoupns['Amount'] / 100) * $args['buildAmount']); //  - $PromoDatacoupns['maxDiscount']);
            if ($discount > $PromoDatacoupns['maxDiscount'] && $PromoDatacoupns['maxDiscount'] != "")
                $PromoDatacoupns['Amount'] = $PromoDatacoupns['maxDiscount'];
            else
                $PromoDatacoupns['Amount'] = $discount;
        }

        if ($PromoDatacoupns['rewardType'] == "2") {
            $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,CouponCode,exiryDate) values ('" . $args['UserId'] . "',4,'" . round($PromoDatacoupns['Amount'], 2) . "',now(),1,'" . $args['ent_coupon'] . "','" . $PromoDatacoupns['endTimestamp'] . "')";
            mysql_query($query, $this->db->conn);
        } else if ($PromoDatacoupns['rewardType'] == "1") {
            $amount = $PromoDatacoupns['Amount'];
        }
        $newdata = array('$push' => array('UsedUser' => array(
                    'userId' => $args['UserId'],
                    'bookingId' => $args['bookingId'],
                    'discount' => $PromoDatacoupns['Amount']
        )));
        $cursor->update(array("coupon_code" => $args['ent_coupon']), $newdata);
        return array('flag' => 0, 'Type' => $PromoDatacoupns['rewardType'], 'discount' => $PromoDatacoupns['Amount'], 'promodata' => $PromoDatacoupns);
    }

    protected function _createCoupon($couponsColl, $coupontype) {

        $coupOn = $this->_generateRandomString(7);

        $find = $couponsColl->findOne(array('coupon_code' => (string) $coupOn, 'coupon_type' => $coupontype));

        if (is_array($find) || count($find) > 0) {
            return $this->_createCoupon($couponsColl);
        } else {
            return $coupOn;
        }
    }

    protected function _generateRandomString($length) {

        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';

        $randomString = '';

        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }

        return $randomString;
    }

}
