<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once 'Models/config.php';
require_once 'Models/ConDB.php';
require_once 'Models/MPDF56/mpdf.php';

function getOut() {
    echo "<h1>You are on a wrong page, please get back.</h1>";
    exit();
}

function convertToHoursMins($time, $format = '%d:%d') {
    settype($time, 'integer');
    if ($time < 1) {
        return;
    }
    $hours = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}

if (isset($_REQUEST['apntId'])) {

    $db = new ConDB();

    $apptDet = $db->mongo->selectCollection("appointments")->findOne(array("_id" => (int) $_REQUEST['apntId']));
    $masData = $db->mongo->selectCollection("location")->findOne(array("user" => (int) $apptDet['mas_id']));
    
    $masterData = mysql_fetch_object(mysql_query("select profile_pic from master where mas_id = ".$apptDet['mas_id']."", $db->conn));
    
    if ($apptDet['status'] != '9')
        getOut();

    

    $Invoicedata = $apptDet['invoice'][0];


    $arr = array(
        "routeImg" => $apptDet['routeImg'] . "&size=740x280",
        "amount" => $Invoicedata['amount'],
        "ServiceFee" => $Invoicedata['ServiceFee'],
        "airportFee" => $Invoicedata['airportFee'],
        "name" => $apptDet['slave_id']['SlaveName'],
        "paymentType" => $apptDet['PayMentType'],
        "appointment_dt" => $apptDet['appointment_dt'],
        "pickup_dt" => $apptDet['appointment_dt'], //pickup_dt
        "pickupAdd" => $apptDet['appointment_address'],
        "drop_dt" => $apptDet['drop_dt'],
        "dropAdd" => $apptDet['Drop_address'],
        "driverPic" => APP_PIC_HOST .$masterData->profile_pic,
        "driverName" => $masData['name'],
        "tripDistance" => $Invoicedata['TripDistance'],
        "tripTime" => $Invoicedata['TripTime'],
        "vehicle" => $apptDet['vehicleType']['TypeName'],
        "baseFare" => $Invoicedata['baseFare'],
        "distanceFare" => $Invoicedata['TripDistanceFee'],
        "timeFare" => $Invoicedata['TripTimeFee'],
        "subtotal" => $Invoicedata['amount'],
        "iswallet" => $apptDet['wallet'],
        "walletDeducted" => $Invoicedata['walletDeducted'],
        'discountVal' => $Invoicedata['discountVal'],
        'Code' => $apptDet['code']
    );

    


    $html = '
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
</head>
<body>
    <div style="width:100%!important;min-width:100%;background-color:#d6d6d5;margin:0;padding:0" bgcolor="#d6d6d5">
        <table border="0" cellpadding="0" cellspacing="0" id="m_-7283196950935089445m_162718108060748383bgwrapper" style="width:100%!important;height:100%!important;line-height:100%!important;border-spacing:0;border-collapse:collapse;background-color:#d6d6d5;margin:0;padding:0;border:none" bgcolor="#d6d6d5">
            <tbody>
                <tr>
                    <td align="center" class="m_-7283196950935089445m_162718108060748383vat" style="vertical-align:top" valign="top">
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-wrapperWidth m_-7283196950935089445m_162718108060748383l-bgcolor" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:740px;background-color:#f8f8f9;border:none" bgcolor="#f8f8f9">
                            <tbody>
                                <tr>
                                    <td>
                                        
                                     
                                       
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                            <tbody>
                                                <tr>
                                                    <td align="right">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-bgcolor m_-7283196950935089445m_162718108060748383l-tripInfoWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:740px;background-color:#f8f8f9;border:none" bgcolor="#f8f8f9">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383tripInnerWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:610px;border:none">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center">
                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-innerWrapperWidth" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style="padding-right:15px;padding-left:15px">
                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383rideSummary" style="padding-top:20px;padding-bottom:30px">
                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383totalPrice m_-7283196950935089445m_162718108060748383topPrice m_-7283196950935089445m_162718108060748383tal m_-7283196950935089445m_162718108060748383black" style="font-size:32px;line-height:40px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;text-align:left;padding-bottom:10px" align="left"> ' . CURRENCY_SYMBOLE . ' ' . round((float) ($arr['amount'] - $arr['discountVal'] - $arr['walletDeducted']), 2) . '</td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383rideInfo m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383topGreetingName" style="font-size:14px;line-height:20px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;text-align:left;color:#898989;padding-bottom:10px" align="left">Thanks for choosing ' . APP_NAME . ', ' . $arr['name'] . '</td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383rideInfo m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:20px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;text-align:left;color:#898989" align="left">' . date('F d,Y', strtotime($arr['appointment_dt'])) . '</td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>
                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td height="1" class="m_-7283196950935089445m_162718108060748383tronhr" style="background-color:#bfbfbf;font-size:0px;line-height:0px" bgcolor="#bfbfbf">
                                                                                                                        <img src="https://ci6.googleusercontent.com/proxy/bjlmwp1lfIp2fevkoEO9P7LRLJDB3htzJ41P3i-rSE5ZwtA6fw0XQ__C7XIfeKMxLCjsuN8uGnjTZ77lPg_2Q3X-nIE1drc87j_Mf3u2_Iy1exK-tg=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/no_collapse.png" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                            <tbody>
                                                <tr>
                                                    <td align="right">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-bgcolor m_-7283196950935089445m_162718108060748383l-tripInfoWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:740px;background-color:#f8f8f9;border:none" bgcolor="#f8f8f9">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383tripInnerWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:610px;border:none">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center">
                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-innerWrapperWidth" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td class="m_-7283196950935089445m_162718108060748383addressSummary" style="padding:40px 15px">
                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" id="m_-7283196950935089445m_162718108060748383normalABlock" style="display:table;border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td>
                                                                                                                        <table cellpadding="0" cellspacing="0" border="0" align="left" width="98%" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td width="5" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots" style="font-size:1;line-height:1">
                                                                                                                                        <img src="https://ci3.googleusercontent.com/proxy/z7CISSfuy3G8tWyE76ENuFiB9L5PnnQNPrgcX0tGQ1z5E8mAWvkPpYCOckkQ7e5PousEwltmZOi1z4026ESwyWJTUXDBH-7PYnMAjmSVPYkztT1U=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/green-left.png" width="5" height="18" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                    </td>
                                                                                                                                    <td width="2" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots m_-7283196950935089445m_162718108060748383addressLine" style="font-size:1;line-height:1;background-color:#cdcdd3" bgcolor="#cdcdd3">
                                                                                                                                        <img src="https://ci5.googleusercontent.com/proxy/nJfedRekVzoWWDNT8qkG9y3k3b8hINaEsXfKQwScs9HwZRuP1ddzsl_qqZJrGbToUx-Jag5FImMICtRLq4Zmy7S6SZq1_c4E9As2P2BrteCxVNf1QJk=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/green-middle.png" width="2" height="18" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                    </td>
                                                                                                                                    <td width="5" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots" style="font-size:1;line-height:1">
                                                                                                                                        <img src="https://ci5.googleusercontent.com/proxy/VTd9gqQdWzqLHSmEogRzBuqRcSabFlyEw9Sn2OHpvrYHiNVTZWvzQ06y3960fETlu_2Th6myPRWOZxmkDsACF0c_3W8EKt4QBpDX4j2IcVO9GFa3EQ=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/green-right.png" width="5" height="18" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                    </td>
                                                                                                                                    <td width="10" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots" style="font-size:1;line-height:1"></td>
                                                                                                                                    <td valign="top" class="m_-7283196950935089445m_162718108060748383address m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383vam m_-7283196950935089445m_162718108060748383firstAddress m_-7283196950935089445m_162718108060748383tal" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;text-align:left;vertical-align:middle;padding-bottom:20px" align="left">
                                                                                                                                        <span class="m_-7283196950935089445m_162718108060748383rideTime m_-7283196950935089445m_162718108060748383black" style="font-size:16px;line-height:24px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000"> 
                                                                                                                                            <span class="aBn" data-term="goog_1466874600" tabindex="0">
                                                                                                                                                <span class="aQJ">' . date('h:i A', strtotime($arr['pickup_dt'])) . '</span>
                                                                                                                                            </span> | 
                                                                                                                                        </span> ' . $arr['pickupAdd'] . '
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td width="5" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots" style="font-size:1;line-height:1">
                                                                                                                                        <img src="https://ci4.googleusercontent.com/proxy/2rQ9r5m_CziatUMU7jQn46xOg6yfuHp7ZKbybsY2OO0SfyDbUQNQXH6-Y7MHdxdgzwucKy4iP7V8bw-N9RpAAdFgmOQ75WSpmVZc1Mg7L0uX8A=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/red-left.png" width="5" height="18" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                    </td>
                                                                                                                                    <td width="2" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots" style="font-size:1;line-height:1">
                                                                                                                                        <img src="https://ci3.googleusercontent.com/proxy/EOfXPLooq0PKJX8Bv7qD-dcC0AhaTqH8-_f52GcmqyLcU3lq-eqUlUt1OS2CUSXqbedHD7dMPoSc0vTA6td1pYD80senD4hO1xY-Jm6QhHbKI7BV=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/red-middle.png" width="2" height="18" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                    </td>
                                                                                                                                    <td width="5" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots" style="font-size:1;line-height:1">
                                                                                                                                        <img src="https://ci6.googleusercontent.com/proxy/InPQjp4YwUxjDkWR9JTbh8gTuE6ancYHDaRjxclAqzRQct3ShSKDNDfMWh6NA3HHmnMSJOIiwMqECAKAO6BiUffpxP6A-AD0cKGVw5YkVESl4IM=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/red-right.png" width="5" height="18" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                    </td>
                                                                                                                                    <td width="10" valign="top" class="m_-7283196950935089445m_162718108060748383addressDots" style="font-size:1;line-height:1"></td>
                                                                                                                                    <td valign="top" class="m_-7283196950935089445m_162718108060748383address m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383vam m_-7283196950935089445m_162718108060748383tal" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;text-align:left;vertical-align:middle" align="left">
                                                                                                                                        <span class="m_-7283196950935089445m_162718108060748383rideTime m_-7283196950935089445m_162718108060748383black m_-7283196950935089445m_162718108060748383vam" style="font-size:16px;line-height:24px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;vertical-align:middle"> 
                                                                                                                                            <span class="aBn" data-term="goog_1466874601" tabindex="0">
                                                                                                                                                <span class="aQJ">' . date('h:i A', strtotime($arr['drop_dt'])) . '</span>
                                                                                                                                            </span> | 
                                                                                                                                        </span> ' . $arr['dropAdd'] . '
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                            <tbody>
                                                <tr>
                                                    <td align="right">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-bgcolor m_-7283196950935089445m_162718108060748383l-tripInfoWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:740px;background-color:#f8f8f9;border:none" bgcolor="#f8f8f9">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383tripInnerWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:610px;border:none">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center">
                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-innerWrapperWidth" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td style="padding-right:15px;padding-left:15px">
                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383fareHr" style="padding-bottom:30px">
                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td height="1" class="m_-7283196950935089445m_162718108060748383tronhr" style="background-color:#bfbfbf;font-size:0px;line-height:0px" bgcolor="#bfbfbf"><img src="https://ci6.googleusercontent.com/proxy/bjlmwp1lfIp2fevkoEO9P7LRLJDB3htzJ41P3i-rSE5ZwtA6fw0XQ__C7XIfeKMxLCjsuN8uGnjTZ77lPg_2Q3X-nIE1drc87j_Mf3u2_Iy1exK-tg=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/no_collapse.png" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>
                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td>
                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="left" class="m_-7283196950935089445m_162718108060748383driverWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:520px;border:none">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding-top:40px;padding-bottom:20px">
                                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="left" class="m_-7283196950935089445m_162718108060748383dPWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:170px;border:none">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383driverPictureWrapper" align="left" style="padding-bottom:20px">
                                                                                                                                                        <table class="m_-7283196950935089445m_162718108060748383driverPicture" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:135px;border:none">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td align="left">
                                                                                                                                                                        <img src="' . $arr['driverPic'] . '"  onerror=this.src="'.APP_PIC_HOST.'user.jpg" width="66" height="66" alt="" class="m_-7283196950935089445m_162718108060748383driverImage CToWUd" style="outline:none;text-decoration:none;display:block;border-radius:40px;border:3px solid #f1f1f1">
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                        <table class="m_-7283196950935089445m_162718108060748383driverInfo" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:275px;border:none">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383driverText m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383tal" style="font-size:16px;line-height:24px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;text-align:left" align="left">
                                                                                                                                                        You rode with ' . $arr['driverName'] . '
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td align="left">
                                                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383tripTable" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:240px;border:none">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td height="50" align="center">
                                                                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383tripSubContainer" style="border-spacing:0;border-collapse:collapse;width:100%;min-width:70px;border:none">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td align="center" class="m_-7283196950935089445m_162718108060748383tripInfo m_-7283196950935089445m_162718108060748383tal" style="font-size:14px;line-height:20px;font-family:\'ClanPro-News\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;text-align:left">
                                                                                                                                                                                        ' . $arr['tripDistance'] . ' 
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td align="center" class="m_-7283196950935089445m_162718108060748383tripInfoDescription m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383tal" style="font-size:12px;line-height:18px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;text-align:left"> 
                                                                                                                                                                                        ' . ((APP_DISTANCE_METRIC == 'KM') ? "Kilometer" : "Miles") . ' 
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                    </td>
                                                                                                                                                                    <td width="2" class="m_-7283196950935089445m_162718108060748383vertLine" style="background-color:#e6e6e9" bgcolor="#e6e6e9"></td>
                                                                                                                                                                    <td align="center">
                                                                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383tripSubContainer" style="border-spacing:0;border-collapse:collapse;width:100%;min-width:70px;border:none">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td align="left" class="m_-7283196950935089445m_162718108060748383tripInfo m_-7283196950935089445m_162718108060748383tal m_-7283196950935089445m_162718108060748383tripInfoText" style="font-size:14px;line-height:20px;font-family:\'ClanPro-News\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;padding-right:15px;padding-left:15px;text-align:left">
                                                                                                                                                                                        <span class="aBn" data-term="goog_1466874602" tabindex="0" style="display: block;width: 90px;">
                                                                                                                                                                                            <span class="aQJ">' . $arr['tripTime'] . ' Minutes</span>
                                                                                                                                                                                        </span>
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td align="left" class="m_-7283196950935089445m_162718108060748383tripInfoDescription m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383tal m_-7283196950935089445m_162718108060748383tripInfoText" style="font-size:12px;line-height:18px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-right:15px;padding-left:15px;text-align:left">
                                                                                                                                                                                        Trip time 
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                    </td>
                                                                                                                                                                    <td width="2" class="m_-7283196950935089445m_162718108060748383vertLine" style="background-color:#e6e6e9" bgcolor="#e6e6e9"></td>
                                                                                                                                                                    <td align="center">
                                                                                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383tripSubContainer" style="border-spacing:0;border-collapse:collapse;width:100%;min-width:70px;border:none">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td align="left" class="m_-7283196950935089445m_162718108060748383tripInfo m_-7283196950935089445m_162718108060748383tal m_-7283196950935089445m_162718108060748383tripInfoText" style="font-size:14px;line-height:20px;font-family:\'ClanPro-News\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;padding-right:15px;padding-left:15px;text-align:left">
                                                                                                                                                                                        ' . $arr['vehicle'] . '
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td align="center" class="m_-7283196950935089445m_162718108060748383tripInfoDescription m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383tal m_-7283196950935089445m_162718108060748383tripInfoText" style="font-size:11px;line-height:18px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-right:15px;padding-left:15px;text-align:left">
                                                                                                                                                                                        Vehicle 
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                            <tbody>
                                                <tr>
                                                    <td align="right">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383fareWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:740px;background-color:#ffffff;border:none" bgcolor="#FFFFFF">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383fareInnerWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:610px;border:none">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center">
                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-innerWrapperWidth" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td class="m_-7283196950935089445m_162718108060748383l-fareTop" style="padding-right:15px;padding-left:15px;padding-top:25px">
                                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" id="m_-7283196950935089445m_162718108060748383textMessage" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td class="m_-7283196950935089445m_162718108060748383textMessageTable" style="padding-bottom:25px">
                                                                                                                        <div align="left">
                                                                                                                            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383messageIconWrapper" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:120px;border:none">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td width="100"><img src="https://ci5.googleusercontent.com/proxy/b-Dd-xuPdvglDS6Rt3mvcDzHS8gGzeEE8dfaI4RxUva_PE8m1IcpFRFQ596Y7QbjC3hHBYRdDmdLx4nF1rM2_tDQ3GAtsXv6IvzGnUVpcQ0el_7QKgI=s0-d-e1-ft#http://d1a3f4spazzrp4.cloudfront.net/receipt_v2/message_icon.png" width="72" height="71" alt="" style="outline:none;text-decoration:none;display:block" class="CToWUd">
                                                                                                                                        </td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>
                                                                                                                        </div>
                                                                                                                        <div align="left">
                                                                                                                            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383messageBoxWidth" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:450px;border:none">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td class="m_-7283196950935089445m_162718108060748383textMessage m_-7283196950935089445m_162718108060748383tal" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;text-align:left" align="left"> Fares are inclusive of service tax and all other taxes applicable. Please download the tax invoice from the trip detail page for a full tax breakdown. </td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>
                                                                                                                        </div>
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                            <tbody>
                                                <tr>
                                                    <td align="center">
                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383fareWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:740px;background-color:#ffffff;border:none" bgcolor="#FFFFFF">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center">
                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383fareInnerWrapper" style="border-spacing:0;border-collapse:collapse;width:100%;max-width:610px;border:none">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center">
                                                                                        <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383l-innerWrapperWidth" align="left" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td class="m_-7283196950935089445m_162718108060748383l-fareTop" style="padding-right:15px;padding-left:15px;padding-top:25px">
                                                                                                        <div>
                                                                                                            <input type="checkbox" id="m_-7283196950935089445m_162718108060748383event1" class="m_-7283196950935089445m_162718108060748383hide-input m_-7283196950935089445m_162718108060748383inputDropdown" style="display:none!important;max-height:0px;overflow:hidden">
                                                                                                            
                                                                                                            <div class="m_-7283196950935089445m_162718108060748383eventinfo">
                                                                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                Base Fare 
                                                                                                                            </td>
                                                                                                                            <td align="right" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                ' . CURRENCY_SYMBOLE.' '. $arr['baseFare'] . ' 
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>
                                                                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                Distance Fare
                                                                                                                            </td>
                                                                                                                            <td align="right" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                ' . CURRENCY_SYMBOLE.' '. $arr['distanceFare'] . ' 
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>
                                                                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                Time Fare
                                                                                                                            </td>
                                                                                                                            <td align="right" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                ' . CURRENCY_SYMBOLE.' '. $arr['timeFare'] . ' 
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>
                                                                                                                
                                                                                                                 <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                Service Fare 
                                                                                                                            </td>
                                                                                                                            <td align="right" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383gray" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;padding-bottom:24px">
                                                                                                                                ' . CURRENCY_SYMBOLE.' '. $arr['ServiceFee'] . ' 
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>
                                                                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" id="m_-7283196950935089445m_162718108060748383hr1" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td class="m_-7283196950935089445m_162718108060748383fareHr" style="padding-bottom:30px">
                                                                                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                                    <tbody>
                                                                                                                                        <tr>
                                                                                                                                            <td height="1" class="m_-7283196950935089445m_162718108060748383tronhr" style="background-color:#bfbfbf;font-size:0px;line-height:0px" bgcolor="#bfbfbf"></td>
                                                                                                                                        </tr>
                                                                                                                                    </tbody>
                                                                                                                                </table>
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>
                                                                                                                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" id="m_-7283196950935089445m_162718108060748383subtotalFare" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383black" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;padding-bottom:24px">
                                                                                                                                Subtotal 
                                                                                                                            </td>
                                                                                                                            <td align="right" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383black" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;padding-bottom:24px">
                                                                                                                                 ' . CURRENCY_SYMBOLE . ' ' . round((float) $arr['subtotal'], 2) . '
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>';
    if ($arr['iswallet'] == '1') {
        $html .= '<table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" id="m_-7283196950935089445m_162718108060748383subtotalFare" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383black" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;padding-bottom:24px">
                                                                                                                                Wallet Deducted 
                                                                                                                            </td>
                                                                                                                            <td align="right" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383black" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;padding-bottom:24px">
                                                                                                                                 ' . CURRENCY_SYMBOLE . ' ' . round((float) $arr['walletDeducted'], 2) . '
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>';
    }

    if ($arr['discountVal'] > '0') {
        $html .= '<table width="100%" border="0" cellpadding="0" cellspacing="0" class="m_-7283196950935089445m_162718108060748383function" id="m_-7283196950935089445m_162718108060748383subtotalFare" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                    <tbody>
                                                                                                                        <tr>
                                                                                                                            <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383black" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;padding-bottom:24px">
                                                                                                                                Discount (' . $arr['Code'] . ') 
                                                                                                                            </td>
                                                                                                                            <td align="right" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383fareSpacing m_-7283196950935089445m_162718108060748383black" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;padding-bottom:24px">
                                                                                                                                 ' . CURRENCY_SYMBOLE . ' ' . round((float) $arr['discountVal'], 2) . '
                                                                                                                            </td>
                                                                                                                        </tr>
                                                                                                                    </tbody>
                                                                                                                </table>';
    }

    $html .='</div>
                                                                                                            <table width="100%" border="0" cellpadding="0" cellspacing="0" id="m_-7283196950935089445m_162718108060748383Charged" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                <tbody>
                                                                                                                    <tr>
                                                                                                                        <td align="left" class="m_-7283196950935089445m_162718108060748383chargedText m_-7283196950935089445m_162718108060748383gray" style="font-size:10px;line-height:16px;font-family:\'ClanPro-News\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;text-transform:uppercase;color:#898989">
                                                                                                                            CHARGED
                                                                                                                        </td>
                                                                                                                        <td rowspan="2" align="right" class="m_-7283196950935089445m_162718108060748383totalPrice m_-7283196950935089445m_162718108060748383chargedFare m_-7283196950935089445m_162718108060748383black" style="font-size:32px;line-height:40px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#000000;padding-bottom:30px"> 
                                                                                                                            ' . CURRENCY_SYMBOLE . ' ' . round((float) ($arr['amount'] - $arr['discountVal'] - $arr['walletDeducted']), 2) . '
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td align="left" class="m_-7283196950935089445m_162718108060748383fareText m_-7283196950935089445m_162718108060748383chargedFare m_-7283196950935089445m_162718108060748383gray m_-7283196950935089445m_162718108060748383vat" style="font-size:14px;line-height:22px;font-family:\'ClanPro-Book\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;color:#898989;vertical-align:top;padding-bottom:30px" valign="top">
                                                                                                                            <span align="left" class="m_-7283196950935089445m_162718108060748383creditCardImage" style="display:inline-block;width:20px;vertical-align:middle;padding-right:5px">
                                                                                                                                <img id="m_-7283196950935089445m_162718108060748383cash_icon" src="' . APP_SERVER_HOST . '/images/cash.png" class="m_-7283196950935089445m_162718108060748383card-image CToWUd" width="auto" style="outline:none;text-decoration:none;display:block;max-width:100%">
                                                                                                                            </span> 
                                                                                                                            <span class="m_-7283196950935089445m_162718108060748383ccNumbers" style="word-break:keep-all">
                                                                                                                                ' . (($arr['paymentType'] == 2) ? "Cash" : "Card") . '
                                                                                                                            </span>
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                </tbody>
                                                                                                            </table>
                                                                                                        
                                                                                                            <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                <tbody>
                                                                                                                    <tr>
                                                                                                                        <td class="m_-7283196950935089445m_162718108060748383fareDisclaimer m_-7283196950935089445m_162718108060748383tal" style="font-size:10px;line-height:16px;font-family:\'ClanPro-News\',\'HelveticaNeue-Light\',\'Helvetica Neue Light\',Helvetica,Arial,sans-serif;text-align:left" align="left">
                                                                                                                            Issued on behalf of ' . $arr['driverName'] . '
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                </tbody>
                                                                                                            </table>
                                                                                                            <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-spacing:0;border-collapse:collapse;width:100%;border:none">
                                                                                                                <tbody>
                                                                                                                    <tr>
                                                                                                                        <td class="m_-7283196950935089445m_162718108060748383tripReference" style="line-height:1px;font-size:1px;color:#ffffff">xid2160e407-e187-425b-a99d-6d7
                                                                                                                            <wbr>a9d08b589</td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td class="m_-7283196950935089445m_162718108060748383zdReceiptIdentifier" style="line-height:1px;font-size:1px;color:#ffffff">pGvlI2ANUbXFfyEOgxta1RMV082993</td>
                                                                                                                    </tr>
                                                                                                                </tbody>
                                                                                                            </table>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="m_-7283196950935089445m_162718108060748383footerSpace" style="padding-top:40px"> </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="m_-7283196950935089445m_162718108060748383layoutSpace" style="padding-top:60px"> </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        
                                        
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <img src="https://ci3.googleusercontent.com/proxy/U4Ndp01qYnQrbghMqwp20OHJ_nt69doSmkuvLvH0dkZ2kMuEuVRNRiGBwhPzQ3AEzvldTyeT8sRv0rj9KwGjchNic3H6_cLh9BbU-IRX7nXSriMbw7mgrMMII0wdSiQnjf5lqDCs_DvSy8NBoTaFY_w6QJlb4DWQD8mOZU0LG-XIwuG2_xN6erLji_he4idDiRsiKlRS4HTB0XQsmnuogo-AbkCgg21qp4HgJZCSAr-tTvor8NPtsH-IxCnCuT7kF5EV5nC5gags0aAEGi2f5W4jAyUnjvTCNeTBHHjFD4SqphoUpUO_ZkxYQLO5Wu0o4g2Cx7RBzMfFFaoe4V9auXPzpK9mrPOMI0rSmpGQzfFiKwGj14d6rwhIMFV_k8-UFFHVLMsLAt1ynAobX99csRvCiTa0AtvoK96hsDxdNjkE1mqabFIs4JodncDB_PixeQGJwyHHq7kVvnbc70q0M0FBPf6EG9cT3mZ44eMRe6ucLd4S1In7RF5I4pzfYSYtc_DqRC_oaEaMDf_4-5hXIw8WuIUWV4H9ELY9i1iF-CXbKgEp7mHIMaZlgiF32YdsVSG3YWBnLmLTzwfN4afxpHBaDqXjz9313_9TJq2wdvBe7bgw5j_-Q2B4aDrnK14r7bsOQrA5g3DcPtOYiFm5KkTo1h-WLtZou97Nxkb8B0AF0Z24UfQ9CdRiN2ONqdBPZqBQf1bFYGi2Kx4R19XnTj7HhCr9da2KGLzRjkJIQYoyR6ljjdSJaadJOPVbo8bg5X-dZHzd_rwM9wrpTwUm65RCJ0Z-oSVagMM7HCrxPWEk1T0xzZRqKclYQORgPfqeo47m66ZI0xtyAeJvRt2yaiUENgQpByAbga_OdzmgWzAS-Y4axiljC9VK85vgDGsCRgpx55ex1BDvLM5DX9YmogU__I7WM0Cyll8YQbYDFWmdnvi2FPBcez7TQDqAKpvoOnrNxwFD8rGwOfiTtHuaH4Tap54Us6kyh1qNeGpjeUbscnUf8BKe0hs1g3oXLnlRMCeeP3UNgqYtfo-4KS4=s0-d-e1-ft#https://email.uber.com/wf/open?upn=BrJVgsn4oGHi2fd-2Fpk3l1ISsFjgJSq9iE5z4J-2FP-2BZY0-2FwPiITMW5xUoKikzNFGPaWM0RdtpmS-2BXVQxy3fENZ5DR-2BoaQFVa7vFIk0iLulTFdPc6F2-2By8TTe8YMnV6OaPUN608sJFtEBUbIFnfd-2BSKaKimr00m1vs6QlPWmIM1f91XNrQgZAZmthEWqgcmlcouZuIGWX4rjYPxw7FJGxLq2Jm3j7vLGDj98K5Li66u1kKrYFwQ7JFU2sV-2BYDGhvKWGWYezRwxKeAbqLu4TOG-2F8PQLofoO0bppeOqlpQMxlWgtbeuajewJj7XzQ6jJKm-2BYCFU7A5-2Btu9X-2FG-2Buigo0Ad-2BVj1TiDFOCIYSkxedONWslVKtHgTy7tB1OaxoQeQm-2FpyksSS9-2F8yeMtG6FEEI-2FH0iP6zQSf6KpA-2BL8XlXKs0c62BdbEUw-2BGBL1vDvgT-2BGCSPAxh-2BhLyEwr-2FhS2Z1JiAAJ31VFeGPOTAL1Mc5xZ-2BcWLr2oOe0CBDOtiC-2BtUDV55LIpCSa-2Fen7N1zYPwwUVyMRPDECbkb-2FJklOGAkYkLafdm4hbyEqQvM9qGCvYuHF21zCjhnMFEPBlSOUman6SDuDo0jIVHUJX2wnPQWYRgm9dMJXXZ6arsnYgxxAqj-2FJJ1tQpDY545pVvPAWqSgl8T1kuw-3D-3D" alt="" width="1" height="1" border="0" style="height:1px!important;width:1px!important;border-width:0!important;margin-top:0!important;margin-bottom:0!important;margin-right:0!important;margin-left:0!important;padding-top:0!important;padding-bottom:0!important;padding-right:0!important;padding-left:0!important" class="CToWUd">
        <div class="yj6qo"></div>
        <div class="adL">
        </div>
    </div>
</body>
</html>';

//    $pdfHtml = $html;
//    $mpdf->WriteHTML($pdfHtml);
//
//    $mpdf->Output();

    echo $html;
} else {
    getOut();
}
?>
