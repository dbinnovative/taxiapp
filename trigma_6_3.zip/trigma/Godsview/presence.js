var baseurl = 'http://52.37.134.30/trigma/Godsview/';
var appurl = 'http://52.37.134.30/trigma/';
var picUrl = appurl + "pics/";
var baseurl1 = 'http://52.37.134.30/trigma/index.php/GodsViewTest';
var serverurl = 'http://52.37.134.30/';
var pubnub_sub_key = 'sub-c-e26582be-f4da-11e6-9c98-02ee2ddab7fe';
var pubnub_chnl = 'godzviewChn';

L.mapbox.accessToken = 'pk.eyJ1IjoiYXNoaXNoM2VtYmVkIiwiYSI6ImNpZzgxajNzejA4cDN2ZmtvbDNiN3R4ancifQ.jMkHGe2fgsgMnclPWrWElQ';//'sk.eyJ1IjoiYXNoaXNoM2VtYmVkIiwiYSI6ImNpd25jcXZyYTAwMTQyc210d2FqZGI5cHYifQ.ybjGWR_zGpVSc8mHGQbR4w';
var map = L.mapbox.map('map', 'mapbox.streets')//'mapbox.light')
        .setView([30.069441, 31.300189], 10);

L.AnimatedMarker = L.Marker.extend({
    _setPos: function (pos) {
        // First call the base method of the Marker itself
        L.Marker.prototype._setPos.call(this, pos);
        // Add a CSS transition to the marker icon and the shadow (and any other objects you've added yourself)
        if (L.DomUtil.TRANSITION) {
            var transSpeed = 2000; // The transition speed is set to 2000ms for dramatic effect, normally I'd set this lower
            if (this._icon) {
                this._icon.style[L.DomUtil.TRANSITION] = ('all ' + transSpeed + 'ms linear');
            }
            if (this._shadow) {
                this._shadow.style[L.DomUtil.TRANSITION] = 'all ' + transSpeed + 'ms linear';
            }
        }
    }
});

var allMarkers = [];
var allDriver = [];
var mapBound = [];

var status = 0;
var appstatus = 0;
var tab_state = 0;
var timestamp = 0;

//$("#four").html(0);
//$("#six").html(0);
//$("#seven").html(0);
//$("#eight").html(0);

$(document).ready(function () {
    $.getJSON(baseurl1 + "/get_all_drivers", function (response) {
        if (response.flg == 0) {
            timestamp = response.time;
            var data = response.data;
            $("#four").html(data.four.length);
            $("#six").html(data.six.length);
            $("#seven").html(data.seven.length);
            $("#eight").html(data.eight.length);
            $.each(data.all, function (ind, val) {
                var adata = {
                    "id": val._id.$id,
                    "name": val.name + " " + val.lname,
                    "proPic": val.image,
                    "bid": '',
                    "email": val.email,
                    "mobile": val.mobile,
                    "user": val.user,
                    "status": val.status,
                    "appstatus": val.apptStatus,
                    "lat": parseFloat(val.location.latitude),
                    "lng": parseFloat(val.location.longitude)
                };
                allDriver[val.user] = adata;
//                allDriver.push(adata);
            });
            show_data(3, 0);
        }
    });
});


function show_data(flg, flg2) {
    var html = '';
    tab_state = flg;
    var bound = [];
    for (var ind in allDriver) {
        var val = allDriver[ind];
//    $.each(allDriver, function (ind, val) {
        var a = 0;
        var colorcode = "";
        var markericong = '';

        switch (val.status) {
            case 3:
                a = 3;
                colorcode = "#78ac2c";
                markericong = baseurl + 'icons/green.png';
                break;
            case 5:
                switch (val.appstatus) {
                    case 6:
                        a = 5;
                        colorcode = '#be0411';
                        markericong = baseurl + 'icons/red.png';
                        break;
                    case 7:
                        a = 5;
                        colorcode = "#4d93c7";
                        markericong = baseurl + 'icons/blue.png';
                        break;
                    case 8:
                        a = 5;
                        colorcode = "#ffd50b";
                        markericong = baseurl + 'icons/yellow.png';
                        break;
                }
                break;
        }
        var adata = val;

        if (a != 0) {
            if (a == flg || flg == 0) {
                html += '<tr id="D_' + adata.user + '">\
                            <td> \n\
                                <div onclick="get_driver_data(' + adata.user + ');popupmodel();">\n\
                                    <p> \n\
                                        <span class="col-xs-height col-middle">\n\
                                            <span class="thumbnail-wrapper d32 circular bg-success"> \n\
                                                <img src="' + adata.proPic + '" onerror="this.src = \'' + appurl + 'pics/user.jpg\'">\n\
                                            </span>\n\
                                            <img width="12" height="12" class="position" src="' + markericong + '"/> \n\
                                        </span>\n\
                                    </p>\n\
                                    <p class="p-l-10 col-xs-height col-middle" style="width: 80%">\n\
                                        <span class="text-master" style="padding-right: 30px;">\n\
                                             ' + adata.name + '&nbsp;(ID:' + adata.user + ')<br/>' + adata.mobile + '<font style="float:right;"></font>\n\
                                        </span>\n\
                                    </p>\n\
                                </div>\n\
                            </td>\n\
                        </tr>';
            }
            if (flg2 == 0) {
                allMarkers['D_' + adata.user] = new L.marker(L.latLng(parseFloat(adata.lat), parseFloat(adata.lng)), {
                    icon: L.mapbox.marker.icon({
                        'marker-color': colorcode
                    }), data: adata
                })
                        .bindPopup('<b>' + adata.name + '</b>')
                        .addTo(map);
            }
        }
//    });
    }
    $(".drivertableNewOne").html(html);
}

/* configure pubnub with the keys to subscribe*/
pubnub = PUBNUB({
    subscribe_key: pubnub_sub_key
});

/* Subscribe to pubnub using channel name
 @envelope will contain the raw message or data along with timestamp
 */
pubnub.subscribe({
    channel: pubnub_chnl,
    presence: function (msg) {
//        console.log("presence ", msg);
//        if (validateEmail(msg.uuid)) {
//            switch (msg.action) {
//                case "join": createMarker(msg.uuid);
//                    break;
//                case "leave": 
//                    removeMarker(msg.uuid);
//                    break;
//                case "timeout": removeMarker(msg.uuid);
//                    break;
//            }
//        }
    },
    message: function (m) {
        console.log(m);
        if (m) {
            if (m.op == "u") {
                var id = m.o2._id;
                var data = m.o.$set;
                if (typeof data != "undefined") {
                    var updated = [];
                    //            $.each(data.all, function (ind, val) {
                    var adata = {
                        "id": id,
                        "bid": '',
                        "status": data.status,
                        "appstatus": data.apptStatus,
                        "location": data.location
                    };
                    updated.push(adata);
                    //            });
                    update_data(updated);
                    update_status_no();
                }
            }
        }
    }
});

function update_status_no() {
    var status_3 = 0;
    var status_6 = 0;
    var status_7 = 0;
    var status_8 = 0;
    for (var ind in allDriver) {
        var val = allDriver[ind];
//    $.each(allDriver, function (ind, val) {
        switch (val.status) {
            case 3:
                status_3++;
                break;
            case 5:
                switch (val.appstatus) {
                    case 6:
                        status_6++;
                        break;
                    case 7:
                        status_7++;
                        break;
                    case 8:
                        status_8++;
                        break;
                }
                break;
        }
//    });
    }
    $("#four").html(status_3);
    $("#six").html(status_6);
    $("#seven").html(status_7);
    $("#eight").html(status_8);
}

//function get_updated(){
//    $.getJSON(baseurl1 + "/get_updated_drivers/"+timestamp, function (response) {
//        if (response.flg == 0) {
//            timestamp = response.time;
//            var data = response.data;
//            $("#four").html(data.four.length);
//            $("#six").html(data.six.length);
//            $("#seven").html(data.seven.length);
//            $("#eight").html(data.eight.length);
//            var updated = [];
//            $.each(data.all, function (ind, val) {
//                var adata = {
//                    "id": val._id.$id,
//                    "name": val.name + " " + val.lname,
//                    "proPic": picUrl + val.image,
//                    "bid": '',
//                    "email": val.email,
//                    "mobile": val.mobile,
//                    "user": val.user,
//                    "status": val.status,
//                    "appstatus": val.apptStatus,
//                    "lat": parseFloat(val.location.latitude),
//                    "lng": parseFloat(val.location.longitude)
//                };
//                updated.push(adata);
//            });
//            update_data(updated);
//        }
//    });
//}

//while loading page after 4 seconds execute function
//setInterval(function () {
//    get_updated();
//}, 7000);

function update_data(updated) {
    $.each(updated, function (index, dr_data) {
        var flag = 0;
        var id = dr_data.id;

        for (var ind in allDriver) {
            var val = allDriver[ind];
//        $.each(allDriver, function (ind, val) {
            if (val.id == id) {
                flag = 1;
                var data = dr_data;
                allDriver[ind].status = (typeof (data.status) != 'undefined') ? data.status : allDriver[ind].status;
                allDriver[ind].appstatus = (typeof (data.appstatus) != 'undefined') ? data.appstatus : allDriver[ind].appstatus;
                allDriver[ind].lat = (typeof (data.location) != 'undefined') ? parseFloat(data.location.latitude) : allDriver[ind].lat;
                allDriver[ind].lng = (typeof (data.location) != 'undefined') ? parseFloat(data.location.longitude) : allDriver[ind].lng;
                var a = 0;
                var colorcode = "";
                var markericong = '';
                val = allDriver[ind];
//                console.log(val);

                switch (val.status) {
                    case 3:
                        a = 3;
                        colorcode = "#78ac2c";
                        markericong = baseurl + 'icons/green.png';
                        break;
                    case 5:
                        switch (val.appstatus) {
                            case 6:
                                a = 5;
                                colorcode = '#be0411';
                                markericong = baseurl + 'icons/red.png';
                                break;
                            case 7:
                                a = 5;
                                colorcode = "#4d93c7";
                                markericong = baseurl + 'icons/blue.png';
                                break;
                            case 8:
                                a = 5;
                                colorcode = "#ffd50b";
                                markericong = baseurl + 'icons/yellow.png';
                                break;
                        }
                        break;
                }
                var adata = allDriver[ind];
                var html = '<td> \n\
                            <div onclick="get_driver_data(' + adata.user + ');popupmodel();">\n\
                                <p> \n\
                                    <span class="col-xs-height col-middle">\n\
                                        <span class="thumbnail-wrapper d32 circular bg-success"> \n\
                                            <img src="' + adata.proPic + '" onerror="this.src = \'' + appurl + 'pics/user.jpg\'">\n\
                                        </span>\n\
                                        <img width="12" height="12" class="position" src="' + markericong + '"/> \n\
                                    </span>\n\
                                </p>\n\
                                <p class="p-l-10 col-xs-height col-middle" style="width: 80%">\n\
                                    <span class="text-master" style="padding-right: 30px;">\n\
                                         ' + adata.name + '&nbsp;(ID:' + adata.user + ')<br/>' + adata.mobile + '<font style="float:right;"></font>\n\
                                    </span>\n\
                                </p>\n\
                            </div>\n\
                        </td>';
                if (a != 0) {
                    if (a == tab_state) {
                        if ($('#D_' + adata.user).length == 0) {
                            $('#D_' + adata.user).remove();
                            $('.drivertableNewOne').append('<tr id="D_' + adata.user + '">' + html + '</tr>');
                        } else {
                            $('#D_' + adata.user).html(html);
                        }
                    } else {
                        $('#D_' + adata.user).remove();
                    }
                    if (adata.status == 4) {
                        if (typeof (allMarkers['D_' + adata.user]) == 'undefined') {

                        } else {
                            map.removeLayer(allMarkers['D_' + adata.user]);
                            delete allMarkers['D_' + adata.user];
                        }
                    } else if ((status == 0 && appstatus == 0) || (adata.status == status && appstatus == 0) || (adata.status == status && adata.appstatus == appstatus)) {
                        if (typeof (allMarkers['D_' + adata.user]) == 'undefined') {
                            allMarkers['D_' + adata.user] = L.marker(L.latLng(parseFloat(adata.lat), parseFloat(adata.lng)), {
                                icon: L.mapbox.marker.icon({
                                    'marker-color': colorcode
                                }), data: adata
                            })
                                    .bindPopup('<b>' + adata.name + '</b>')
                                    .addTo(map);
                        } else {
                            var z = allMarkers['D_' + adata.user].getLatLng();
                            var position = [z.lat, z.lng];
                            var re = L.latLng(parseFloat(adata.lat), parseFloat(adata.lng));
                            re = [re.lat, re.lng];
                            transition(re, position, 'D_' + adata.user, colorcode, adata);
//                            allMarkers['D_' + adata.user].setLatLng(L.latLng(parseFloat(adata.lat), parseFloat(adata.lng)));
//                            allMarkers['D_' + adata.user].setIcon(L.mapbox.marker.icon({
//                                'marker-color': colorcode
//                            }));
                        }
                    } else {
                        if (typeof (allMarkers['D_' + adata.user]) == 'undefined') {

                        } else {
                            map.removeLayer(allMarkers['D_' + adata.user]);
//                            delete allMarkers['D_' + adata.user];
                        }
                    }
                } else {
                    if ($('#D_' + adata.user).length != 0)
                        $('#D_' + adata.user).remove();
                    if (typeof (allMarkers['D_' + adata.user]) != 'undefined') {
                        map.removeLayer(allMarkers['D_' + adata.user]);
                        delete allMarkers['D_' + adata.user];
                    }
                }
            }
//        });
        }
        if (flag == 0) {
            $.getJSON(baseurl1 + "/getSpecificDriver/" + id, function (response) {
                if (response.flg == 0) {
                    var val = response.data;
                    var adata = {
                        "id": val._id.$id,
                        "name": val.name + " " + val.lname,
                        "proPic": val.image,
                        "bid": '',
                        "email": val.email,
                        "mobile": val.mobile,
                        "user": val.user,
                        "status": val.status,
                        "appstatus": val.apptStatus,
                        "lat": parseFloat(val.location.latitude),
                        "lng": parseFloat(val.location.longitude)
                    };
                    allDriver[val.user] = adata;
//                    allDriver.push(adata);
                    var a = 0;
                    var colorcode = "";
                    var markericong = '';
                    switch (adata.status) {
                        case 3:
                            a = 3;
                            colorcode = "#78AC2C";
                            markericong = baseurl + 'icons/green.png';
                            break;
                        case 5:
                            switch (adata.appstatus) {
                                case 6:
                                    a = 5;
                                    colorcode = "#BE0411";
                                    markericong = baseurl + 'icons/red.png';
                                    break;
                                case 7:
                                    a = 5;
                                    colorcode = "#4D93C7";
                                    markericong = baseurl + 'icons/blue.png';
                                    break;
                                case 8:
                                    a = 5;
                                    colorcode = "#FFD50B";
                                    markericong = baseurl + 'icons/yellow.png';
                                    break;
                            }
                            break;
                    }
//                    var adata = val;
                    var html = '<tr id="D_' + adata.user + '">\
                            <td> \n\
                                <div onclick="get_driver_data(' + adata.user + ');popupmodel();">\n\
                                    <p> \n\
                                        <span class="col-xs-height col-middle">\n\
                                            <span class="thumbnail-wrapper d32 circular bg-success"> \n\
                                                <img src="' + adata.proPic + '" onerror="this.src = \'' + appurl + 'pics/user.jpg\'">\n\
                                            </span>\n\
                                            <img width="12" height="12" class="position" src="' + markericong + '"/> \n\
                                        </span>\n\
                                    </p>\n\
                                    <p class="p-l-10 col-xs-height col-middle" style="width: 80%">\n\
                                        <span class="text-master" style="padding-right: 30px;">\n\
                                             ' + adata.name + '&nbsp;(ID:' + adata.user + ')<br/>' + adata.mobile + '<font style="float:right;"></font>\n\
                                        </span>\n\
                                    </p>\n\
                                </div>\n\
                            </td>\n\
                        </tr>';
                    if (a != 0) {
                        if (a == tab_state || tab_state == 0) {
                            $('#D_' + adata.user).remove();
                            $('.drivertableNewOne').append(html);
                        }
                        if ((status == 0 && appstatus == 0) || (adata.status == status && appstatus == 0) || (adata.status == status && adata.appstatus == appstatus)) {
                            allMarkers['D_' + adata.user] = L.marker([parseFloat(adata.lat), parseFloat(adata.lng)], {
                                icon: L.mapbox.marker.icon({
                                    'marker-color': colorcode
                                }), data: adata
                            })
                                    .bindPopup('<b>' + adata.name + '</b>')
                                    .addTo(map);
                        }
                    }
                }
            });
        }
    });
}

function change_state(flg, act) {
    status = flg;
    appstatus = act;

    for (var key in allMarkers)
    {
        var val = allMarkers[key].options;
        if ((flg == 0 && act == 0) || (val.data.status == flg && act == 0) || (val.data.status == flg && val.data.appstatus == act)) {
            allMarkers[key].addTo(map);
        } else {
            map.removeLayer(allMarkers[key]);
        }
    }

}
//getting driver data and appointment data based on driverid 
var popup;
function get_driver_data(id) {
//    clearCircle();
    document.getElementById("driver").innerHTML = "";
    document.getElementById("jobid").innerHTML = "";
    document.getElementById("slave").innerHTML = "";
    document.getElementById("route").innerHTML = "";

    var ddata = '';
    for (var ind in allDriver) {
        var val = allDriver[ind];
//    $.each(allDriver, function (ind, val) {
        if (val.user == id) {
            $("#driver").append('<h5 style="padding-left: 10px;color: white;">Driver Details</h5>');
            $("#driver").append('<h5><p style="margin-bottom: 0px;padding: 10px;">\
                                    Driver Name: &nbsp;' + val.name + '<br>Phone No: &nbsp;' + val.mobile + '\
                                </p></h5>');
            map.setView([parseFloat(val.lat), parseFloat(val.lng)], 18);
            allMarkers['D_' + val.user].openPopup();
            ddata = val;
        }
//    });
    }
    if (ddata.status == 5) {
        $.getJSON(baseurl1 + "/getApptDetails/" + id, function (response) {
            if (response.flg == 0) {
                var data = response.data;
                $("#jobid").append('<h5 style="padding-left: 10px;color: white;">Booking Deatils</h5>');

                var type = 'Card';
                if (data.payment_type == 2) {
                    type = 'Cash';
                }

                $('#jobid').append('<h5 style="padding-left: 10px;color: white;">Booking ID : ' + data._id + '</h5>');
                $("#jobid").append('<p>Booking Type : ' + type + '</p>')
                $("#jobid").append('<h5><p style="padding: 10px;">Customer Name: ' + data.slave_id.SlaveName + '<br>Phone No: ' + data.slave_id.SlavePone + '</p></h5>');
                $("#jobid").append('<hr><p style="margin-bottom: 0px;"><i class="fa fa-map-marker" style="color: green;font-size: 20px;"></i><font size="3" style="padding-left: 20px;">Pickup Address</font><br/>');
                $("#jobid").append('<span class="col-xs-height col-middle" style="padding-left: 30px;">' + data.appointment_address + '</p><hr>');
                $("#jobid").append('<hr><p style="margin-bottom: 0px;"><i class="fa fa-map-marker" style="color: red;font-size: 20px;"></i><font size="3" style="padding-left: 20px;">Drop Address</font><br/>');
                $("#jobid").append('<span class="col-xs-height col-middle" style="padding-left: 30px;">' + ((data.Drop_address == "") ? "----------" : data.Drop_address) + '</p><hr>');
//                }
            }
        });
    }

}
//right side bar ,its displays driver and jobs details
function popupmodel() {
    $('#myModal2').modal('show');
}
//based on click  adding css class to statusbar enroute,pickup,journey,all 
$(".btn").click(function () {
    $(".btn-default").removeClass("raised");
    $(this).addClass("raised");
});
// to resize the map window based on browser or device size
function changeSize() {
    var elem = (document.compatMode === "CSS1Compat") ?
            document.documentElement :
            document.body;
    var height = elem.clientHeight;
    var restSpace = height - 90;
    document.getElementById("body").style.height = height;
    var y = document.getElementsByClassName("restSpace");
    for (var i = 0, len = y.length; i < len; i++)
        y[i].style.height = restSpace + 'px';
    document.getElementById("map").style.height = restSpace + 'px';
}
window.onresize = changeSize;
//marker moving smoothly  
var x;
var numDeltas = 50;
var delay = 60; //milliseconds
var i = 0;
var deltaLat;
var deltaLng;
var pos;
var clr, adt;
function transition(result, position, ids, color, adata1) {
    x = ids;
    i = 0;
    pos = position;
    clr = color;
    adt = adata1;
    deltaLat = (result[0] - position[0]) / numDeltas;
    deltaLng = (result[1] - position[1]) / numDeltas;
    moveMarker();
}

function moveMarker() {
    pos[0] += deltaLat;
    pos[1] += deltaLng;
    var latlng1 = L.latLng(parseFloat(pos[0]), parseFloat(pos[1]));

    if (allMarkers[x]) {
        allMarkers['D_' + adt.user].setLatLng(latlng1);
        allMarkers['D_' + adt.user].setIcon(L.mapbox.marker.icon({
            'marker-color': clr
        }));
    }

    if (i != numDeltas) {
        i++;
        setTimeout(moveMarker, delay);
    }
}