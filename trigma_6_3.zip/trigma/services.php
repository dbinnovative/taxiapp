<?php

error_reporting(1);

ini_set("log_errors", 1);
ini_set("error_log", "/tmp/php-error.log");
$date = date("Y-m-d H:i:s");
error_log("$date: Hello! Running script /services_v2.php" . PHP_EOL);

require_once 'Models/config.php';

require_once 'Models/API.php';
require_once 'Models/ConDBServices.php';
require_once 'Models/getErrorMsg.php';
require_once 'Models/ManageToken.php';
//require_once 'Models/Polyline.php';
require_once 'Models/class.verifyEmail.php';
require_once 'Models/StripeModule.php';
require_once 'Models/mandrill/src/Mandrill.php';
require_once 'Models/InvoiceHtml.php';
require_once 'Models/sendAMail.php';
require_once 'Models/MongoClass.php';

require_once 'Models/class.phpmailer.php';
require_once 'Models/MPDF56/mpdf.php';
require_once 'Models/Pubnub.php';
//require_once 'Models/Payfort.php';
require_once 'Models/twilio-php/Services/Twilio.php';
include 'Models/awsPhar/aws.phar';

require_once 'Models/AwsPush.php';

require_once 'Models/campaign.php';

class MyAPI extends API {

    public $User;
    private $db;
    private $mongo;
    private $ios_cert_path;
    private $ios_cert_pwd;
    private $androidApiKey;
    private $androidUrl = 'http://android.googleapis.com/fcm/send';
    private $default_profile_pic = 'aa_default_profile_pic.gif';
    private $ios_cert_server = "ssl://gateway.push.apple.com:2195";
//    private $ios_cert_server = "ssl://gateway.push.apple.com:2195";
//    private $Payfort;
    public $curr_date_time;
    private $maxChunkSize = 1048576;
    private $reviewsPageSize = 5;
    private $historyPageSize = 5;
    private $cancellationTimeInSec = 120; //cancellation time for free in seconds
    private $DriverCancelTime = 600; //cancellation time for dirver in seconds
    private $pubnub;
    public $distanceMetersByUnits = APP_DISTANCE_METERS;
    private $serverUploader = "";
    public $promoCodeRadius = 100;
    public $share;
    public $expireTimeForDriver = 12;
    public $expireTimeForTip = 120;

    /*
      Development -- ssl://gateway.sandbox.push.apple.com:2195
      Production -- ssl://gateway.push.apple.com:2195
     */

    public function __construct($request_uri, $postData, $origin) {

        parent::__construct($request_uri, $postData);

        $this->db = new ConDB();

        $this->curr_date_time = date('Y-m-d H:i:s', time());

        $this->share = APP_SERVER_HOST . "track.php?id=";

        $this->mongo = $this->db->mongo;
//        $this->Payfort = new Payfort();
        $this->stripe = new StripeModule();

        $this->MongoClass = new MongoClass($this->db->mongo);

        $this->pubnub = new Pubnub(PUBNUB_PUBLISH_KEY, PUBNUB_SUBSCRIBE_KEY);
    }

    protected function updateTipCheck($args) {
        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $this->curr_date_time = time();

        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));
        //  $cancleSeconds = $this->__getConfig();
        $after_5min = $apptDet['Tip_time'];

//        $lastid = $this->mongo->selectCollection('JAIN');        
//        $lastid->insert(array('serverTime'=>$this->curr_date_time,'tripTime'=>$after_5min,'bid'=>$args['ent_booking_id'] ));
        return array('Flag' => (($this->curr_date_time >= $after_5min) ? 1 : 0), 'errNo' => 505);
    }

    public function PushFromAdminForSpicific1($args) {
//        return array('test' => $_REQUEST);

        $args = $_REQUEST;
        $andiTokenArr = array();
        $aplTokenArr = array();
        $User_ids = array();
        $user_data = array();
        $andr_Token_MasId = array();
        $appl_Token_MasId = array();
        $message = $args['message'];
        $aplPushContent = array('alert' => $message, 'nt' => '420');
        $andrPushContent = array("payload" => $message, 'action' => '420');
//        $emails = $this->input->post('emails');
//        $User_id = $args['User_id'];

        $User_id = implode(",", $args['User_id']);

        $message = $args['message'];
        $city_id = $args['city_id'];

//        $msg = "Driver";
        $query = "";
        $usertype = $args['usertype'];

        if ($usertype == 2) {
//            $city_id = '';
            $query = "select * from slave where slave_id in (" . $User_id . ")"; //If the passengers are deleted so for that check user exist on not
//            $msg = "Passanger";

            $data = mysql_query($query, $this->db->conn);
////             $driversArrIos[] = 'arn:aws:sns:ap-southeast-2:284495162885:endpoint/APNS/passanger/f03799da-2b62-3cf2-9053-dda9303c9d47';
//         
            if (mysql_num_rows($data) > 0) {
//
                while ($tokenArr = mysql_fetch_assoc($data))
                    $User_ids[] = $tokenArr['slave_id'];
            }



            $users = implode(',', array_filter(array_unique($User_ids)));
            $query1 = "select * from user_sessions where oid in (" . $users . ") and user_type = 2";
            $data1 = mysql_query($query1, $this->db->conn);

            if (mysql_num_rows($data1) > 0) {
//
                while ($tokenArr = mysql_fetch_assoc($data1)) {


                    if ($tokenArr['type'] == 1) {
                        $aplTokenArr[] = $tokenArr['push_token'];
                        $appl_Token_MasId[] = $tokenArr['oid'];
                    } else if ($tokenArr['type'] == 2) {
                        $andiTokenArr[] = $tokenArr['push_token'];
                        $andr_Token_MasId[] = $tokenArr['oid'];
                    }
                }
            }
        } else {

            $query = "select * from master where mas_id in (" . $User_id . ")";
            $msg = "Driver";
            $data = mysql_query($query, $this->db->conn);


            if (mysql_num_rows($data) > 0) {

                while ($tokenArr = mysql_fetch_assoc($data))
                    $User_ids[] = $tokenArr['mas_id'];
            }

            $d = $users = implode(',', array_filter(array_unique($User_ids)));


            $query1 = "select * from user_sessions where oid in (" . $d . ") and user_type = 1 ";
            $data1 = mysql_query($query1, $this->db->conn);

            if (mysql_num_rows($data1) > 0) {
//
                while ($tokenArr = mysql_fetch_assoc($data1)) {

                    if ($tokenArr['type'] == 1) {
                        $aplTokenArr[] = $tokenArr['push_token'];
                        $appl_Token_MasId[] = $tokenArr['oid'];
                    } else if ($tokenArr['type'] == 2) {
                        $andiTokenArr[] = $tokenArr['push_token'];
                        $andr_Token_MasId[] = $tokenArr['oid'];
                    }
                }
            }
        }


//         $aplTokenArr1 = array_values(array_filter(array_unique($aplTokenArr)));
//            $andiTokenArr1 = array_values(array_filter(array_unique($andiTokenArr)));





        if (count($aplTokenArr) > 0)
            $aplResponse = $this->_sendApplePush_Admin($aplTokenArr, $appl_Token_MasId, $aplPushContent, $usertype);

        if (count($andiTokenArr) > 0)
            $andiResponse = $this->_sendAndroidPush_Admin($andiTokenArr, $andr_Token_MasId, $andrPushContent, $usertype);

        $successfullySentId = array();
        if (count($andiResponse['sendId']) != 0) {
            foreach ($andiResponse['sendId'] as $mas_id) {
                $successfullySentId[] = $mas_id;
            }
        }
        if (count($aplResponse['sendId']) != 0) {
            foreach ($aplResponse['sendId'] as $mas_id) {
                $successfullySentId[] = $mas_id;
            }
        }

        if (count($successfullySentId) != 0) {
            $insertArr = array('user_type' => (int) $usertype, 'DateTime' => date('Y-m-d H:i:s'), 'msg' => $message, 'city' => $city_id, 'user_ids' => $successfullySentId);
            $lastid = $this->mongo->selectCollection('AdminNotifications');
            $lastid->insert($insertArr);
        }

        return array('Count' => count($andiResponse['sendId']) + count($aplResponse['sendId']), 'AndriodMas_id' => $andiResponse['sendId'], 'AppleMas_id' => $aplResponse['sendId'], 'andriodPushTokens' => $andiResponse['Tokens'], 'applePushTokens' => $aplResponse['Tokens']);
    }

    public function PushFromAdminForSpicificnode($args) {
//        return $args;

        $andiTokenArr = array();
        $aplTokenArr = array();
        $User_ids = array();
        $user_data = array();
        $andr_Token_MasId = array();
        $appl_Token_MasId = array();
        $message = $args['message'];
        $aplPushContent = $args['message'];
        $User_id = implode(",", $args['User_id']);
        $aplPushContent = $args['message'];
        $andrPushContent = array("payload" => $message, 'action' => '421');
        if ($args['action'] != '')
            $andrPushContent = array("payload" => $message, 'action' => $args['action']);

        $city_id = $args['city_id'];

        $query = "";
        $usertype = $args['usertype'];

        if ($usertype == 2) {
//            $city_id = '';

            if ($args['toall'] == '1') {
                $query = "select slave_id from slave where city_id = " . $city_id;
            } else
                $query = "select * from slave where slave_id in (" . $User_id . ")"; //If the passengers are deleted so for that check user exist on not
//            $msg = "Passanger";

            $data = mysql_query($query, $this->db->conn);
////             $driversArrIos[] = 'arn:aws:sns:ap-southeast-2:284495162885:endpoint/APNS/passanger/f03799da-2b62-3cf2-9053-dda9303c9d47';
//         
            if (mysql_num_rows($data) > 0) {
//
                while ($tokenArr = mysql_fetch_assoc($data))
                    $User_ids[] = $tokenArr['slave_id'];
            }



            $users = implode(',', array_filter(array_unique($User_ids)));
            $query1 = "select * from user_sessions where oid in (" . $users . ") and user_type = 2 and loggedIn = 1";
            $data1 = mysql_query($query1, $this->db->conn);

            if (mysql_num_rows($data1) > 0) {
//
                while ($tokenArr = mysql_fetch_assoc($data1)) {


                    if ($tokenArr['type'] == 1) {
                        $aplTokenArr[] = $tokenArr['push_token'];
                        $appl_Token_MasId[] = $tokenArr['oid'];
                    } else if ($tokenArr['type'] == 2) {
                        $andiTokenArr[] = $tokenArr['push_token'];
                        $andr_Token_MasId[] = $tokenArr['oid'];
                    }
                }
            }
        } else {

            $query = "select * from master where mas_id in (" . $User_id . ")";
            $msg = "Driver";
            $data = mysql_query($query, $this->db->conn);

            if (mysql_num_rows($data) > 0) {

                while ($tokenArr = mysql_fetch_assoc($data))
                    $User_ids[] = $tokenArr['mas_id'];
            }

            $d = $users = implode(',', array_filter(array_unique($User_ids)));
            $query1 = "select * from user_sessions where oid in (" . $d . ") and user_type = 1 and loggedIn = 1";
            $data1 = mysql_query($query1, $this->db->conn);

            if (mysql_num_rows($data1) > 0) {
//
                while ($tokenArr = mysql_fetch_assoc($data1)) {

                    if ($tokenArr['type'] == 1) {
                        $aplTokenArr[] = $tokenArr['push_token'];
                        $appl_Token_MasId[] = $tokenArr['oid'];
                    } else if ($tokenArr['type'] == 2) {
                        $andiTokenArr[] = $tokenArr['push_token'];
                        $andr_Token_MasId[] = $tokenArr['oid'];
                    }
                }
            }
        }


//         $aplTokenArr1 = array_values(array_filter(array_unique($aplTokenArr)));
//            $andiTokenArr1 = array_values(array_filter(array_unique($andiTokenArr)));





        if (count($aplTokenArr) > 0)
            $aplResponse = $this->_sendApplePush_Admin($aplTokenArr, $appl_Token_MasId, $aplPushContent, $usertype);

        if (count($andiTokenArr) > 0)
            $andiResponse = $this->_sendAndroidPush_Admin($andiTokenArr, $andr_Token_MasId, $andrPushContent, $usertype);

        $successfullySentId = array();
        if (count($andiResponse['sendId']) != 0) {
            foreach ($andiResponse['sendId'] as $mas_id) {
                $successfullySentId[] = $mas_id;
            }
        }
        if (count($aplResponse['sendId']) != 0) {
            foreach ($aplResponse['sendId'] as $mas_id) {
                $successfullySentId[] = $mas_id;
            }
        }

        return array('Count' => count($andiResponse['sendId']) + count($aplResponse['sendId']), 'AndriodMas_id' => $andiResponse['sendId'], 'AppleMas_id' => $aplResponse['sendId'], 'andriodPushTokens' => $andiResponse['Tokens'], 'applePushTokens' => $aplResponse['Tokens'], 'tokens' => $andiTokenArr);
    }

    protected function PushFromAdminForAll1($args) {
        $args = $_REQUEST;
        $andiTokenArr = array();
        $aplTokenArr = array();
        $User_ids = array();

        $user_data = array();
        $andr_Token_MasId = array();
        $appl_Token_MasId = array();

        $citylatlon = explode('-', $args['city']);
        $message = $args['message'];
        $usertype = $args['usertype'];

        $aplPushContent = array('alert' => $message, 'nt' => '420');
        $andrPushContent = array("payload" => $message, 'action' => '420');

        $driversArrAndroid = array();
        $driversArrIos = $array = array();
        $User_ids = array();


        $query = "";

        if ($usertype == 2) {
            $query = "select * from slave s,user_sessions us where (3956 * acos( cos(radians('" . $citylatlon[0] . "') ) * COS( RADIANS(s.latitude) ) * cos(radians(s.longitude) - radians('" . $citylatlon[1] . "')) + sin( radians('" . $citylatlon[0] . "')) * sin( radians(s.latitude) ) ) ) <= 100 and us.oid = s.slave_id and us.user_type = 2 and loggedIn = 1";
//            $msg = "Passanger";


            $data = mysql_query($query, $this->db->conn);


            if (mysql_num_rows($data) > 0) {
                while ($tokenArr = mysql_fetch_assoc($data)) {

                    if ($tokenArr['type'] == 1) {
                        $aplTokenArr[] = $tokenArr['push_token'];
                        $appl_Token_MasId[] = $tokenArr['oid'];
                    } else if ($tokenArr['type'] == 2) {
                        $andiTokenArr[] = $tokenArr['push_token'];
                        $andr_Token_MasId[] = $tokenArr['oid'];
                    }

                    $User_ids[] = (string) $tokenArr['oid'];
                }
            }
        } else {

//             $location = $this->mongo->selectCollection('verification');
            $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
                'geoNear' => 'location',
                'near' => array(
                    (double) $citylatlon[1], (double) $citylatlon[0]
                //  (double) $_REQUEST['lat'], (double) $_REQUEST['lon']
                ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137)
            );


            foreach ($resultArr['results'] as $res) {

                $doc = $res['obj'];

                $User_ids[] = $doc['user'];
            }

            $d = $users = implode(',', array_filter(array_unique($User_ids)));
//             
//        
            $query1 = "select * from user_sessions where oid in (" . $d . ") and user_type = 1 and loggedIn = 1";
            $data1 = mysql_query($query1, $this->db->conn);


            if (mysql_num_rows($data1) > 0) {
//
                while ($tokenArr = mysql_fetch_assoc($data1)) {

                    if ($tokenArr['type'] == 1) {
                        $aplTokenArr[] = $tokenArr['push_token'];
                        $appl_Token_MasId[] = $tokenArr['oid'];
                    } else if ($tokenArr['type'] == 2) {
                        $andiTokenArr[] = $tokenArr['push_token'];
                        $andr_Token_MasId[] = $tokenArr['oid'];
                    }
                }
            }
        }

        if (count($aplTokenArr) > 0)
            $aplResponse = $this->_sendApplePush_Admin($aplTokenArr, $appl_Token_MasId, $aplPushContent, $usertype);

        if (count($andiTokenArr) > 0)
            $andiResponse = $this->_sendAndroidPush_Admin($andiTokenArr, $andr_Token_MasId, $andrPushContent, $usertype);

        $successfullySentId = array();
        if (count($andiResponse['sendId']) != 0) {
            foreach ($andiResponse['sendId'] as $mas_id) {
                $successfullySentId[] = $mas_id;
            }
        }
        if (count($aplResponse['sendId']) != 0) {
            foreach ($aplResponse['sendId'] as $mas_id) {
                $successfullySentId[] = $mas_id;
            }
        }

        if (count($successfullySentId) != 0) {
            $insertArr = array('user_type' => (int) $usertype, 'DateTime' => date('Y-m-d H:i:s'), 'msg' => $message, 'city' => $citylatlon[2], 'user_ids' => $successfullySentId);
            $lastid = $this->mongo->selectCollection('AdminNotifications');
            $lastid->insert($insertArr);
        }

        return array('Count' => count($andiResponse['sendId']) + count($aplResponse['sendId']), 'AndriodMas_id' => $andiResponse['sendId'], 'AppleMas_id' => $aplResponse['sendId'], 'andriodPushTokens' => $andiResponse['Tokens'], 'applePushTokens' => $aplResponse['Tokens']);
    }

    protected function PushNotificationByApp($args) {
//return array($args);
        if (!in_array($args['usertype'], array('1', '2'))) {
            return $this->_getStatusMessage(1, 'user type');
        } else if ($args['PushType'] == '') {
            return $this->_getStatusMessage(1, 'pushTypes');
        } else if ($args['PushType'] == 1 && $args['city'] == '') {
            return $this->_getStatusMessage(1, 'city id');
        } else if ($args['PushType'] == 2 && count($args['users']) > 1) {
            return $this->_getStatusMessage(1, 'User_id');
        } else if ($args['PushType'] == 3 && !is_array($args['User_id'])) {
            return $this->_getStatusMessage(1, 'User_id');
        }

        $action = '420';
        if ($args['action'] != '')
            $action = $args['action'];

        $aplPushContent = array('alert' => $args['message'], 'nt' => $action);
        $andrPushContent = array("payload" => $args['message'], 'action' => $action);

        switch ($args['PushType']) {
            case '1':
                if ($args['usertype'] == '1')
                    $query = 'SELECT t1.* FROM user_sessions t1,master m,company_info ci WHERE ci.company_id = m.company_id and LENGTH(t1.push_token) > 63 and ci.city = "' . $args['city'] . '" and m.mas_id = t1.oid and t1.user_type = "' . $args['usertype'] . '" AND t1.expiry = (SELECT MAX(expiry) FROM user_sessions t2 WHERE t2.oid = t1.oid)';
                else if ($args['usertype'] == '2')
                    $query = 'SELECT t1.* FROM user_sessions t1,slave s WHERE t1.user_type = "' . $args['usertype'] . '" AND t1.oid = s.slave_id and LENGTH(t1.push_token) > 63 and s.city_id = "' . $args['city'] . '" and t1.expiry = (SELECT MAX(expiry) FROM user_sessions t2 WHERE t2.oid = t1.oid)';
                break;
            case '2' :
                $query = 'SELECT t1.* FROM user_sessions t1 WHERE t1.user_type = "' . $args['usertype'] . '" AND t1.oid = "' . $args['User_id'][0] . '" and LENGTH(t1.push_token) > 63 and t1.expiry = (SELECT MAX(expiry) FROM user_sessions t2 WHERE t2.oid = t1.oid)';
                break;
            case '3' :
                $query = 'SELECT t1.* FROM user_sessions t1 WHERE t1.user_type = "' . $args['usertype'] . '" AND t1.oid in  (' . rtrim(implode(',', $args['User_id']), ',') . ') and LENGTH(t1.push_token) > 63 and t1.expiry = (SELECT MAX(expiry) FROM user_sessions t2 WHERE t2.oid = t1.oid)';
                break;
        }
        $aplTokenArr = $andiTokenArr = array();
        $getSession = mysql_query($query, $this->db->conn);
        if (mysql_num_rows($getSession) > 0) {
            while ($tokenArr = mysql_fetch_assoc($getSession)) {
                if ($tokenArr['type'] == 1) {
                    $aplTokenArr[] = $tokenArr['push_token'];
                } else if ($tokenArr['type'] == 2) {
                    $andiTokenArr[] = $tokenArr['push_token'];
                }
            }
        }

        if (count($aplTokenArr) > 0)
            $aplResponse = $this->_sendApplePush_Admin(array_unique($aplTokenArr), $aplPushContent);

        if (count($andiTokenArr) > 0)
            $andiResponse = $this->_sendAndroidPush_Admin(array_unique($andiTokenArr), $andrPushContent, $args['usertype']);

        return array('Count' => count($aplTokenArr) + count($andiTokenArr), 'andriodPushTokens' => $andrPushContent, 'applePushTokens' => $aplPushContent, 'senderIdAndd' => $andiResponse, 'senderIdApple' => $aplResponse, 'query' => $query);
    }

    protected function _sendAndroidPush_Admin($tokenArr, $andrContent, $userType) {


        if ($userType == '1')
            $apiKey = ANDROID_DRIVER_PUSH_KEY;
        else if ($userType == '2')
            $apiKey = ANDROID_PASSENGER_PUSH_KEY;



        $headers = array(
            'Authorization: key=' . $apiKey,
            'Content-Type: application/json'
        );

        $success = 0;

        for ($i = 0; $i < count($tokenArr); $i++) {

            $fields = array(
                'registration_ids' => array($tokenArr[$i]),
                'data' => $andrContent,
            );

            // Open connection
            $ch = curl_init();

            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $this->androidUrl);

            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            // Disabling SSL Certificate support temporarly
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

            // Execute post
            $result = curl_exec($ch);

            curl_close($ch);
            //        echo 'Result from google:' . $result . '---';
            $res_dec = json_decode($result);
            if ($res_dec->success == '1')
                $success++;
            usleep(500000);
        }

        return array('Tokens' => $tokenArr, 'sendId' => $success);
    }

    protected function _sendApplePush_Admin($tokenArr, $aplContent) {
        if (IOS_PUSH_TYPE === 'AMAZON') {
            $amazon = new AwsPush();
            $pushReturn = array();
            foreach ($tokenArr as $endpointArn) {
                $pushReturn[] = $amazon->publishJson(array(
                    'MessageStructure' => 'json',
                    'TargetArn' => $endpointArn,
                    'Message' => json_encode(array(
                        'APNS_SANDBOX' => json_encode(array(
                            'aps' => $aplContent
                        ))
                    )),
                ));
            }
            return array('Tokens' => 'apple', 'sendId' => $pushReturn);
        }
    }

    protected function addPaypal($args) {

        if ($args['ent_code'] == '')
            return $this->_getStatusMessage(1, 'code');

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $paypal = new paypal();

        $refreshToken = $paypal->get_refresh_token($args);

        if (!empty($refreshToken['error'])) {
            return $this->_getStatusMessage(103, 1);
        } else {
            $updateDataQry = "update slave set paypal_token = '" . $refreshToken['refresh_token'] . "' where slave_id = '" . $this->User['entityId'] . "'";
            mysql_query($updateDataQry, $this->db->conn);
            if (mysql_affected_rows() > 0)
                return $this->_getStatusMessage(102, $refreshToken);
            else
                return $this->_getStatusMessage(103, 1);
        }
    }

    protected function removePaypal($args) {

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

//        $paypal = new paypal();
//
//        $refreshToken = $paypal->get_refresh_token($args);
//
//        if (!empty($refreshToken['error'])) {
//            return $this->_getStatusMessage(103, 1);
//        } else {
        $updateDataQry = "update slave set paypal_token = '' where slave_id = '" . $this->User['entityId'] . "'";
        mysql_query($updateDataQry, $this->db->conn);
        if (mysql_affected_rows() >= 0)
            return $this->_getStatusMessage(105, 1);
        else
            return $this->_getStatusMessage(106, 1);
//        }
    }

    protected function getVerificationCode($args) {

        if ($args['ent_mobile'] == '')
            return $this->_getStatusMessage(1, 1);

        $checDeviceId = "select * from slave where DeviceId =" . $args['ent_dev_id'];
        $checDeviceIdRes = mysql_query($checDeviceId, $this->db->conn);

        if (mysql_num_rows($checDeviceIdRes) > 1)
            return $this->_getStatusMessage(134, 1);

        $checkMobileQry = "select * from slave where phone = '" . $args['ent_mobile'] . "'";
        $checkMobileRes = mysql_query($checkMobileQry, $this->db->conn);
//
////        return $this->_getStatusMessage(113, $checkMobileQry);
        if (mysql_num_rows($checkMobileRes) > 0)
            return $this->_getStatusMessage(113, $checkMobileQry);

        $rand = $args['ent_rand'] = rand(10000, 99999); //11111
        $resutl = $this->mobileVerification($args);

//        if ($resutl['errNo'] == 1)
//            return array('errNum' => 500, 'errFlag' => 0, 'errMsg' => $resutl['errMsg']);

        $location = $this->mongo->selectCollection('verification');
//
        if (is_array($location->findOne(array('mobile' => $args['ent_mobile']))))
            $location->update(array('mobile' => $args['ent_mobile']), array('$set' => array('code' => (int) $rand, 'ts' => time())));
        else
            $location->insert(array('mobile' => $args['ent_mobile'], 'code' => (int) $rand, 'ts' => time()));

//        if ($signup !== NULL)
        return $this->_getStatusMessage(107, 1);
    }

    protected function mobileVerification($args, $test = NULL, $message = NULL) {

        $client = new Services_Twilio(ACCOUNT_SID, AUTH_TOKEN);

        if ($test == NULL) {
            $message = "Thank you for registering with " . APP_NAME . ". Your confirmation code is " . $args['ent_rand'] . ".";
        }

        try {
            $message = $client->account->messages->create(array(
                'To' => $args['ent_mobile'],
                'From' => ACCOUNT_NUMBER,
                'Body' => $message
            ));
        } catch (Exception $e) {  //on error push userId in to error array
            $notifications = $this->mongo->selectCollection('mobilestatuerror');
            $notifications->insert(array('data' => $e->getMessage()));
        }

        return true;
    }

    public function SendSms($args) {
        if ($args['ent_mobile'] == '')
            return $this->_getStatusMessage(1, 1);
        else if ($args['ent_msg'] == '')
            return $this->_getStatusMessage(1, 1);

        $client = new Services_Twilio(ACCOUNT_SID, AUTH_TOKEN);
        try {

            $message = $client->account->messages->create(array(
                'To' => $args['ent_mobile'],
                'From' => ACCOUNT_NUMBER,
                'Body' => $args['ent_msg']
            ));
        } catch (Exception $e) {  //on error push userId in to error array
            $notifications = $this->mongo->selectCollection('mobilestatuerror');
            $notifications->insert(array('data' => $e->getMessage()));
        }
        return array('flag' => 1);
    }

    protected function checkMobile($args) {
        if ($args['ent_mobile'] == '')
            return $this->_getStatusMessage(1, 'Mobile number');
        else if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'User type');

        if ($args['ent_user_type'] == '2') {
            $table = "slave";
            $field = "phone";
        } else {
            $table = "master";
            $field = "mobile";
        }

        $checkMobileQry = "select status from $table where $field = '" . $args['ent_mobile'] . "'";
        $checkMobileRes = mysql_query($checkMobileQry, $this->db->conn);

        if (mysql_num_rows($checkMobileRes) > 0)
            return $this->_getStatusMessage(113, 1);
        else
            return $this->_getStatusMessage(112, 1);
    }

    protected function verifyPhone($args) {

        if ($args['ent_phone'] == '')
            return $this->_getStatusMessage(1, 'Mobile number');
        else if ($args['ent_code'] == '')
            return $this->_getStatusMessage(1, 'Code');

        $notifications = $this->mongo->selectCollection('notifications');

        $notifications->insert($args);

//        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2', '1');
//
//        if (is_array($returned))
//            return $returned;

        $location = $this->mongo->selectCollection('verification');
        if (is_array($location->findOne(array('mobile' => $args['ent_phone'], 'code' => (int) $args['ent_code']))) || $args['ent_code'] == '11111') {
//            $updateQry = "update slave status = 3 where slave_id = '" . $this->User['entityId'] . "'";
//            mysql_query($updateQry, $this->db->conn);
            return $this->_getStatusMessage(109, 1);
        } else {
            return $this->_getStatusMessage(110, 1);
        }
    }

    /*
     * Method name: masterLogin
     * Desc: Driver login on the app
     * Input: Request data
     * Output:  Success flag with data array if completed successfully, else data array with error flag
     */

    protected function masterLogin($args) {

//        $this->mongo->selectCollection('notifications')->insert($args);

        if ($args['ent_email'] == '')
            return $this->_getStatusMessage(1, 'Email');
        if ($args['ent_password'] == '')
            return $this->_getStatusMessage(1, 'Password');
        if ($args['ent_dev_id'] == '')
            return $this->_getStatusMessage(1, 'Device id');
        if ($args['ent_device_type'] == '')
            return $this->_getStatusMessage(1, 'Device type');
        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        if ($args['ent_lat'] == '' || $args['ent_long'] == '')
            return $this->_getStatusMessage(1, 'Location');
        if ($args['ent_lang'] == '' && $args['ent_device_type'] == 2)
            return $this->_getStatusMessage(1, 'Language');
        if ($args['ent_push_token'] == "")
            return $this->_getStatusMessage(1, 'ent_push_token');
        $this->User['lang'] = $args['ent_lang'];


        $location = $this->mongo->selectCollection('location');
        $this->curr_date_time = urldecode($args['ent_date_time']);

        $devTypeNameArr = $this->_getDeviceTypeName($args['ent_device_type']);

        if (!$devTypeNameArr['flag'])
            return $this->_getStatusMessage(5, 108);

        $args['ent_email'] = strtolower($args['ent_email']);

        $searchDriverQry = "select md5('" . $args['ent_password'] . "') as given_password,m.account_type,m.mobile,m.password,m.company_id,m.mas_id,m.profile_pic,m.first_name,m.last_name,m.created_dt,m.license_num,m.status,m.workplace_id,(select status from company_info where company_id = m.company_id) as company_status from master m where ( m.email = '" . $args['ent_email'] . "' or m.mobile = '" . $args['ent_email'] . "'  )";
        $searchDriverRes = mysql_query($searchDriverQry, $this->db->conn);
//echo $searchDriverQry;

        if (mysql_num_rows($searchDriverRes) <= 0)
            return $this->_getStatusMessage(8, $searchDriverQry); //_getStatusMessage($errNo, $test_num);

        $driverRow = mysql_fetch_assoc($searchDriverRes);

        if ($driverRow['password'] !== $driverRow['given_password'])
            return $this->_getStatusMessage(117, 18); //_getStatusMessage($errNo, $test_num);

        if ($driverRow['status'] == '2' || $driverRow['status'] == '1')
            return $this->_getStatusMessage(10, 17); //_getStatusMessage($errNo, $test_num);

        if ($driverRow['company_status'] != '3')
            return $this->_getStatusMessage(92, 17); //_getStatusMessage($errNo, $test_num);

        if ($driverRow['status'] == '4')
            return $this->_getStatusMessage(79, 79); //_getStatusMessage($errNo, $test_num);

        if ($driverRow['status'] == '6')
            return $this->_getStatusMessage(137, 79);

        mysql_query("update user_sessions set loggedIn = 2 where device = '" . $args['ent_dev_id'] . "' and user_type = 1 and oid != '" . $driverRow['mas_id'] . "'", $this->db->conn);
        mysql_query("update user_sessions set loggedIn = 3 where device != '" . $args['ent_dev_id'] . "' and user_type = 1 and oid = '" . $driverRow['mas_id'] . "'", $this->db->conn);
        /*
         * Sending last workplace id in an array for the current user, if he is logged in this car, then that will be freed for others
         */



        $statusLog = $this->mongo->selectCollection('statusLog');

        $lastLoggedInStatus = array();
        $lastLoggedIn = $statusLog->find(array('master' => (int) $driverRow['mas_id'], 'status' => 3, 'time' => array('$lte' => time())))->sort(array('time' => -1))->limit(1);
        foreach ($lastLoggedIn as $key) {
            $lastLoggedInStatus[] = $key;
        }

        if ($lastLoggedInStatus[0]['status'] == 3) {
            $update['status_log'] = $statusLog->update(array('master' => (int) $driverRow['mas_id'], 'status' => 3), array('$set' => array('status' => 4, 'EndTime' => time(), 'dist' => ((double) $args['ent_overall_dist'] > 0 ? (double) $args['ent_overall_dist'] : 0))));
        }

        $updateWorkplaceIdQry = "update master set workplace_id = '' where mas_id = '" . $driverRow['mas_id'] . "'";
        mysql_query($updateWorkplaceIdQry, $this->db->conn);

        $updateWorkplaceQry = "update workplace set Status = 2,last_logout_lat = '" . $args['ent_lat'] . "',last_logout_long = '" . $args['ent_long'] . "' where workplace_id = '" . $driverRow['workplace_id'] . "'";
        mysql_query($updateWorkplaceQry, $this->db->conn);


        if ($args['ent_device_type'] == 2) {
            $getApptStatusQry = "update master set lang = '" . $args['ent_lang'] . "' where mas_id = '" . $driverRow['mas_id'] . "'";
            mysql_query($getApptStatusQry, $this->db->conn);
        }

        $sessDet = $this->_checkSession($args, $driverRow['mas_id'], '1', $devTypeNameArr['name'], null); // ($carRow['workplace_id'] == $driverRow['workplace_id']) ? NULL : array('workplaceId' => $driverRow['workplace_id'], 'lat' => $args['ent_lat'], 'lng' => $args['ent_long'])); //_checkSession($args, $oid, $user_type);

        $location->update(array('chn' => 'qd_' . $args['ent_dev_id']), array('$set' => array('chn' => '', 'listner' => '')));

        $location->update(array('user' => (int) $driverRow['mas_id']), array('$set' => array('type' => 0, 'carId' => 0, 'chn' => 'qd_' . $args['ent_dev_id'], 'loginTime' => time(), 'listner' => 'qdl_' . $args['ent_dev_id'], 'status' => 4, 'inBooking' => 1, "LastBookingTime" => time())));

        $errMsgArr = $this->_getStatusMessage(9, 8);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'data' => array(
                'token' => $sessDet['Token'],
                'fname' => $driverRow['first_name'],
                'mid' => $driverRow['mas_id'],
                'presenseChn' => presenseChn,
                'lname' => $driverRow['last_name'],
                'profilePic' => $driverRow['profile_pic'],
                'email' => $args['ent_email'],
                'susbChn' => 'qd_' . $args['ent_dev_id'],
                'chn' => APP_PUBNUB_CHANNEL,
                'listner' => 'qdl_' . $args['ent_dev_id'],
                'status' => $masterDet['status'],
                'referralCode' => $masterDet['coupon_code'],
                'driverid' => $driverRow["mas_id"],
                'pub' => PUBNUB_PUBLISH_KEY,
                'sub' => PUBNUB_SUBSCRIBE_KEY,
                'phone' => $driverRow['mobile'],
                'Languages' => $this->getLangueage(),
                'workpalce' => $this->getWorkplaceForDriver_($driverRow['mas_id'], $driverRow['company_id'], $driverRow['account_type'])));
    }

    /*
     * 
     * 
     * get linked driver vehicle id
     * 
     */

    protected function getWorkplaceForDriver_($driverid, $compayid, $account_type) {

        if ($account_type == '1') {
            $selectWkTypesQry = "select uniq_identity from workplace where Status = 2 and ((company ='" . $compayid . "' and mas_id = 0 ) or (mas_id = '" . $driverid . "'))  ";
        } else
            $selectWkTypesQry = "select uniq_identity from workplace where company ='" . $compayid . "' and Status = 2";

        $selectWkRes = mysql_query($selectWkTypesQry, $this->db->conn);

        $vehicleId_ = array();

        while ($VehicleId = mysql_fetch_assoc($selectWkRes)) {
            $getVehicleDataQry = "select wrk.License_Plate_No, (select vm.vehiclemodel from vehiclemodel vm, workplace w where w.Vehicle_Model = vm.id and w.workplace_id = wrk.workplace_id) as vehicle_model, (select vt.vehicletype from vehicleType vt, workplace w,vehiclemodel vm where vm.id = w.Vehicle_Model and vm.vehicletypeid = vt.id and w.workplace_id = wrk.workplace_id) as vehicle_brand, (select wt.type_name from workplace_types wt, workplace w where w.type_id = wt.type_id and w.workplace_id = wrk.workplace_id) as vehicle_type, (select wt.MapIcon from workplace_types wt, workplace w where w.type_id = wt.type_id and w.workplace_id = wrk.workplace_id) as MapIcon from workplace wrk where  wrk.uniq_identity = '" . $VehicleId['uniq_identity'] . "'";

            $getVehicleDataRes = mysql_query($getVehicleDataQry, $this->db->conn);

            $vehicleData = mysql_fetch_assoc($getVehicleDataRes);

            $vehicleId_[] = array('VehileId' => $VehicleId['uniq_identity'], 'licPlateNum' => $vehicleData['License_Plate_No'], 'vehModle' => $vehicleData['vehicle_model'], 'vehicleType' => $vehicleData['vehicle_type'], 'TypeImage' => $vehicleData['MapIcon'], 'brand' => $vehicleData['vehicle_brand']);
        }

        return $vehicleId_;
    }

    /*
     * 
     *  make default work place
     */

    public function DefaultWorkplaceForDriver($args) {
        if ($args['ent_vehile_id'] == '') {
            return $this->_getStatusMessage(1, 'ent_vehile_id');
        } else if ($args['ent_mid'] == '') {
            return $this->_getStatusMessage(1, 'ent_mid');
        }

//        $this->MongoClass->insert('aaaaaaaaaaaa', $args);

        $location = $this->mongo->selectCollection('location');
        $mas = $location->findOne(array('user' => (int) $args['ent_mid']));

        $checkCarAvailabilityQry = "select w.type_id,w.Status,w.company,w.workplace_id,(select type_icon from workplace_types where type_id = w.type_id) as type_icon,(select type_name from workplace_types where type_id = w.type_id) as type_Name,(select city_id from workplace_types where type_id = w.type_id) as cityid from workplace w where w.uniq_identity = '" . $args['ent_vehile_id'] . "'";
        $checkCarAvailabilityRes = mysql_query($checkCarAvailabilityQry, $this->db->conn);
        $carRow = mysql_fetch_assoc($checkCarAvailabilityRes);

        if ($carRow['Status'] == '4')
            return $this->_getStatusMessage(121, 76); //_getStatusMessage($errNo, $test_num);

        if ($carRow['Status'] != '2')
            return $this->_getStatusMessage(77, 76); //_getStatusMessage($errNo, $test_num);

        $updateother = "update master set workplace_id = '0'  where mas_id ='" . $args['ent_mid'] . "'";
        mysql_query($updateother, $this->db->conn);

        $selectWkTypesQry = "update master set workplace_id = '" . $carRow['workplace_id'] . "'  where mas_id ='" . $args['ent_mid'] . "'";
        mysql_query($selectWkTypesQry, $this->db->conn);
        if (mysql_affected_rows() > 0) {
//            $updateCarStatusQry = "update workplace set Status = 2 where mas_id = '" . $mas['user'] . "'";
//            mysql_query($updateCarStatusQry, $this->db->conn);

            $updateCarStatusQry = "update workplace set Status = 1 where workplace_id = '" . $carRow['workplace_id'] . "'";
            mysql_query($updateCarStatusQry, $this->db->conn);

            $location->update(array('user' => (int) $args['ent_mid']), array('$set' => array('type' => (int) $carRow['type_id'], 'carId' => (int) $carRow['workplace_id'])));

            $errorno = $this->_getStatusMessage(23, 'test');
            return array('errNum' => $errorno['errNum'], 'errFlag' => $errorno['errFlag'], 'errMsg' => $errorno['errMsg'], 'tp' => $carRow['type_id'], 'cityid' => $carRow['cityid']);
        } else
            return $this->_getStatusMessage(3, $selectWkTypesQry);

        return $return;
    }

    /*
     * Method name: slaveSignup
     * Desc: Passenger signup
     * Input: Request data
     * Output:  Success flag with data array if completed successfully, else data array with error flag
     */

    protected function getCity($args) {
        $condition = "('" . customerRadiusUnit . "' * acos ( cos ( radians( '" . $args['latitude'] . "') ) * cos( radians(ca.City_Lat ) ) * cos( radians(ca.City_Long) - radians('" . $args['longitude'] . "') ) + sin ( radians( '" . $args['latitude'] . "' ) ) * sin( radians(ca.City_Lat) ) )) < '" . customerRadius . "'";
        $query = "select ca.City_Id from city_available ca where $condition";
        $checkMobileRes = mysql_query($query, $this->db->conn);

        if (mysql_num_rows($checkMobileRes) == 0)
            return $this->_getStatusMessage(113, $query);

        $referralData = mysql_fetch_assoc($checkMobileRes);
        return array('cityId' => $referralData['City_Id']);
    }

    /*
     * get referral code 
     * 
     */

    protected function getReferralCode($args) {
        if ($args['ent_dev_type'] == '')
            return $this->_getStatusMessage(1, 'device type');

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');
        if (is_array($returned))
            return $returned;

        return array('errFlg' => 0, 'errNo' => 505, 'errMsg' => 'got the details',
            'referralCode' => $this->User['coupon'],
            'referralTitle' => 'Get a discount if your contacts sign up using your invite code',
            'referralBody' => 'Hello,\n  Use my  referral code, ' . $this->User['coupon'] . ' to signup on ' . APP_NAME . ' and you will  get an exclusive profit. Go to link ' . ($args['ent_dev_type'] == '2' ? 'https://play.google.com/store/apps/details?id=com.pq.passenger' : ''));
    }

    protected function slaveSignup($args) {

//     $data = $this->mongo->selectCollection('slavesignup');
//     $args = $data->findOne(array('_id' => new MongoId('583fdbe3861e53d65688c3f0')));
        if ($args['ent_first_name'] == '')
            return $this->_getStatusMessage(1, 'First name');
        else if ($args['ent_email'] == '')
            return $this->_getStatusMessage(1, 'Email');
        else if ($args['ent_password'] == '')
            return $this->_getStatusMessage(1, 'Password');
        else if ($args['ent_mobile'] == '')
            return $this->_getStatusMessage(1, 'Mobile');
        else if ($args['ent_dev_id'] == '')
            return $this->_getStatusMessage(1, 'Device id');
        else if ($args['ent_device_type'] == '')
            return $this->_getStatusMessage(1, 'Device type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_latitude'] == "")
            return $this->_getStatusMessage(1, 'latitude');
        else if ($args['ent_longitude'] == "")
            return $this->_getStatusMessage(1, 'longitude');



//        $this->curr_date_time = urldecode($args['ent_date_time']);
//
//        if ($this->curr_date_time == '0000-00-00 00:00:00')
//            $this->curr_date_time = date("Y-m-d H:i:s", time());

        if ($args['ent_terms_cond'] == '0')
            return $this->_getStatusMessage(14, 14); //_getStatusMessage($errNo, $test_num);

        if ($args['ent_pricing_cond'] == '0')
            return $this->_getStatusMessage(15, 15); //_getStatusMessage($errNo, $test_num);

        if ($args['ent_latitude'] == '')
            $args['ent_latitude'] = 0;

        if ($args['ent_longitude'] == '')
            $args['ent_longitude'] = 0;

        if ($args['ent_referral_code'] != '' && ((double) $args['ent_latitude'] < 0 || (double) $args['ent_longitude'] < 0))
            return $this->_getStatusMessage(120, 4);

        $devTypeNameArr = $this->_getDeviceTypeName($args['ent_device_type']);

        if (!$devTypeNameArr['flag'])
            return $this->_getStatusMessage(4, 4); //_getStatusMessage($errNo, $test_num);


























































































            
// check passanger device id being used multiple time or not
        $checDeviceId = "select * from slave where DeviceId =" . $args['ent_dev_id'];
        $checDeviceIdRes = mysql_query($checDeviceId, $this->db->conn);

        $ALLOW_PASSANGER_SIGNUP = $this->__getConfig();
        if (mysql_num_rows($checDeviceIdRes) > $ALLOW_PASSANGER_SIGNUP['maxDriverOneDevice'])
            return $this->_getStatusMessage(134, 1);


        $checkMobileQry = "select status from slave where phone = '" . $args['ent_mobile'] . "'";
        $checkMobileRes = mysql_query($checkMobileQry, $this->db->conn);

        if (mysql_num_rows($checkMobileRes) > 0)
            return $this->_getStatusMessage(113, 1);

        $verifyEmail = $this->_verifyEmail($args['ent_email'], 'slave_id', 'slave'); //_verifyEmail($email,$field,$table);

        if (is_array($verifyEmail))
            return $this->_getStatusMessage(2, 2); //_getStatusMessage($errNo, $test_num);

        $carTypes = $this->getWorkplaceTypes($args['ent_city'], $args['ent_latitude'], $args['ent_longitude']);

//        if (!is_array($carTypes))
//            return $this->_getStatusMessage(80, 80);
//        if ($args['ent_referral_code'] != '') {
//            $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
//                'geoNear' => 'coupons',
//                'near' => array(
//                    (double) $args['ent_longitude'], (double) $args['ent_latitude']
//                ), 'spherical' => true, 'maxDistance' => 10000000 / 6378137, 'distanceMultiplier' => 6378137,
//                'query' => array('status' => 0, 'coupon_code' => 'REFERRAL', 'coupon_code' => (string) $args['ent_referral_code']))
//            );
//
//            if (count($resultArr['results']) <= 0) {
//                return $this->_getStatusMessage(100, 2);
//            }
//        }

        $getCity = $this->getCity(array("latitude" => $args['ent_latitude'], "longitude" => $args['ent_longitude']));

        $insertSlaveQry = "
                        insert into 
                        slave(first_name,last_name,email,password,phone,status,
                        created_dt,last_active_dt,latitude,longitude,city_id,DeviceId,ThirdPartyLoginType,ServerTime,gender,dob) 
                        values('" . $args['ent_first_name'] . "','" . $args['ent_last_name'] . "','" . $args['ent_email'] . "',md5('" . $args['ent_password'] . "'),'" . $args['ent_mobile'] . "','3',
                                '" . $this->curr_date_time . "','" . $this->curr_date_time . "','" . $args['ent_latitude'] . "','" . $args['ent_longitude'] . "','" . $getCity['cityId'] . "','" . $args['ent_dev_id'] . "','" . $args['ent_login_type'] . "','" . $this->curr_date_time . "','" . $args['ent_gender'] . "','" . $args['ent_dob'] . "')";

        mysql_query($insertSlaveQry, $this->db->conn);

        if (mysql_error($this->db->conn) != '')
            return $this->_getStatusMessage(3, $insertSlaveQry); //_getStatusMessage($errNo, $test_num);

        $newPassenger = mysql_insert_id($this->db->conn);

        if ($newPassenger <= 0)
            return $this->_getStatusMessage(3, 3); //_getStatusMessage($errNo, $test_num);

        $referralUsageMsg = $couponId = "";
        $mailArr = array();
        $mail = new sendAMail(APP_SERVER_HOST);


//        $couponsColl = $this->mongo->selectCollection('coupons');
//
//        $couponsColl->ensureIndex(array('location' => '2d'));
//
//        $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
//            'geoNear' => 'coupons',
//            'near' => array(
//                (double) $args['ent_longitude'], (double) $args['ent_latitude']
//            ), 'spherical' => true, 'maxDistance' => 100000 / 6378137, 'distanceMultiplier' => 6378137,
//            'query' => array('status' => 0, 'coupon_code' => 'REFERRAL'))
//        );
//
//        if (count($resultArr['results']) > 0) {
//
//            $referralData = $resultArr['results'][0]['obj'];
//
//            $friendDiscCode = $friendReferred = "";
//
//            $coupon = $this->_createCoupon($couponsColl);
//
//            if ($args['ent_referral_code'] != '') {
//
//                $referralArr = $this->mongo->selectCollection('$cmd')->findOne(array(
//                    'geoNear' => 'coupons',
//                    'near' => array(
//                        (double) $args['ent_longitude'], (double) $args['ent_latitude']
//                    ), 'spherical' => true, 'maxDistance' => 100000 / 6378137, 'distanceMultiplier' => 6378137,
//                    'query' => array('coupon_code' => (string) $args['ent_referral_code'], 'coupon_type' => 1, 'user_type' => 1, 'status' => 0))
//                );
//
//                if (count($referralArr['results']) > 0) {
//
//                    $couponData = $referralArr['results'][0]['obj'];
//
//                    $discountCoupon = $this->_createCoupon($couponsColl);
//
//                    $friendReferred = $couponData['user_id'];
//
//                    $insertArr = array(
//                        "coupon_code" => $discountCoupon,
//                        "coupon_type" => 3,
//                        "start_date" => strtotime($this->curr_date_time),
//                        "expiry_date" => strtotime($this->curr_date_time) + (10 * 30 * 24 * 60 * 60),
//                        "discount_type" => $couponData['referral_discount_type'],
//                        "discount" => $couponData['referral_discount'],
//                        "message" => $couponData['message'],
//                        "status" => 0,
//                        "city_id" => $couponData['city_id'],
//                        "location" => $couponData['location'],
//                        "user_type" => 1,
//                        "user_id" => (string) $couponData['user_id'],
//                        "email" => $couponData['email'],
//                        'created_ts' => strtotime($this->curr_date_time)
//                    );
//
//                    $couponsColl->insert($insertArr);
//
//                    if ($insertArr['_id'] != '') {
//
//                        $friendDiscCode = $this->_createCoupon($couponsColl);
//
//                        $discCouponNewUser = array(
//                            "coupon_code" => $friendDiscCode,
//                            "parantId" => $couponData['user_id'],
//                            "coupon_type" => 3,
//                            "counter" => 0,
//                            "parantCoupon" => $discountCoupon,
//                            "start_date" => strtotime($this->curr_date_time),
//                            "expiry_date" => strtotime($this->curr_date_time) + (10 * 30 * 24 * 60 * 60),
//                            "discount_type" => $couponData['discount_type'],
//                            "discount" => $couponData['discount'],
//                            "message" => $couponData['message'],
//                            "status" => 0,
//                            "city_id" => $couponData['city_id'],
//                            "location" => $couponData['location'],
//                            "user_type" => 1,
//                            "user_id" => (string) $newPassenger,
//                            "email" => $args['ent_email'],
//                            'created_ts' => strtotime($this->curr_date_time)
//                        );
//
//                        $couponsColl->insert($discCouponNewUser);
//
//                        $mailArr[] = $mail->discountOnFriendSignup($couponData['email'], $couponData['first_name'], array('code' => $discountCoupon, 'discountData' => $couponData, 'uname' => $args['ent_first_name'])); //$couponId
//                        $friendDiscCode = $this->_createCoupon($couponsColl);
//
//                        $cond = array('_id' => $referralData['_id'], 'signups.coupon_code' => $args['ent_referral_code']);
//
//                        $push = array('$push' => array('signups.$.discounts' => array('discount_code' => $discountCoupon, 'signedUpUser' => array('slave_id' => $newPassenger, 'discount_code' => $friendDiscCode, 'email' => $args['ent_email'], 'referral' => $coupon, 'created_ts' => strtotime($this->curr_date_time)))));
//
//                        $couponsColl->update($cond, $push);
//                    } else {
//                        $error = $this->_getStatusMessage(100, 100);
//                        $referralUsageMsg = $error['errMsg'];
//                    }
//                } else {
//                    $error = $this->_getStatusMessage(100, 2);
//                    $referralUsageMsg = $error['errMsg'];
//                }
//            }
//
//            $insertReferralArr = array(
//                "coupon_code" => $coupon,
//                "coupon_type" => 1,
//                "start_date" => strtotime($this->curr_date_time),
//                "expiry_date" => strtotime($this->curr_date_time) + (10 * 365 * 24 * 60 * 60),
//                "discount_type" => $referralData['discount_type'],
//                "discount" => $referralData['discount'],
//                "referral_discount_type" => $referralData['referral_discount_type'],
//                "referral_discount" => $referralData['referral_discount'],
//                "message" => $referralData['message'],
//                "status" => 0,
//                "city_id" => $referralData['city_id'],
//                "currency" => $referralData['currency'],
//                "location" => $referralData['location'],
//                "user_type" => 1,
//                "user_id" => $newPassenger,
//                "email" => $args['ent_email'],
//                'created_ts' => strtotime($this->curr_date_time)
//            );
//
//            $data = array('coupon_code' => $coupon, 'slave_id' => $newPassenger, 'email' => $args['ent_email'], 'fname' => $args['ent_first_name'], 'created_dt' => time());
//
//            $couponsColl->update(array('_id' => $referralData['_id']), array('$push' => array('signups' => $data)));
//
//            $couponsColl->insert($insertReferralArr);
//
//            if ($insertReferralArr['_id'] > 0) {
//                $couponId = $coupon;
//                $updateCouponQry = "update slave set coupon = '" . $coupon . "' where slave_id = '" . $newPassenger . "'";
//                mysql_query($updateCouponQry, $this->db->conn);
//                $mailArr[] = $mail->sendDiscountCoupon($args['ent_email'], $args['ent_first_name'], array('code' => $friendDiscCode, 'refCoupon' => $coupon, 'discountData' => $referralData)); //$couponId
//            }
//        } else {
//            $mailArr[] = $mail->sendSlvWelcomeMail($args['ent_email'], $args['ent_first_name']); //$couponId
////            echo $checkReferralAvailability;
//        }


        /*         * ********** */
        $arrayCampain = array('ent_latitude' => $args['ent_latitude'], 'CampaingsType' => 1,
            'ent_longitude' => $args['ent_longitude'],
            'user_id' => $newPassenger,
            'user_email' => $args['ent_email'],
            'user_name' => $args['ent_first_name'],
            'ent_referral_code' => $args['ent_referral_code']
        );

        $CampainData = $this->Campaings($arrayCampain);
        if ($CampainData['flag'] == 0) {
            $referralCode = $CampainData['referralCode'];
            if ($CampainData['ReferralType'] == 3) {
                $mailArr[] = $mail->discountOnFriendSignup($CampainData['parantUser']['userEmail'], $CampainData['parantUser']['userName'], array('code' => $CampainData['parantUser']['coupon_code'], 'discountData' => $CampainData['parantUser'], 'uname' => $args['ent_first_name'])); //$couponId
                $mailArr[] = $mail->sendDiscountCoupon($CampainData['CurrentUser']['userEmail'], $CampainData['CurrentUser']['userName'], array('code' => $CampainData['parantUser']['coupon_code'], 'refCoupon' => $CampainData['CurrentUser']['coupon_code'], 'discountData' => $CampainData['CurrentUser'])); //$couponId
            }
            $updateCouponQry = "update slave set coupon = '" . $referralCode . "' where slave_id = '" . $newPassenger . "'";
            mysql_query($updateCouponQry, $this->db->conn);
        }
        /*         * ********* */

        /* createSessToken($obj_id, $dev_name, $mac_addr, $push_token); */
        $createSessArr = $this->_checkSession($args, $newPassenger, '2', $devTypeNameArr['name']); //$token_obj->createSessToken($newPassenger, $devTypeNameArr['name'], $args['ent_dev_id'], $args['ent_push_token'], '2');

        if ($args['ent_push_token'] == '')
            $errMsgArr = $this->_getStatusMessage(115, 8);
        else
            $errMsgArr = $this->_getStatusMessage(5, 8);

        $ClientPlaceKey = And_ClientPlaceKey;
        if ($args['ent_dev_id'] == 1) {
            $ClientPlaceKey = Ios_ClientPlaceKey;
        }

        return array('errNum' => $errMsgArr['errNum'],
            'refferalData' => $referralCode,
            'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'],
            'coupon' => $referralCode,
            'presenseChn' => presenseChn,
            'stipeKey' => stipeKeyForApp,
            'ClientPlaceKey' => $ClientPlaceKey,
            'name' => $args['ent_first_name'] . ' ' . $args['ent_last_name'],
            'sid' => $newPassenger,
            'token' => $createSessArr['Token'],
            'email' => $args['ent_email'],
            'types' => $carTypes,
            'PaymentUrl' => $this->Payfort . $this->encrypt_decrypt('encrypt', $newPassenger),
            'serverChn' => APP_PUBNUB_CHANNEL,
            'chn' => 'qp_' . $args['ent_dev_id'],
            'pub' => PUBNUB_PUBLISH_KEY, 'sub' => PUBNUB_SUBSCRIBE_KEY);
    }

    /*
     * CheckPromotions
     * 
     */

    protected function Campaings($args) {
        if ($args['CampaingsType'] == '')
            return array('flag' => 1, 'msg' => 'type missing');
        else if ($args['ent_latitude'] == '' && ($args['CampaingsType'] == '1' && $args['CampaingsType'] == '3'))
            return array('flag' => 1, 'msg' => 'ent_latitude needed');
        else if ($args['ent_longitude'] == '' && ($args['CampaingsType'] == '1' && $args['CampaingsType'] == '3'))
            return array('flag' => 1, 'msg' => 'ent_longitude needed');
        else if ($args['user_id'] == '' && $args['CampaingsType'] != '3')
            return array('flag' => 1, 'msg' => 'user_id needed');
        else if ($args['user_email'] == '' && $args['CampaingsType'] == '1')
            return array('flag' => 1, 'msg' => 'user_email needed');
        else if ($args['user_name'] == '' && $args['CampaingsType'] == '1')
            return array('flag' => 1, 'msg' => 'user_name needed');
        else if ($args['buildAmount'] == '' && $args['CampaingsType'] == '2')
            return array('flag' => 1, 'msg' => 'buildAmount needed');
        else if ($args['bookingId'] == '' && $args['CampaingsType'] == '2')
            return array('flag' => 1, 'msg' => 'bookingId needed');
        else if ($args['code'] == '' && $args['CampaingsType'] == '2')
            return array('flag' => 1, 'msg' => 'promo code needed');

        $Refferal = new campaign();

        if ($args['CampaingsType'] == 1) { // referral
            $RefferalResp = $Refferal->RewardForNewSignup($args);

            if ($RefferalResp["flag"] == 0 && $RefferalResp["promotionType"] == "") {
                // storeRefferalCode
                return array('flag' => 0, 'ReferralType' => 1, 'referralCode' => $RefferalResp['ReferralCode']);
            } else if ($RefferalResp["flag"] == 0 && $RefferalResp["promotionType"] == "2") {
                // credit to wallet
                return array('flag' => 0, 'ReferralType' => 2, 'referralCode' => $RefferalResp['ReferralCode']);
            } else if ($RefferalResp["flag"] == 0 && $RefferalResp["promotionType"] == "1") {
                // get promocode and send to parnat as we as current user
                return array('flag' => 0, 'ReferralType' => 3, 'referralCode' => $RefferalResp['ReferralCode'], "parantUser" => $RefferalResp["parantUser"], "CurrentUser" => $RefferalResp["CurrentUser"]);
            }
        } else if ($args['CampaingsType'] == 2) { // promotions
            $promodata = array(
                "buildAmount" => $args['buildAmount'],
                "UserId" => $args['user_id'],
                "bookingId" => $args['bookingId'],
                "ent_coupon" => $args['code']
            );
            $response = $Refferal->getPromoProfit($promodata);
            if ($response["flag"] == 0 && $response["Type"] == "1") {
                return $response;
            } else if ($RefferalResp["flag"] == 0 && $RefferalResp["promotionType"] == "2") {
                return array('flag' => 1, 'test' => $response);
            }
            return $response;
        } else if ($args['CampaingsType'] == 3) {
            return $Refferal->CheckRefferalForXrides($args);
        } else if ($args['CampaingsType'] == 4) {
            $returnData = $Refferal->triggerRewardForCompletingxrides($args);
            if ($returnData["Type"] == "PROMO") {
                $mail = new sendAMail(APP_SERVER_HOST);
                if (is_array($returnData['referrer']))
                    $mailArr[] = $mail->discountOnFriendSignupXrides($returnData['referrer']['userEmail'], $returnData['referrer']['userName'], array('code' => $returnData['referrer']['coupon_code'], 'discountData' => $returnData['referrer'], 'uname' => $returnData['referred']['userName'])); //$couponId
                if (is_array($returnData['referred']))
                    $mailArr[] = $mail->sendDiscountCouponXrides($returnData['referred']['userEmail'], $returnData['referred']['userName'], $returnData['referred']); //$couponId
                $this->mongo->selectCollection('campaindata')->insert(array('mail' => $mailArr, 'res' => $returnData));
            }
            return array('flag' => 0, 'test' => $returnData);
        }
        return array('flag' => 1, 'msg' => 'Error while Processing');
    }

    public function testpromotion() {

        $args['ent_latitude'] = "13.028572925538553";
        $args["ent_longitude"] = "77.59019801501174";
        $newPassenger = 420;
        $args['ent_email'] = "rpatil@mobifyi.com";
        $args['ent_first_name'] = "rahul patil";
        $args['ent_referral_code'] = "bv5nbns";

        $arrayCampain = array('ent_latitude' => $args['ent_latitude'], 'CampaingsType' => 1,
            'ent_longitude' => $args['ent_longitude'],
            'user_id' => $newPassenger,
            'user_email' => $args['ent_email'],
            'user_name' => $args['ent_first_name'],
            'ent_referral_code' => $args['ent_referral_code']
        );

        $CampainData = $this->Campaings($arrayCampain);
        return array('test' => $CampainData);

//          $args['ent_coupon'] = 'wudvifv';
//          $args['ent_payment_type'] = '2';
//          if ($args['ent_coupon'] != "") {
//            $Refferal = new campaign();
//            $promodata = array(
//                'ent_latitude' => 13.0288639376006,
//                'ent_longitude' => 77.5895761325955,
//                'userId' => 16,
//                'ent_coupon' => $args['ent_coupon'],
//                'ent_from_long' => 77.5895761325955,
//                'ent_from_lat' => 13.0288639376006
//            );
//
//            $response = $Refferal->checkCoupons($promodata);
//            if ($response['flag'] == 1) {
//                $errMsgArr = $this->_getStatusMessage(116, 52);
//                return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $response['msg']);
//            }
//            if ($response['PaymentType'] != ($args['ent_payment_type'] == '2' ? '1' : '2') && $response['PaymentType'] != '3') {
//                $errMsgArr = $this->_getStatusMessage(116, 52);
//                return array('ptype' => $response, 'errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => "The Promocode Is not Applicable for " . ($args['ent_payment_type'] == '2' ? 'Cash' : 'Card') . ' Booking.');
//            }
//        }
        $apptDet['code'] = "wudvifv";
        $finalAmount = 28;
        $apptDet['slave_id']['slaveId'] = 158;
        $apptDet['_id'] = 5942;

        if ($apptDet['code'] != '') {
            $promodata = array(
                'buildAmount' => $finalAmount,
                'UserId' => $apptDet['slave_id']['slaveId'],
                'bookingId' => $apptDet['_id'],
                'ent_coupon' => $apptDet['code'],
            );

//            $this->mongo->selectCollection('testingData')->insert($promodata);

            $Refferal = new campaign();
            $response = $Refferal->getPromoProfit($promodata);

            if ($response['Type'] == 1) {
                $discount = $response['discount'];
                $discountedFare = ($finalAmount - $response['discount']);
                $finalAmountafterdiscount = ($discountedFare > 0 ? $discountedFare : 0);
            }
        }
        return array('test' => $response);
        $Data = $this->mongo->selectCollection('campaindata')->findOne(array('_id' => new MongoId('585e32d5c79152cd538b456b')));
        $returnData = $Data['res']; // $this->mongo->selectCollection('campaindata')->findOne(array('_id' => new MongoId('585e32d5c79152cd538b456b')));
        if ($returnData["Type"] == "PROMO") {

            $mail = new sendAMail(APP_SERVER_HOST);
            $echo = 3;
//            if (!is_null($returnData['referrer'])) {
//                $echo = 1;
//                $mailArr[] = $mail->discountOnFriendSignup($returnData['referrer']['userEmail'], $returnData['referrer']['userName'], array('code' => $returnData['referrer']['coupon_code'], 'discountData' => $returnData['referrer'], 'uname' => $returnData['referred']['userName'])); //$couponId
//            }
            if (is_array($returnData['referred'])) {
                $echo = 2;
                $mailArr = $mail->sendDiscountCoupon(
                        $returnData['referred']['userEmail'], $returnData['referred']['userName'], $returnData['referred']); //$couponId
            }
//             $this->mongo->selectCollection('campaindata')->insert(array('mail' => $mailArr, 'res' => $returnData));
        }
        return array('mail' => $mailArr, 'echo' => $returnData['referrerd']);
    }

    /*
     * Method name: slaveLogin
     * Desc: Passenger login on the app
     * Input: Request data
     * Output:  Success flag with data array if completed successfully, else data array with error flag
     */

    protected function slaveLogin($args) {
        if ($args['ent_password'] == '')
            return $this->_getStatusMessage(1, 'Password');
        else if ($args['ent_dev_id'] == '')
            return $this->_getStatusMessage(1, 'Device id');
        else if ($args['ent_device_type'] == '')
            return $this->_getStatusMessage(1, 'Device type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

//        $this->curr_date_time = urldecode($args['ent_date_time']);
//        $notifications = $this->mongo->selectCollection('notifications');
//
//        $notifications->insert(array('args' => $args));

        $devTypeNameArr = $this->_getDeviceTypeName($args['ent_device_type']);

        if (!$devTypeNameArr['flag'])
            return $this->_getStatusMessage(4, 108);

        $carTypes = $this->getWorkplaceTypes($args['ent_city'], $args['ent_latitude'], $args['ent_longitude']);

        if ($args['ent_login_type'] == '2' || $args['ent_login_type'] == '3') {
            $searchPassengerQry = "select MD5('" . $args['ent_password'] . "') as given_password,p.coupon as coupon_id,p.password,p.slave_id,p.paypal_token as paypal,p.profile_pic,p.first_name,p.last_name,p.created_dt,p.status,p.stripe_id from slave p where p.password = MD5('" . $args['ent_password'] . "') and p.ThirdPartyLoginType in (2,3)";
            $searchPassengerRes = mysql_query($searchPassengerQry, $this->db->conn);
        } else {
            $searchPassengerQry = "select MD5('" . $args['ent_password'] . "') as given_password,p.coupon as coupon_id,p.password,p.slave_id,p.paypal_token as paypal,p.profile_pic,p.first_name,p.last_name,p.created_dt,p.status,p.stripe_id from slave p where ( p.email = '" . $args['ent_email'] . "' or p.phone = '" . $args['ent_email'] . "'  )";
            $searchPassengerRes = mysql_query($searchPassengerQry, $this->db->conn);
        }
        if (mysql_num_rows($searchPassengerRes) <= 0)
            return $this->_getStatusMessage(8, $searchPassengerQry); //_getStatusMessage($errNo, $test_num);

        $passengerRow = mysql_fetch_assoc($searchPassengerRes);


        if ($passengerRow['password'] !== $passengerRow['given_password'] && !($args['ent_login_type'] == '2' || $args['ent_login_type'] == '3'))
            return $this->_getStatusMessage(117, 18); //_getStatusMessage($errNo, $test_num);

        if ($passengerRow['status'] == '1' || $passengerRow['status'] == '4')
            return $this->_getStatusMessage(94, 18); //_getStatusMessage($errNo, $test_num);

        $cardsArr = array();

        $getToken = "select * from cardMapping where slave_id ='" . $passengerRow['slave_id'] . "'";
        $getCardRes = mysql_query($getToken, $this->db->conn);
        while ($c = mysql_fetch_assoc($getCardRes)) {
            $cardsArr[] = array('id' => $c['token'], 'last4' => $c['lastDegit'], 'type' => $c['type'], 'exp_month' => substr($c['expiryDate'], -2), 'exp_year' => substr($c['expiryDate'], 2));
        }


        $couponId = $passengerRow['coupon_id'];


        if ($couponId == '') {
            $couponsColl = $this->mongo->selectCollection('coupons');

            $cond = array(
                'geoNear' => 'coupons',
                'near' => array(
                    (double) $args['ent_longitude'], (double) $args['ent_latitude']
                ), 'spherical' => true, 'maxDistance' => 100000 / 6378137, 'distanceMultiplier' => 6378137,
                'query' => array('status' => 0, 'coupon_code' => 'REFERRAL'));

//            return $couponsColl->findOne(array('coupon_code'=> 'REFERRAL'));

            $resultArr = $this->mongo->selectCollection('$cmd')->findOne($cond);

            if (count($resultArr['results']) > 0) {

                $referralData = $resultArr['results'][0]['obj'];

                $coupon = $this->_createCoupon($couponsColl);

                $insertReferralArr = array(
                    "coupon_code" => $coupon,
                    "coupon_type" => 1,
                    "start_date" => time(),
                    "expiry_date" => time() + (10 * 365 * 24 * 60 * 60),
                    "discount_type" => $referralData['discount_type'],
                    "discount" => $referralData['discount'],
                    "referral_discount_type" => $referralData['referral_discount_type'],
                    "referral_discount" => $referralData['referral_discount'],
                    "message" => $referralData['message'],
                    "status" => 0,
                    "city_id" => $referralData['city_id'],
                    "location" => $referralData['location'],
                    "user_type" => 1,
                    "user_id" => $passengerRow['slave_id']
                );

                $data = array('referral_code' => $coupon, 'slave_id' => $passengerRow['slave_id'], 'email' => $args['ent_email'], 'fname' => $passengerRow['first_name']);

                $couponsColl->update(array('_id' => $referralData['_id']), array('$push' => array('signups' => $data)));

                $couponsColl->insert($insertReferralArr);

//echo $insertCouponQry;
                if ($insertReferralArr['_id'] > 0) {
//                    $referralCode = array('code' => $coupon, 'referralData' => $referralData);
                    $couponId = $coupon;

                    $updateCouponQry = "update slave set coupon = '" . $coupon . "' where slave_id = '" . $passengerRow['slave_id'] . "'";
                    mysql_query($updateCouponQry, $this->db->conn);
                }
            }
        }



        $updateCouponQry = "update slave set latitude = '" . $args['ent_latitude'] . "',longitude = '" . $args['ent_longitude'] . "' where slave_id = '" . $passengerRow['slave_id'] . "'";
        mysql_query($updateCouponQry, $this->db->conn);

        $sessDet = $this->_checkSession($args, $passengerRow['slave_id'], '2', $devTypeNameArr['name']); //_checkSession($args, $oid, $user_type);

        if ($args['ent_push_token'] == '')
            $errMsgArr = $this->_getStatusMessage(115, 8);
        else
            $errMsgArr = $this->_getStatusMessage(9, 8);


        $ClientmapKey = And_ClientmapKey;
        $ClientPlaceKey = And_ClientPlaceKey;
        if ($args['ent_device_type'] == 1) {
            $ClientmapKey = Ios_ClientmapKey;
            $ClientPlaceKey = Ios_ClientPlaceKey;
        }

        $balnace = $this->GetWalletMoney(array('ent_sid' => $this->User['entityId']));
        return array(
            'errNum' => $errMsgArr['errNum'],
            'errFlag' => $errMsgArr['errFlag'],
            'errMsg' => $errMsgArr['errMsg'],
            'coupon' => $couponId,
            'walletAmt' => $balnace['amount'],
            'presenseChn' => presenseChn,
            'stipeKey' => stipeKeyForApp,
            'ClientPlaceKey' => $ClientPlaceKey,
            'sid' => $passengerRow['slave_id'],
            'token' => $sessDet['Token'],
            'name' => $passengerRow['first_name'] . ' ' . $passengerRow['last_name'],
            'email' => $args['ent_email'],
            'profilePic' => ($passengerRow['profile_pic'] == '') ? $this->default_profile_pic : $passengerRow['profile_pic'],
            'cards' => $cardsArr,
            'types' => $carTypes,
            'serverChn' => APP_PUBNUB_CHANNEL,
            'Languages' => $this->getLangueage(),
            'chn' => 'qp_' . $args['ent_dev_id'],
            'PaymentUrl' => $this->Payfort . $this->encrypt_decrypt('encrypt', $passengerRow['slave_id']),
            'pub' => PUBNUB_PUBLISH_KEY, 'sub' => PUBNUB_SUBSCRIBE_KEY);
    }

    /*
     * Method name: uploadImage
     * Desc: Uploads media to the server folder named "pics"
     * Input: Request data
     * Output:  image name if uploaded and status message according to the result
     */

    protected function uploadImage($args) {

        if ($args['ent_sess_token'] == '')
            return $this->_getStatusMessage(1, 'Session token');
        else if ($args['ent_dev_id'] == '')
            return $this->_getStatusMessage(1, 'Device id');
        else if ($args['ent_snap_name'] == '')
            return $this->_getStatusMessage(1, 'Snap name');
        else if ($args['ent_snap_type'] == '')
            return $this->_getStatusMessage(1, 'Snap type');
        else if ($args['ent_snap_chunk'] == '')
            return $this->_getStatusMessage(1, 'Chunk');
        else if ($args['ent_upld_from'] == '')
            return $this->_getStatusMessage(1, 'Upload from');
        else if ($args['ent_offset'] == '')
            return $this->_getStatusMessage(1, 'Offset');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $valid_exts = array("jpg", "jpeg", "gif", "png");
// Select the extension from the file.
        $ext = end(explode(".", strtolower(trim($args['ent_snap_name']))));

        if (!in_array($ext, $valid_exts))
            return $this->_getStatusMessage(26, 12);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_upld_from'], '1');

        if (is_array($returned))
            return $returned;

        if (filter_var($args['ent_snap_chunk'], FILTER_VALIDATE_URL)) {
            $args['ent_snap_chunk'] = base64_encode(file_get_contents($args['ent_snap_chunk']));
        }

        if ($args['ent_upld_from'] == '1') {
            $table = 'master';
            $field = 'mas_id';
        } else {
            $table = 'slave';
            $field = 'slave_id';
        }

        $file_to_open = 'pics/' . $args['ent_snap_name'];

//        echo '<img src="data:image/jpg;base64,'.$args['ent_snap_chunk'].'" />';

        $newphrase_plus = str_replace('-', '+', $args['ent_snap_chunk']);
        $newphrase = str_replace('_', '/', $newphrase_plus);



        $base64_de = base64_decode($newphrase); //base64_decode($media_chunk);

        if (strlen($base64_de) > $this->maxChunkSize)
            return $this->_getStatusMessage(18, 205);

        $handle = fopen($file_to_open, 'a');
        $fwrite = fwrite($handle, $base64_de);
        fclose($handle);

        if ($fwrite === false)
            return $this->_getStatusMessage(19, 224);
        else if ($args['ent_snap_type'] == '1')
            mysql_query("update $table set profile_pic = '" . $args['ent_snap_name'] . "' where $field = '" . $this->User['entityId'] . "'", $this->db->conn);

        $file_size = filesize($file_to_open);
        $number_of_chunks = ceil($file_size / $this->maxChunkSize);

        if ((int) $args['ent_offset'] == $number_of_chunks) {

            if ($args['ent_upld_from'] == '1' && $args['ent_snap_type'] == '2') {
                mysql_query("insert into images(mas_id,image) values ('" . $this->User['entityId'] . "','" . $args['ent_snap_name'] . "')", $this->db->conn);
            }

            if ($args['ent_snap_type'] == '1' && $args['ent_upld_from'] == '1') {
                $location = $this->mongo->selectCollection('location');

                $newdata = array('$set' => array("image" => $args['ent_snap_name']));
                $location->update(array("user" => (int) $this->User['entityId']), $newdata);
            }

            list($width, $height) = getimagesize($file_to_open);

            $ratio = $height / $width;

            /* mdpi 36*36 */
            $mdpi_nw = 36;
            $mdpi_nh = $ratio * 36;

            $mtmp = imagecreatetruecolor($mdpi_nw, $mdpi_nh);

            $mdpi_image = imagecreatefromjpeg($file_to_open);

            imagecopyresampled($mtmp, $mdpi_image, 0, 0, 0, 0, $mdpi_nw, $mdpi_nh, $width, $height);

            $mdpi_file = 'pics/mdpi/' . $args['ent_snap_name'];

            imagejpeg($mtmp, $mdpi_file, 100);

            /* HDPI Image creation 55*55 */
            $hdpi_nw = 55;
            $hdpi_nh = $ratio * 55;

            $tmp = imagecreatetruecolor($hdpi_nw, $hdpi_nh);

            $hdpi_image = imagecreatefromjpeg($file_to_open);

            imagecopyresampled($tmp, $hdpi_image, 0, 0, 0, 0, $hdpi_nw, $hdpi_nh, $width, $height);

            $hdpi_file = 'pics/hdpi/' . $args['ent_snap_name'];

            imagejpeg($tmp, $hdpi_file, 100);

            /* XHDPI 84*84 */
            $xhdpi_nw = 84;
            $xhdpi_nh = $ratio * 84;

            $xtmp = imagecreatetruecolor($xhdpi_nw, $xhdpi_nh);

            $xhdpi_image = imagecreatefromjpeg($file_to_open);

            imagecopyresampled($xtmp, $xhdpi_image, 0, 0, 0, 0, $xhdpi_nw, $xhdpi_nh, $width, $height);

            $xhdpi_file = 'pics/xhdpi/' . $args['ent_snap_name'];

            imagejpeg($xtmp, $xhdpi_file, 100);

            /* xXHDPI 125*125 */
            $xxhdpi_nw = 125;
            $xxhdpi_nh = $ratio * 125;

            $xxtmp = imagecreatetruecolor($xxhdpi_nw, $xxhdpi_nh);

            $xxhdpi_image = imagecreatefromjpeg($file_to_open);

            imagecopyresampled($xxtmp, $xxhdpi_image, 0, 0, 0, 0, $xxhdpi_nw, $xxhdpi_nh, $width, $height);

            $xxhdpi_file = 'pics/xxhdpi/' . $args['ent_snap_name'];

            imagejpeg($xxtmp, $xxhdpi_file, 100);

//            $serverUpload[] = $this->_serverUpload(array('file_name' => $file_to_open));
//            $serverUpload[] = $this->_serverUpload(array('file_name' => $mdpi_file));
//            $serverUpload[] = $this->_serverUpload(array('file_name' => $hdpi_file));
//            $serverUpload[] = $this->_serverUpload(array('file_name' => $xhdpi_file));
//            $serverUpload[] = $this->_serverUpload(array('file_name' => $xxhdpi_file));
        }

        $errMsgArr = $this->_getStatusMessage(17, 122);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'data' => array('picURL' => $file_to_open, 'writeFlag' => $fwrite, 'serverUploadRes' => $serverUpload));
    }

    protected function _serverUpload($args) {
        $local_directory = dirname(__FILE__);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_URL, $this->serverUploader);
        //most importent curl assues @filed as file field
//        echo $local_directory;
        $post_array = array(
            "my_file" => "@" . $local_directory . '/' . $args['file_name'],
            "upload" => "Upload",
            "dir_to_upload" => $args['file_name']
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_array);
        $response = curl_exec($ch);
        return $response;
    }

    /*
     * Method name: getMasters
     * Desc: Get masters around an area
     * Input: Request data
     * Output:  master location if available and status message according to the result
     */

    protected function getMasters($args) {

        if ($args['ent_api_key'] == '')
            return $this->_getStatusMessage(1, 'Api key');
        else if ($args['ent_latitude'] == '' || $args['ent_longitude'] == '')
            return $this->_getStatusMessage(1, 'Location');
        else if ($args['ent_search_type'] == '')
            return $this->_getStatusMessage(1, 'Search type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        if ($args['ent_api_key'] != '2ee51574176b15c2e')
            return $this->_getStatusMessage(1, 'Api key');

        $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
            'geoNear' => 'location',
            'near' => array(
                (double) $args['ent_longitude'], (double) $args['ent_latitude']
            ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137,
            'query' => array('status' => 3, 'type' => (int) $args['ent_search_type']))
        );

        $md_arr = $nurse_arr = array();
//                    
        foreach ($resultArr['results'] as $res) {
            $doc = $res['obj'];
            $md_arr[] = array("name" => $doc["name"], 'lname' => $doc['lname'], "image" => $doc['image'], "rating" => (float) $doc['rating'],
                'email' => $doc['email'], 'lat' => $doc['location']['latitude'], 'lon' => $doc['location']['longitude'], 'dis' => number_format((float) $res['dis'] / $this->distanceMetersByUnits, 2, '.', ''));
        }


        if (count($md_arr) > 0 || count($nurse_arr) > 0)
            return array('errNum' => "101", 'errFlag' => 0, 'errMsg' => "Drivers found!", 'docs' => $md_arr, 'nurses' => $nurse_arr, 'test' => $args['ent_search_type']);

        return array('errNum' => "102", 'errFlag' => 1, 'errMsg' => "Drivers not found!", 'test' => $resultArr);
    }

    /*
     * Method name: getMasterDetails
     * Desc: Server sends the master details according to the email id that is sent by the client
     * Input: Request data
     * Output:  driver data if available and status message according to the result
     */

    protected function getMasterDetails($args) {

        if ($args['ent_dri_email'] == '')
            return $this->_getStatusMessage(1, 'Driver email');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $getDetailsQry = "select doc.mas_id,doc.first_name,doc.last_name,doc.mobile,doc.about,doc.profile_pic,doc.last_active_dt,doc.expertise,";
        $getDetailsQry .= "(select avg(star_rating) from master_ratings where mas_id = doc.mas_id) as rating,";
        $getDetailsQry .= "(select group_concat(image) from images where mas_id = doc.mas_id) as images ";
        $getDetailsQry .= "from master doc where doc.email = '" . $args['ent_dri_email'] . "'";
        $getDetailsRes = mysql_query($getDetailsQry, $this->db->conn);

        if (mysql_error($this->db->conn) != '')
            return $this->_getStatusMessage(3, $getDetailsQry); //_getStatusMessage($errNo, $test_num);

        $num_rows = mysql_num_rows($getDetailsRes);

        if ($num_rows <= 0)
            return $this->_getStatusMessage(20, $getDetailsQry); //_getStatusMessage($errNo, $test_num);

        $doc_data = mysql_fetch_assoc($getDetailsRes);

        $reviewsArr = $this->_getMasterReviews($args);

        if (!isset($reviewsArr[0]['rating']))
            $reviewsArr = array();

        $eduArr = array();

        $getEducationQry = "select edu.degree,edu.start_year,edu.end_year,edu.institute from master_education edu,master doc where doc.mas_id = edu.mas_id and doc.email = '" . $args['ent_dri_email'] . "'";
        $getEducationRes = mysql_query($getEducationQry, $this->db->conn);

        while ($edu = mysql_fetch_assoc($getEducationRes)) {
            $eduArr[] = array('deg' => $edu['degree'], 'start' => $edu['start_year'], 'end' => $edu['end_year'], 'inst' => $edu['institute']);
        }

        $errMsgArr = $this->_getStatusMessage(21, 122);

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'],
            'fName' => $doc_data['first_name'], 'lName' => $doc_data['last_name'], 'mobile' => $doc_data['mobile'], 'pPic' => $doc_data['profile_pic'], 'about' => ($doc_data['about'] == '' ? ' ' : $doc_data['about']), 'expertise' => $doc_data['expertise'],
            'ladt' => $doc_data['last_active_dt'], 'rating' => (float) $doc_data['rating'], 'images' => explode(',', $doc_data['images']), 'totalRev' => $reviewsArr[0]['total'], 'reviews' => $reviewsArr, 'education' => $eduArr);
    }

    // check password

    protected function checkPassword($args) {

        if ($args['ent_password'] == '') {
            return $this->_getStatusMessage(1, 'password ');
        } else if ($args['ent_sid'] == '') {
            return $this->_getStatusMessage(1, 'id');
        }

        $searchPassengerQry = "select MD5('" . $args['ent_password'] . "') as given_password from slave p where p.slave_id  = '" . $args['ent_sid'] . "' and p.password = MD5('" . $args['ent_password'] . "') ";
        $searchPassengerRes = mysql_query($searchPassengerQry, $this->db->conn);

        if (mysql_num_rows($searchPassengerRes) <= 0)
            return $this->_getStatusMessage(8, $searchPassengerQry);

        return $this->_getStatusMessage(21);
    }

    /*
     * Method name: updateMasterLocation
     * Desc: Update master location
     * Input: Request data
     * Output:  success if changed else error according to the result
     */

    protected function updateMasterLocation($args) {

        if ($args['ent_latitude'] == '' || $args['ent_longitude'] == '')
            return $this->_getStatusMessage(1, 'Location');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $location = $this->mongo->selectCollection('location');

        $newdata = array('$set' => array("location" => array("longitude" => (float) $args['ent_longitude'], "latitude" => (float) $args['ent_latitude'])));
        $updated = $location->update(array("user" => (int) $this->User['entityId']), $newdata);

        if ($updated)
            return $this->_getStatusMessage(23, 2);
        else
            return $this->_getStatusMessage(22, 3);
    }

    /*
     * Method name: getMasterReviews
     * Desc: Get driver reviews by pagination
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function getMasterReviews($args) {

        if ($args['ent_dri_email'] == '')
            return $this->_getStatusMessage(1, 'Driver email');
        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $reviewsArr = $this->_getMasterReviews($args);

        if (!isset($reviewsArr[0]['rating']))
            return $reviewsArr;

        $errMsgArr = $this->_getStatusMessage(27, 122);

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'reviews' => $reviewsArr);
    }

    /*
     * Method name: getMasterAppointments
     * Desc: Get Driver appointments
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function getMasterAppointments($args) {

        if ($args['ent_appnt_dt'] == '')
            return $this->_getStatusMessage(1, 'Booking date time');
        else if ($args['ent_appnt_dt'] == '')
            return $this->_getStatusMessage(1, 'Date time');

//        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $args['ent_appnt_dt'] = urldecode($args['ent_appnt_dt']);

        $dates = explode('-', $args['ent_appnt_dt']);

        if (count($dates) == 3) {
            $endDate = (int) strtotime('+7 day', strtotime($args['ent_appnt_dt']));
//            $selectStr = " DATE(a.appointment_dt) between '" . $args['ent_appnt_dt'] . "' and '" . $endDate . "'";
            $startdate = (int) strtotime($args['ent_appnt_dt']);
        } else {
            $startdate = (int) strtotime($args['ent_appnt_dt'] . '-01');
            $endDate = (int) strtotime('+1 month', strtotime($args['ent_appnt_dt']));
//            $selectStr = " YEAR(a.appointment_dt) = '" . (int) $dates[0] . "' and MONTH(a.appointment_dt) = '" . (int) $dates[1] . "'";
        }


//        appointment_dt

        $appointmentsCur = $this->mongo->selectCollection('appointments');
        $apptDetaos = $appointmentsCur->find(array("status" => array('$in' => [9, 3]), 'mas_id' => (int) $this->User['entityId'], 'timpeStamp_appointment_dt' => array(
                        '$gte' => $startdate,
                        '$lte' => $endDate
            )))->sort(array('_id' => -1));
//        $apptDetaos = $appointmentsCur->find(array('BOOKING.$.DriverId' =>  $this->User['entityId']));


        $appointments = $daysArr = array();

        $pendingCount = 0;

        foreach ($apptDetaos as $appnt) {

            if ($appnt['profile_pic'] == '')
                $appnt['profile_pic'] = $this->default_profile_pic;

            $pendingCount = $appnt['pen_count'];

            $aptdate = date('Y-m-d', strtotime($appnt['appointment_dt']));

            if ($appnt['status'] == '6')
                $status = 'Driver is on the way.';
            else if ($appnt['status'] == '7')
                $status = 'Driver arrived.';
            else if ($appnt['status'] == '8')
                $status = 'Booking started.';
            else if ($appnt['status'] == '9')
                $status = 'Booking completed.';
            else
                $status = 'Status unavailable.';

            $appointments[$aptdate][] = array(
                'distance' => $appnt['invoice'][0]['TripDistance'],
                'duration' => ($appnt['invoice'][0]['TripTime'] == "" ? 0 : $appnt['invoice'][0]['TripTime']),
                'addrLine1' => $appnt['appointment_address'],
                'dropLine1' => $appnt['Drop_address'],
                'Dispute' => 0,
                'base_fare' => $appnt['invoice'][0]['baseFare'],
                'DistanceFee' => $appnt['invoice'][0]['TripDistanceFee'],
                'discountVal' => $appnt['invoice'][0]['discountVal'],
                'TimeFee' => $appnt['invoice'][0]['TripTimeFee'],
                'waitingTime' => $appnt['invoice'][0]['waitingTime'],
                'waitingTimeFee' => $appnt['invoice'][0]['waitingTimeFee'],
                'tripamount' => $appnt['invoice'][0]['tripamount'],
                'mas_earning' => $appnt['invoice'][0]['mas_earning'],
                'cashCollected' => $appnt['invoice'][0]['cashCollected'],
                'airport_fee' => $appnt['invoice'][0]['airportFee'],
                'tip_amount' => $appnt['invoice'][0]['tip'],
                'appCommision' => $appnt['invoice'][0]['app_commission'],
                'min_fare' => $appnt['vehicleType']['minmunfare'],
                'amount' => round($appnt['invoice'][0]['amount'], 2),
                'apntTime' => $appnt['appointment_dt'],
                'bid' => $appnt['_id'],
                'status' => $appnt['status'],
                'fname' => $appnt['slave_id']['SlaveName'],
                'PayMentType' => $appnt['PayMentType'],
                'ServiceFee' => $appnt['invoice'][0]['ServiceFee'],
                'subtotal' => round($appnt['invoice'][0]['subtotal'], 2)
            );
        }
        $refIndexes = $sortedApnts = array();
        $date = date('Y-m-d', strtotime($args['ent_appnt_dt']));
        $enddate_ = date('Y-m-d', $endDate);
        while ($date < $enddate_) {
            $empty_arr = array();

            if (is_array($appointments[$date])) {
                $sortedApnts[] = array('date' => $date, 'appt' => $appointments[$date]);
                $num = date('j', strtotime($date));
                $refIndexes[] = $num;
            } else {
                $sortedApnts[] = array('date' => $date, 'appt' => $empty_arr);
            }

            $date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
        }

        $errMsgArr = $this->_getStatusMessage(31, 2);

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'appointments' => $sortedApnts); //,'test'=>$selectAppntsQry,'test1'=>$appointments);
    }

    /*
     * Method name: getPendingAppointments
     * Desc: Get Driver appointments
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function getPendingAppts($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

//        $curr_date = date('Y-m-d H:i:s', time());
//        $curr_date_bfr_30min = date('Y-m-d H:i:s', time() - 1800);
//        $curr_date_bfr_1hr = date('Y-m-d H:i:s', time() - 3600);


        $selectAppntsQry = "select p.profile_pic,p.first_name,p.phone,p.email,a.appt_lat,a.appt_long,a.appointment_dt,a.appointment_id,a.drop_addr2,a.drop_addr1,a.extra_notes,a.address_line1,a.address_line2,a.status,a.appt_type from appointment a, slave p ";
        $selectAppntsQry .= " where p.slave_id = a.slave_id and a.status = 2 and a.appt_type = 2 and a.mas_id = '" . $this->User['entityId'] . "' order by a.appointment_dt DESC"; // and a.appointment_dt >= '" . $curr_date_bfr_1hr . "'

        $selectAppntsRes = mysql_query($selectAppntsQry, $this->db->conn);

        if (mysql_num_rows($selectAppntsRes) <= 0)
            return $this->_getStatusMessage(30, $selectAppntsQry);

        $pending_appt = array();

        while ($appnt = mysql_fetch_assoc($selectAppntsRes)) {

            if ($appnt['profile_pic'] == '')
                $appnt['profile_pic'] = $this->default_profile_pic;

            $pending_appt[date('Y-m-d', strtotime($appnt['appointment_dt']))][] = array('apntDt' => $appnt['appointment_dt'], 'pPic' => $appnt['profile_pic'], 'email' => $appnt['email'], 'bid' => $appnt['appointment_id'],
                'fname' => $appnt['first_name'], 'phone' => $appnt['phone'], 'apntTime' => date('H:i', strtotime($appnt['appointment_dt'])), 'dropLine1' => urldecode($appnt['drop_addr1']), 'dropLine2' => urldecode($appnt['drop_addr2']),
                'apntDate' => date('Y-m-d', strtotime($appnt['appointment_dt'])), 'apptLat' => (double) $appnt['appt_lat'], 'apptLong' => (double) $appnt['appt_long'],
                'addrLine1' => urldecode($appnt['address_line1']), 'addrLine2' => urldecode($appnt['address_line2']), 'notes' => $appnt['extra_notes'], 'bookType' => $appnt['booking_type']);
        }

        $finalArr = array();

        foreach ($pending_appt as $date => $penAppt) {
            $finalArr[] = array('date' => $date, 'appt' => $penAppt);
        }

        $errMsgArr = $this->_getStatusMessage(31, 2);

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'appointments' => $finalArr); //,'test'=>$selectAppntsQry,'test1'=>$appointments);
    }

    /*
     * Method name: getPendingAppointments
     * Desc: Get Driver appointments
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function getPendingAppointments($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

//        $curr_date = date('Y-m-d H:i:s', time());
//        $curr_date_bfr_30min = date('Y-m-d H:i:s', time() - 1800);
//        $curr_date_bfr_1hr = date('Y-m-d H:i:s', time() - 3600);


        $selectAppntsQry = "select p.profile_pic,p.first_name,p.phone,p.email,a.appt_lat,a.appt_long,a.appointment_dt,a.extra_notes,a.address_line1,a.address_line2,a.status,a.booking_type from appointment a, slave p ";
        $selectAppntsQry .= " where p.slave_id = a.slave_id and a.status = 1 and a.mas_id = '" . $this->User['entityId'] . "' order by a.appointment_dt DESC"; // and a.appointment_dt >= '" . $curr_date_bfr_1hr . "'

        $selectAppntsRes = mysql_query($selectAppntsQry, $this->db->conn);

        if (mysql_num_rows($selectAppntsRes) <= 0)
            return $this->_getStatusMessage(30, $selectAppntsQry);

        $pending_appt = array();

        while ($appnt = mysql_fetch_assoc($selectAppntsRes)) {

            if ($appnt['profile_pic'] == '')
                $appnt['profile_pic'] = $this->default_profile_pic;

            $pending_appt[] = array('apntDt' => $appnt['appointment_dt'], 'pPic' => $appnt['profile_pic'], 'email' => $appnt['email'],
                'fname' => $appnt['first_name'], 'phone' => $appnt['phone'], 'apntTime' => date('H:i', strtotime($appnt['appointment_dt'])),
                'apntDate' => date('Y-m-d', strtotime($appnt['appointment_dt'])), 'apptLat' => (double) $appnt['appt_lat'], 'apptLong' => (double) $appnt['appt_long'],
                'addrLine1' => urldecode($appnt['address_line1']), 'addrLine2' => urldecode($appnt['address_line2']), 'notes' => $appnt['extra_notes'], 'bookType' => $appnt['booking_type']);
        }


        $errMsgArr = $this->_getStatusMessage(31, 2);

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'appointments' => $pending_appt); //,'test'=>$selectAppntsQry,'test1'=>$appointments);
    }

    function getMasterTripDetails($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $explodeDateTime = explode(' ', $this->curr_date_time);
        $explodeDate = explode('-', $explodeDateTime[0]);

        $weekData = $this->week_start_end_by_date($this->curr_date_time);

        $query = "select distinct (select sum(mas_earning) from appointment where mas_id =mas.mas_id and payment_type = 2 ) as DriverCashEarning,"
                . "(select sum(mas_earning) from appointment where mas_id =mas.mas_id and payment_type = 1 ) as DriverCardEarning,"
                . "(select sum(mas_earning) from appointment where mas_id =mas.mas_id) as DriverTotalEarning,"
                . "(select sum(amount) from appointment where mas_id =mas.mas_id and payment_type = 2 and status = 9) as DriverCashColleted,"
                . "COALESCE((SELECT SUM(mas_earning) FROM appointment WHERE  mas_id = mas.mas_id   AND  STATUS = 9) - (SELECT SUM(amount) FROM appointment WHERE   mas_id = mas.mas_id  and payment_type = 2 and status = 9) - (SELECT COALESCE( SUM(pay_amount) ,0) FROM payroll WHERE mas_id = mas.mas_id ),0) AS pending,"
                . "COALESCE((SELECT SUM(mas_earning) FROM appointment WHERE payment_type = 2 AND mas_id = mas.mas_id  AND  STATUS = 9) - (SELECT SUM(app_owner_pl) FROM appointment WHERE payment_type = 1 AND mas_id =mas.mas_id  AND STATUS = 9),0) AS DriverToPay,"
                . "(select pay_date from payroll where mas_id= mas.mas_id order by payroll_id DESC limit 1) as pay_date,"
                . "(SELECT SUM(pay_amount) FROM payroll WHERE mas_id = mas.mas_id) as TOTALRECIVED,"
                . "(select pay_amount from payroll where mas_id= mas.mas_id order by payroll_id DESC limit  1) as pay_amount,"
                . "(select count(appointment_id) from appointment where mas_id = mas.mas_id and DATE(appointment_dt) = '" . $explodeDateTime[0] . "' and status = 9) as cmpltApts_toady,"
                . "(select count(appointment_id) from appointment where mas_id = mas.mas_id and DATE(appointment_dt) BETWEEN '" . $weekData['first_day_of_week'] . "' and '" . $weekData['last_day_of_week'] . "' and status = 9) as cmpltApts_week,"
                . "(select count(appointment_id) from appointment where mas_id = mas.mas_id and DATE_FORMAT(appointment_dt, '%Y-%m') = '" . $explodeDate[0] . '-' . $explodeDate[1] . "' and status = 9) as cmpltApts_month,"
                . "(select sum(mas_earning) from appointment where mas_id = mas.mas_id and DATE(appointment_dt) = '" . $explodeDateTime[0] . "' and status = 9) as toadys_earning,"
                . "(select count(appointment_id) from appointment where mas_id = mas.mas_id and DATE(appointment_dt) = '" . $explodeDateTime[0] . "' and status = 4) as canceled_toadys,"
                . "(select sum(mas_earning) from appointment where mas_id = mas.mas_id and status = 9 and DATE(appointment_dt) BETWEEN '" . $weekData['first_day_of_week'] . "' and '" . $weekData['last_day_of_week'] . "') as week_earnings,"
                . "(select count(appointment_id) from appointment where mas_id = mas.mas_id and status = 4 and DATE(appointment_dt) BETWEEN '" . $weekData['first_day_of_week'] . "' and '" . $weekData['last_day_of_week'] . "') as canceled_week,"
                . "(select sum(mas_earning) from appointment where mas_id = mas.mas_id and status = 9 and DATE_FORMAT(appointment_dt, '%Y-%m') = '" . $explodeDate[0] . '-' . $explodeDate[1] . "') as month_earnings,"
                . "(select count(appointment_id) from appointment where mas_id = mas.mas_id and status = 4 and DATE_FORMAT(appointment_dt, '%Y-%m') = '" . $explodeDate[0] . '-' . $explodeDate[1] . "') as canceld_month "
                . "from appointment mas where mas.mas_id = '" . $this->User['entityId'] . "'";
//       return array('query' => $query);

        $getAnalytics = mysql_query($query, $this->db->conn);
        $PaymentLocs = $tripdata = array();

        if (mysql_num_rows($getAnalytics) > 0) {
            $errMsgArr = $this->_getStatusMessage(21, 2);
        } else {
            $errMsgArr = $this->_getStatusMessage(3, 2);
        }

        $getRowData = mysql_fetch_assoc($getAnalytics);


        $PaymentLocs['DriverCashEarning'] = $getRowData['DriverCashEarning'];
        $PaymentLocs['DriverCardEarning'] = $getRowData['DriverCardEarning'];
        $PaymentLocs['DriverTotalEarning'] = $getRowData['DriverTotalEarning'];
        $PaymentLocs['DriverCashColleted'] = $getRowData['DriverCashColleted'];
        $PaymentLocs['pending'] = $getRowData['pending'];
        $PaymentLocs['DriverToPay'] = $getRowData['DriverToPay'];
        $PaymentLocs['LastPayDate'] = $getRowData['pay_date'];
        $PaymentLocs['LastPayAmount'] = $getRowData['pay_amount'];
        $PaymentLocs['TotalDue'] = ($PaymentLocs['pending'] + ($PaymentLocs['DriverToPay']));
        $PaymentLocs['TotalReceived'] = $getRowData['TOTALRECIVED'];



        $tripdata['cmpltApts_toady'] = $getRowData['cmpltApts_toady'];
        $tripdata['cmpltApts_week'] = $getRowData['cmpltApts_week'];
        $tripdata['cmpltApts_month'] = $getRowData['cmpltApts_month'];

        $tripdata['toadys_earning'] = $getRowData['toadys_earning'];
        $tripdata['canceled_toadys'] = $getRowData['canceled_toadys'];


        $tripdata['week_earnings'] = $getRowData['week_earnings'];
        $tripdata['canceled_week'] = $getRowData['canceled_week'];

        $tripdata['month_earnings'] = $getRowData['month_earnings'];
        $tripdata['canceld_month'] = $getRowData['canceld_month'];




        $errMsgArr = $this->_getStatusMessage(21, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'],
            'paymentLoc' => $this->makeZeroIfNull($PaymentLocs),
            'Trips' => $this->makeZeroIfNull($tripdata)
        );
    }

    function makeZeroIfNull($array) {
        $arraytosend = array();
        foreach ($array as $key => $res) {
            $arraytosend[$key] = ($res == '' ? '0' : (string) round($res, 2));
        }
        return $arraytosend;
    }

    /*
     * Method name: getHistoryWith
     * Desc: Get appointment details
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function getHistoryWith($args) {

        if ($args['ent_pas_email'] == '')
            return $this->_getStatusMessage(1, 'Passenger email');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $pageNum = (int) $args['ent_page'];

        if ($args['ent_page'] == '')
            $pageNum = 1;

        $lowerLimit = ($this->historyPageSize * $pageNum) - $this->historyPageSize;
        $upperLimit = $this->historyPageSize * $pageNum;

        $selectAppntsQry = "select a.remarks,a.appointment_dt from appointment a,slave p ";
        $selectAppntsQry .= "where a.slave_id = p.slave_id and a.mas_id = '" . $this->User['entityId'] . "' and p.email = '" . $args['ent_pas_email'] . "' ";
        $selectAppntsQry .= "limit $lowerLimit,$upperLimit";

        $selectAppntsRes = mysql_query($selectAppntsQry, $this->db->conn);

        if (mysql_num_rows($selectAppntsRes) <= 0)
            return $this->_getStatusMessage(32, 12);

        $data = array();

        while ($details = mysql_fetch_assoc($selectAppntsRes)) {
            $data[] = array('apptDt' => $details['appointment_dt'], 'remarks' => $details['remarks']);
        }

        $errMsgArr = $this->_getStatusMessage(33, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'history' => $data);
    }

    /*
     * Method name: fareCalculator
     * Desc: calculates fare for the given pick up to drop off
     * Input: Request data
     * Output: success if got it else error according to the result
     */

    protected function fareCalculator($args) {

//        $booking_data_livetrack = $this->mongo->selectCollection('farecalculator');
//        $booking_data_livetrack->insert($args);

        if ($args['ent_type_id'] == '')
            return $this->_getStatusMessage(1, 'Vehicle type');
        else if ($args['ent_from_lat'] == '' || $args['ent_from_long'] == '')
            return $this->_getStatusMessage(1, 'Pickup location');
        else if ($args['ent_to_lat'] == '' || $args['ent_to_long'] == '')
            return $this->_getStatusMessage(1, 'Drop location');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

//        $arr = array();

        $getTypeDataQry = "select * from workplace_types where type_id = '" . $args['ent_type_id'] . "'";
        $getTypeDataRes = mysql_query($getTypeDataQry, $this->db->conn);

        $typeData = mysql_fetch_assoc($getTypeDataRes);
        if (!is_array($typeData)) {
            return $this->_getStatusMessage(1, 'Vehicle type');
        }



//        $getDirectionFormMatrix = $this->get_DirectionFormMatrix($args['ent_curr_lat'], $args['ent_curr_long'], $args['ent_from_lat'], $args['ent_from_long']);
//
//        $cur_to_pick_distance_text = $getDirectionFormMatrix['distance'];


        $getDirectionFormMatrix = $this->get_DirectionFormMatrix($args['ent_from_lat'], $args['ent_from_long'], $args['ent_to_lat'], $args['ent_to_long']);

//        this above array will return below thing 
//        return array('data' => $getDirectionFormMatrix,
//            'distance' => round($getDirectionFormMatrix['distance']/$this->distanceMetersByUnits,2), 
//            'duration' => round($getDirectionFormMatrix['duration'] / 360)); // in minuts

        $distance_in_mtr = $getDirectionFormMatrix['distance'];
        $duration_in_sec = ($getDirectionFormMatrix['duration'] / 60);




        $surg_price = '';
//
//        $zonefactor = $this->mongo->selectCollection('zones')->findOne(
//                array("polygons" =>
//                    array('$geoIntersects' =>
//                        array('$geometry' =>
//                            array("type" => "Point", "coordinates" => array((double) $args['ent_from_long'], (double) $args['ent_from_lat']))
//                        )
//                    )
//                )
//        );
//
//        if (is_array($zonefactor))
//            $surg_price = (int) $zonefactor['surge_price'];



        $zonefactor = $this->mongo->selectCollection('zones')->findOne(
                array("polygons" =>
                    array('$geoIntersects' =>
                        array('$geometry' =>
                            array("type" => "Point", "coordinates" => array((double) $args['ent_from_long'], (double) $args['ent_from_lat']))
                        )
                    )
                )
        );

        if (is_array($zonefactor))
            $surg_price = (int) $zonefactor['surge_price'];
        else {
            $zonefactor_pickup = $this->mongo->selectCollection('zones')->findOne(
                    array("polygons" =>
                        array('$geoIntersects' =>
                            array('$geometry' =>
                                array("type" => "Point", "coordinates" => array((double) $args['ent_to_long'], (double) $args['ent_to_lat']))
                            )
                        )
                    )
            );
            if (is_array($zonefactor_pickup))
                $surg_price = (int) $zonefactor_pickup['surge_price'];
        }

        if ($surg_price != '') {

            $fare1 = number_format(($typeData['basefare'] + (float) (($distance_in_mtr / $this->distanceMetersByUnits) * $typeData['price_per_km']) + (float) (($duration_in_sec / 60) * $typeData['price_per_min'] ) + $surg_price), 2, '.', '');
        } else {
            $fare1 = number_format($typeData['basefare'] + (float) (($distance_in_mtr / $this->distanceMetersByUnits) * $typeData['price_per_km']) + (float) (($duration_in_sec / 60) * $typeData['price_per_min']), 2, '.', '');
        }

        $fare = ($typeData['min_fare'] < $fare1) ? $fare1 : $typeData['min_fare'];

        // return array('fare' => $fare);

        $errMsgArr = $this->_getStatusMessage(21, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'dis' => round(($distance_in_mtr / $this->distanceMetersByUnits), 1) . ' ' . APP_DISTANCE_METRIC, 'fare' => $fare, 'curDis' => round(($cur_to_pick_distance_text / $this->distanceMetersByUnits), 1) . ' ' . APP_DISTANCE_METRIC, 'surg_price' => $surg_price); // 't' => $arr, 't1' => $arr
    }

    protected function fareCalculator_($args) {

        $booking_data_livetrack = $this->mongo->selectCollection('farecalculator');
        $args = $booking_data_livetrack->findOne(array('_id' => new MongoId('57a23e5bad16f57d343fd124')));

        if ($args['ent_type_id'] == '')
            return $this->_getStatusMessage(1, 'Vehicle type');
        else if ($args['ent_from_lat'] == '' || $args['ent_from_long'] == '')
            return $this->_getStatusMessage(1, 'Pickup location');
        else if ($args['ent_to_lat'] == '' || $args['ent_to_long'] == '')
            return $this->_getStatusMessage(1, 'Drop location');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

//        $arr = array();

        $getTypeDataQry = "select * from workplace_types where type_id = '" . $args['ent_type_id'] . "'";
        $getTypeDataRes = mysql_query($getTypeDataQry, $this->db->conn);

        $typeData = mysql_fetch_assoc($getTypeDataRes);
        if (!is_array($typeData)) {
            return $this->_getStatusMessage(1, 'Vehicle type');
        }



        $getDirectionFormMatrix = $this->get_DirectionFormMatrix($args['ent_curr_lat'], $args['ent_curr_long'], $args['ent_from_lat'], $args['ent_from_long']);

        $cur_to_pick_distance_text = $getDirectionFormMatrix['distance'];


        $getDirectionFormMatrix = $this->get_DirectionFormMatrix($args['ent_from_lat'], $args['ent_from_long'], $args['ent_to_lat'], $args['ent_to_long']);

//        this above array will return below thing 
//        return array('data' => $getDirectionFormMatrix,
//            'distance' => round($getDirectionFormMatrix['distance']/$this->distanceMetersByUnits,2), 
//            'duration' => round($getDirectionFormMatrix['duration'] / 360)); // in minuts

        $distance_in_mtr = $getDirectionFormMatrix['distance'];
        $duration_in_sec = ($getDirectionFormMatrix['duration'] / 60);




//        $surg_price = '';
//
//        $zonefactor = $this->mongo->selectCollection('zones')->findOne(
//                array("polygons" =>
//                    array('$geoIntersects' =>
//                        array('$geometry' =>
//                            array("type" => "Point", "coordinates" => array((double) $args['ent_from_long'], (double) $args['ent_from_lat']))
//                        )
//                    )
//                )
//        );
//         $surg_price = 0;

        $zonefactor = $this->mongo->selectCollection('zones')->findOne(
                array("polygons" =>
                    array('$geoIntersects' =>
                        array('$geometry' =>
                            array("type" => "Point", "coordinates" => array((double) $args['ent_from_long'], (double) $args['ent_from_lat']))
                        )
                    )
                )
        );

        if (is_array($zonefactor))
            $surg_price = (int) $zonefactor['surge_price'];
        else {
            $zonefactor_pickup = $this->mongo->selectCollection('zones')->findOne(
                    array("polygons" =>
                        array('$geoIntersects' =>
                            array('$geometry' =>
                                array("type" => "Point", "coordinates" => array((double) $args['ent_to_long'], (double) $args['ent_to_lat']))
                            )
                        )
                    )
            );
            if (is_array($zonefactor_pickup))
                $surg_price = (int) $zonefactor_pickup['surge_price'];
        }




        if ($surg_price != '') {

            $fare1 = number_format(($typeData['basefare'] + (float) (($distance_in_mtr / $this->distanceMetersByUnits) * $typeData['price_per_km']) + (float) (($duration_in_sec / 60) * $typeData['price_per_min'] ) + $surg_price), 2, '.', '');
        } else {
            $fare1 = number_format($typeData['basefare'] + (float) (($distance_in_mtr / $this->distanceMetersByUnits) * $typeData['price_per_km']) + (float) (($duration_in_sec / 60) * $typeData['price_per_min']), 2, '.', '');
        }

        $fare = ($typeData['min_fare'] < $fare1) ? $fare1 : $typeData['min_fare'];

        // return array('fare' => $fare);

        $errMsgArr = $this->_getStatusMessage(21, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'dis' => round(($distance_in_mtr / $this->distanceMetersByUnits), 1) . ' ' . APP_DISTANCE_METRIC, 'fare' => $fare, 'curDis' => round(($cur_to_pick_distance_text / $this->distanceMetersByUnits), 1) . ' ' . APP_DISTANCE_METRIC, 'surg_price' => $surg_price); // 't' => $arr, 't1' => $arr
    }

    protected function get_DirectionFormMatrix($pickupLat, $pickuptLong, $dropLat, $DropLong) {


        $url = 'https://maps.googleapis.com/maps/api/distancematrix/json?origins=' . $pickupLat . ',' . $pickuptLong . '&destinations=' . $dropLat . ',' . $DropLong;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        $result = curl_exec($ch);
        $arr = json_decode($result, true);

        return array('OrignalDatadata' => $arr,
            'distance' => $arr['rows'][0]['elements'][0]['distance']['value'],
            'duration' => $arr['rows'][0]['elements'][0]['distance']['value']);
    }

    protected function gettest_DirectionFormMatrix($latlongs) {


        $url = 'https://maps.googleapis.com/maps/api/directions/json?origins=' . $latlongs;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        $result = curl_exec($ch);
        $arr = json_decode($result, true);

        return array('OrignalDatadata' => $arr, 'give' => $url,
            'distance' => $arr['rows'][0]['elements'][0]['distance']['value'],
            'duration' => $arr['rows'][0]['elements'][0]['distance']['value']);
    }

    protected function fareCalAdmin($args) {

        if ($args['ent_type_id'] == '')
            return $this->_getStatusMessage(1, 'Vehicle type');
        else if ($args['ent_from_lat'] == '' || $args['ent_from_long'] == '')
            return $this->_getStatusMessage(1, 'Pickup location');
        else if ($args['ent_to_lat'] == '' || $args['ent_to_long'] == '')
            return $this->_getStatusMessage(1, 'Drop location');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

//        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

//        $arr = array();

        $getTypeDataQry = "select * from workplace_types where type_id = '" . $args['ent_type_id'] . "'";
        $getTypeDataRes = mysql_query($getTypeDataQry, $this->db->conn);

        $cur_to_pick_arr = $this->_getDirectionsData(array('lat' => $args['ent_curr_lat'], 'long' => $args['ent_curr_long']), array('lat' => $args['ent_from_lat'], 'long' => $args['ent_from_long']));

        $cur_to_pick_distance_text = $cur_to_pick_arr['routes'][0]['legs'][0]['distance']['value'];

        $arr = $this->_getDirectionsData(array('lat' => $args['ent_from_lat'], 'long' => $args['ent_from_long']), array('lat' => $args['ent_to_lat'], 'long' => $args['ent_to_long']));

        $distance_in_mtr = $arr['routes'][0]['legs'][0]['distance']['value'];
        $duration_in_sec = $arr['routes'][0]['legs'][0]['duration']['value'];

        $typeData = mysql_fetch_assoc($getTypeDataRes);

        $fare1 = number_format($typeData['basefare'] + (float) (($distance_in_mtr / $this->distanceMetersByUnits) * $typeData['price_per_km']) + (float) (($duration_in_sec / 60) * $typeData['price_per_min']), 2, '.', '');

//        $distance_in_mts = $arr['routes'][0]['legs'][0]['distance']['value'];
//        $dis_in_km = (float) ($distance_in_mts / $this->distanceMetersByUnits);

        $calculatedAmount = $typeData['min_fare']; //(float) $dis_in_km * $typeData['price_per_km'];

        $fare = ($calculatedAmount < $fare1) ? $fare1 : $calculatedAmount;

        $errMsgArr = $this->_getStatusMessage(21, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'dis' => round(($distance_in_mtr / $this->distanceMetersByUnits), 1) . ' ' . APP_DISTANCE_METRIC, 'fare' => $fare, 'curDis' => round(($cur_to_pick_distance_text / $this->distanceMetersByUnits), 1) . ' ' . APP_DISTANCE_METRIC, 't' => $arr, 't1' => $arr);
    }

    /*
     * Method name: getApptStatus
     * Desc: Get appointment status
     * Input: nothing
     * Output:  gives status if available else error msg
     */

    protected function getApptStatus($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 15);

        $this->curr_date_time = urldecode($args['ent_date_time']);
        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_user_type']);

        if (is_array($returned))
            return $returned;



        $masStatus = $this->MongoClass->get_one("location", array('user' => (int) $this->User['entityId']));

        $getAmountQry = $this->MongoClass->aggrigation('appointments', 'BOOKING', array('$and' => array(array('BOOKING.DriverId' => (int) $this->User['entityId']), array('BOOKING.Status' => "Accepted")), "status" => array('$in' => [6, 7, 8, 2, 11])), 'NeedAllData');

        if ($getAmountQry['flag'] == '1')
            $data = array();
        else {

            if (!(($getAmountQry['status'] == '1') && ($getAmountQry['BookingRequestServerTime'][0] - (time()) <= 0))) {


                $data = array(
                    'sid' => $getAmountQry['slave_id']['slaveId'],
                    'bid' => $getAmountQry['_id'],
                    'CustomerWalletBalance' => $getAmountQry['CustomerWalletBalance'],
                    'adr2' => $getAmountQry['appointment_address'],
                    'status' => $getAmountQry['status'],
                    'additional_info' => $getAmountQry['additional_info'],
                    'pickupDistance' => $getAmountQry['pickupDistance'],
                    'lt' => $getAmountQry['appointment_location']['latitude'],
                    'lg' => $getAmountQry['appointment_location']['longitude'],
                    'DropAddress' => $getAmountQry['Drop_address'],
                    'DropLat' => $getAmountQry['Drop_location']['latitude'],
                    'DropLong' => $getAmountQry['Drop_location']['longitude'],
                    'CutomerBal' => $getAmountQry['CustomerWalletBalance'],
                    'CustomerName' => $getAmountQry['slave_id']['SlaveName'],
                    'CustomerPone' => $getAmountQry['slave_id']['SlavePone'],
                    'chn' => $getAmountQry['slave_id']['SlaveChan'],
                    'dt' => $getAmountQry['appointment_dt'],
                    'sumLastDue' => $getAmountQry['slave_id']['sumLastDue'],
                    'PayMentType' => $getAmountQry['PayMentType'],
                    'ServerTime' => time(),
                    'AcceptenceRadiou' => AcceptenceRadiou,
                    'iswallet' => $getAmountQry['wallet'],
                    'invoice' => ($getAmountQry['status'] == 11 ? $getAmountQry['invoice'] : array()),
                );
            }
        }

        if ($args['ent_user_type'] == 1) {

            $queyrDrivervehicleInfo = "select (select count(appointment_id) from appointment where appointment_dt like '%" . date('Y-m-d') . "%' and status = 9 and mas_id = '" . $this->User['entityId'] . "') as tripsToday,"
                    . "(select IFNULL(sum(mas_earning),0) from appointment where appointment_dt like '%" . date('Y-m-d') . "%' and status = 9 and mas_id = '" . $this->User['entityId'] . "') as earningsToday,"
                    . "(select IFNULL(amount,0) from appointment where status = 9 and mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as lastTripPrice,"
                    . "(select IFNULL(tip_amount,0) from appointment where status = 9 and mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as lastTripTip,"
                    . "(select appointment_dt from appointment where  status = 9 and mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as lastTripTime,"
                    . "(select type_name  from appointment a,workplace_types wt where  a.type_id = wt.type_id and a.status = 9 and a.mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as carType";
            $driverRechargeData = mysql_fetch_assoc(mysql_query($queyrDrivervehicleInfo, $this->db->conn));
        }

        $errMsgArr = $this->_getStatusMessage(21, $queyrDrivervehicleInfo);

        $driverWalltBal = $this->getDriverHardOrSoftLimit($this->User['entityId']);
        if ($args['ent_user_type'] == '1') {
            return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'],
                'tripsToday' => $driverRechargeData['tripsToday'],
                'DriverWallet' => $driverWalltBal['amount'],
                'hardLimit' => $driverWalltBal['flag'],
                'earningsToday' => round($driverRechargeData['earningsToday'], 2),
                'data' => empty($data) ? (object) array() : $data,
                'lastTripTime' => $driverRechargeData['lastTripTime'],
                'lastTripPrice' => round(($driverRechargeData['lastTripPrice'] + $driverRechargeData['lastTripTip']), 2),
                'carType' => $driverRechargeData['carType'],
                'masStatus' => $masStatus['status']);
        }
    }

    /*
     * 
     * get driver wallet balance and hard limit or soft limit
     */

    protected function getDriverHardOrSoftLimit($masId) {
        $query = "select (IFNULL((sum(mas_earning) - sum(cashCollected)),0) + IFNULL((select sum(d.amount) from DriverTxn d where d.mas_id='" . $masId . "' and d.settled_flag = 0),0)) as DriverWallet from appointment where status = 9 and mas_id = '" . $masId . "' and settled_flag = 0 ";
        $driverRechargeData = mysql_fetch_assoc(mysql_query($query, $this->db->conn));
        $config = $this->MongoClass->get_one("config", array('_id' => 1));
        if ($driverRechargeData['DriverWallet'] <= ( - $config['softLimit']) && $driverRechargeData['DriverWallet'] > ( - $config['hardLimit'])) {
            $flag = 1; // softlimit
        } else if ($driverRechargeData['DriverWallet'] <= (-$config['hardLimit'])) {
            $flag = 2; // hardlimit
        } else
            $flag = 0; // its ok
        return array('flag' => $flag, 'amount' => $driverRechargeData['DriverWallet']);
    }

    /*
     * get appt details 
     * 
     */

    protected function getAppointmentDetails($args) {
        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking date time');
        else if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'user type');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_user_type']);

        if (is_array($returned))
            return $returned;

        $getBookingData = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));

        if ($getBookingData['flag'] == '1') {
            return $this->_getStatusMessage(62, $args['ent_booking_id']);
        }


        foreach ($getBookingData['BOOKING'] as $Driver) {
            if ($Driver['Status'] == "Accepted") {
                $masArray = array('pPic' => $Driver['pPic'], 'fName' => $Driver['fName'], 'lName' => $Driver['lName']);
            }
        }

        $invoice = array(
            'addr1' => $getBookingData['appointment_address'],
            'dropAddr1' => $getBookingData['Drop_address'],
            'pPic' => $masArray['pPic'],
            'fName' => $masArray['fName'],
            'lName' => $masArray['lName'],
            'r' => $getBookingData['r'],
            'bid' => $getBookingData['appointment_id'],
            'discountType' => $getBookingData['invoice'][0]['discountType'],
            'discountVal' => $getBookingData['invoice'][0]['discountVal'],
            'min_fare' => $getBookingData['vehicleType']['minmunfare'],
            'code' => $getBookingData['code'],
            'tipPercent' => $getBookingData['tip_percent'],
            'distanceFee' => $getBookingData['invoice'][0]['TripDistanceFee'],
            'timeFee' => $getBookingData['invoice'][0]['TripTimeFee'],
            'tollFee' => $getBookingData['invoice'][0]['tollFee'],
            'airportFee' => $getBookingData['invoice'][0]['airportFee'],
            'parkingFee' => $getBookingData['invoice'][0]['parkingFee'],
            'tip' => $getBookingData['invoice']['tip'],
            'baseFee' => $getBookingData['invoice'][0]['baseFare'],
            'pickupDt' => $getBookingData['appointment_dt'],
            'appntDt' => $getBookingData['appointment_dt'],
            'dropDt' => $getBookingData['drop_dt'],
            'dis' => $getBookingData['invoice'][0]['TripDistance'],
            'dur' => $getBookingData['invoice'][0]['TripTime'],
            'subTotal' => $getBookingData['invoice'][0]['subtotal'],
            'amount' => $getBookingData['invoice'][0]['amount'],
            'payType' => $getBookingData['payment_type'],
            'ServiceFee' => $getBookingData['invoice'][0]['ServiceFee']
        );

        $errMsgArr = $this->_getStatusMessage(21, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'Invoice' => $invoice);
    }

    protected function encrypt_decrypt($action, $string) {
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $secret_key = APP_NAME . 'secretKey Created';
        $secret_iv = APP_NAME . 'sicuerity 123456swq5s';
        // hash

        $key = hash('sha256', $secret_key);

        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha256', $secret_iv), 0, 3);

        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } else if ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        }

        return $output;
    }

    /*
     * Method name: liveBooking
     * Desc: Book appointment live in a given slot
     * Input: Request data
     * Output: success if got it else error according to the result
     */

    protected function liveBooking($args) {

        if ($args['ent_wrk_type'] == '')
            return $this->_getStatusMessage(1, 'Vehicle type');
        else if ($args['ent_addr_line1'] == '')
            return $this->_getStatusMessage(1, 'Pickup address');
        else if ($args['ent_lat'] == '' || $args['ent_long'] == '')
            return $this->_getStatusMessage(1, 'Pickup location');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_payment_type'] == '')
            return $this->_getStatusMessage(1, 'Payment type');
//        else if (!isset($args['ent_wallet_bal']))
//            return $this->_getStatusMessage(1, 'wallet bal');
        else if ($args['ent_payment_type'] == '1' && $args['ent_token'] == '')
            return $this->_getStatusMessage(1, 'token');

        if ($args['ent_surge'] == '' || $args['ent_surge'] == 0)
            $args['ent_surge'] = 1;

        $args['ent_appnt_dt'] = $args['ent_date_time'];

//        $this->curr_date_time = date('Y-m-d H:i:s', time());//urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $args['ent_appnt_dt'] = urldecode($args['ent_appnt_dt']);



        $getapptDt = $this->MongoClass->get_one('appointments', array('slave_id.slaveId' => (int) $this->User['entityId'], "status" => array('$in' => [1, 2, 6, 7, 8, 11])));
        if ($getapptDt['flag'] == '0')
            return $this->_getStatusMessage(60, 60);



//        $this->MongoClass->selects = array('basefare', 'min_fare', 'price_per_min', 'price_per_km', 'type_map_image');
        $getAmountQry = $this->MongoClass->get_one('vehicleTypes', array('type' => (int) $args['ent_wrk_type']));

        if ($getAmountQry['flag'] == '1')
            return $this->_getStatusMessage(38, 38);




        $getLastInsertedId = $this->MongoClass->getLastIdInCollection('appointments', '_id');
        if ($getLastInsertedId['data'] == "")
            $BookingId = 1;
        else
            $BookingId = ((int) $getLastInsertedId['data'] + 1);


        if ($args['ent_coupon'] != "") {
            $Refferal = new campaign();
            $promodata = array(
                'ent_latitude' => $args['ent_lat'],
                'ent_longitude' => $args['ent_long'],
                'userId' => $this->User['entityId'],
                'ent_coupon' => $args['ent_coupon'],
                'ent_from_long' => $args['ent_long'],
                'ent_from_lat' => $args['ent_lat']
            );

            $response = $Refferal->checkCoupons($promodata);
            if ($response['flag'] == 1) {
                $errMsgArr = $this->_getStatusMessage(116, 52);
                return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $response['msg']);
            }
            if ($response['PaymentType'] != ($args['ent_payment_type'] == '2' ? '1' : '2') && $response['PaymentType'] != '3') {
                $errMsgArr = $this->_getStatusMessage(116, 52);
                return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => "The Promocode Is not Applicable for " . ($args['ent_payment_type'] == '2' ? 'Cash' : 'Card') . ' Booking.');
            }
        }




        $getConfgi = $this->__getConfig();
        $MongoAppointmnet = array(
            "_id" => $BookingId,
            "mas_id" => 0,
            'tip_percent' => '0',
            'rating' => 0,
            'DriverAcceptTimeStampServer' => '',
            'code' => is_null($args['ent_coupon']) ? "" : $args['ent_coupon'],
            "slave_id" => array(
                'slaveId' => (int) $this->User['entityId'],
                'coupon' => (int) $this->User['coupon'],
                'email' => $this->User['email'],
                'DeviceId' => $args['ent_dev_id'],
                'SlaveName' => $this->User['firstName'] . ' ' . $this->User['last_name'],
                'SlavePone' => $this->User['mobile'],
                'SlaveChan' => "qp_" . $args['ent_dev_id'],
                'lastDue' => 0,
                'sumLastDue' => 0,
                'sumAllEarning' => 0
            ),
            "status" => 1,
            "ExpiryLimit" => $getConfgi['newBookingPopupTime'],
            "UpdateCustomerReview" => 1,
            "applicableForXrides" => 1,
            "CusomerReviewMessage" => "",
            "Share" => $this->share . $this->encrypt_decrypt('encrypt', $BookingId),
            "UpdateReview" => 1,
            'TripStartTimeStamp' => 0,
            "amount" => ((float) $getAmountQry['min_fare']),
            "PayMentType" => (string) $args['ent_payment_type'],
            "appointment_dt" => $this->curr_date_time,
            "timpeStamp_appointment_dt" => (int) strtotime($this->curr_date_time),
            "drop_dt" => "",
            "appointment_address" => $args['ent_addr_line1'],
            "appointment_location" => array("longitude" => (double) $args['ent_long'], "latitude" => (double) $args['ent_lat']),
            "Drop_address" => isset($args['ent_drop_addr_line1']) ? $args['ent_drop_addr_line1'] : "",
            "Drop_location" => array("longitude" => (double) ($args['ent_drop_long'] == "" ? 0 : $args['ent_drop_long']), "latitude" => (double) ($args['ent_drop_lat'] == "" ? 0 : $args['ent_drop_lat'])),
            "amount" => ((float) $getAmountQry['min_fare']),
            "user_device" => $args['ent_dev_id'],
            "appt_type" => 1,
            "CustomerWalletBalance" => is_null($args['ent_wallet_bal']) ? "" : $args['ent_wallet_bal'],
            "payment_type" => $args['ent_payment_type'],
            "vehicleType" => array(
                "typeId" => ((int) $args['ent_wrk_type']),
                "pricePerMin" => ((float) $getAmountQry['price_per_min']),
                "PricePerKm" => ((float) $getAmountQry['price_per_km']),
                "baseFare" => ((float) $getAmountQry['basefare']),
                "minmunfare" => ((float) $getAmountQry['min_fare']),
                "cancilation_fee" => ((float) $getAmountQry['cancilation_fee']),
                "TypeName" => $getAmountQry['type_name'],
                "cityid" => $getAmountQry['city_id']
            ),
            "VehicleDetails" => array(
                "modal" => "",
                "vehicleID" => "",
                "plateNo" => "",
                "carMapImage" => $getAmountQry['type_map_image'] == "" ? "" : $getAmountQry['type_map_image'],
                "carImage" => "",
                "company" => "",
            ),
            "surge" => $args['ent_surge'],
            "wallet" => (int) $args['ent_wallet'],
            "Favouritepickup" => ($args['ent_fav_pickup'] == "" ? "" : $args['ent_fav_pickup']),
            "Favouritedrop" => ($args['ent_fav_drop'] == "" ? "" : $args['ent_fav_drop']),
            "fraud_satteled" => 0,
            'token' => is_null($args['ent_token']) ? "" : $args['ent_token'],
            "additional_info" => ($args['ent_additional_info'] == "") ? "" : $args['ent_additional_info']
        );

        $response = $this->MongoClass->insert('appointments', $MongoAppointmnet);

        if ($response['flag'] == '1') {
            return $this->_getStatusMessage(3, $MongoAppointmnet);
        }

        if ($args['ent_later_dt'] != '') {

            $pubnubContent1 = array('a' => 12, 'bid' => $BookingId);

            $pushNum['pubnub'] = $this->pubnub->publish(array(
                'channel' => 'dispatcher',
                'message' => $pubnubContent1
            ));
            return $this->_getStatusMessage(78, 78);
        }

        $errMsgArr = $this->_getStatusMessage(21, 78);

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], "BookingId" => $BookingId,
            "ExpiryPerDriver" => $getConfgi['newBookingPopupTime'],
            'ExpiryForBooking' => $getConfgi['newBookingMaxSearchTime'],
            'cancellation_peak_time' => $getConfgi['cancelTime']
        );
    }

    /*
     *  Once Bookingid is generated passenger will request to driver
     *   in this case we use this service 
     *   param : driver emailid , appointment_id 
     */

    protected function TriggerBooking($args) {

        //$this->MongoClass->insert('triggerbooking',$args);

        $notifications123 = $this->mongo->selectCollection('tESTNGdEV');

//        $args = $notifications->findOne(array('_id' => new MongoId('5839457f861e53f60954a7d4')));



        if ($args['ent_mid'] == '')
            return $this->_getStatusMessage(1, 'driver id');
        else if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Pickup address');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');




        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;


        $endOfDay = time() + 21600;
        $beginOfDay = $endOfDay - (604800); // 7 

        $todayCount = $this->mongo->selectCollection('appointments')->find(array('timpeStamp_appointment_dt' => array('$gt' => (int) $beginOfDay, '$lt' => (int) $endOfDay), "status" => 9, "slave_id.DeviceId" => $args['ent_dev_id'], "mas_id" => (int) $args['ent_mid'], 'fraud_satteled' => 0))->count();
        $MINIMUM_FROUD_BOOKING_ALLOW = $this->__getConfig();
        if ($todayCount > $MINIMUM_FROUD_BOOKING_ALLOW['fraudBooking']) {
            $masDet = $this->_getEntityDet($args['ent_mid'], '1', '1');
            $andrPushContent = array('action' => 420, 'message' => "Froud Alert", "usertype" => 1, "User_id" => array($args['ent_mid']));
            $data = $this->PushFromAdminForSpicificnode($andrPushContent);
            $notifications = $this->mongo->selectCollection('notificationsOne');
            $notifications->insert(array('test' => $data));

            $msg = "passangerId : " . $this->User['entityId'] . " device id : " . $args['ent_dev_id'] . ' No of bookings : ' . $todayCount;
            $updateResetDataQry = "update master set workplace_id = 0,status = 5,reject_reason = '" . $msg . "',reject_time = now() where mas_id = '" . $args['ent_mid'] . "'";
            mysql_query($updateResetDataQry, $this->db->conn);

            $updateWorkplaceQry = "update workplace set Status = 2 where workplace_id = '" . $masDet['workplace_id'] . "'";
            mysql_query($updateWorkplaceQry, $this->db->conn);

            $logoutQry = "update user_sessions set loggedIn = '2' where oid = '" . $args['ent_mid'] . "' and user_type = 1";
            $mysql = mysql_query($logoutQry, $this->db->conn);

            if (mysql_affected_rows($mysql) > 0) {

                $statusLog = $this->mongo->selectCollection('statusLog');

                $lastLoggedInStatus = array();
                $lastLoggedIn = $statusLog->find(array('master' => (int) $args['ent_mid'], 'status' => 3, 'time' => array('$lte' => time())))->sort(array('time' => -1))->limit(1);
                foreach ($lastLoggedIn as $key) {
                    $lastLoggedInStatus[] = $key;
                }

                if ($lastLoggedInStatus[0]['status'] == 3) {
                    $update['status_log'] = $statusLog->update(array('master' => (int) $args['ent_mid'], 'status' => 3), array('$set' => array('status' => 4, 'EndTime' => time(), 'dist' => ((double) $args['ent_overall_dist'] > 0 ? (double) $args['ent_overall_dist'] : 0))));
                }
            }

            $this->MongoClass->updatewithPushandSet('location', array("status" => 4), array("logs" => array('date' => time(), 'reason' => $msg, 'slave_id' => $this->User['entityId'], 'deviceId' => $args['ent_dev_id'])), array("user" => (int) $args['ent_mid']));
            return $this->_getStatusMessage(71, 78);
        }




        if (!preg_match("/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/", $args['ent_date_time']))
            return $this->_getStatusMessage(1, 'date and time');

        $startTime = time();



        $getBookingData = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));



        if ($getBookingData['flag'] == '1') {
            return $this->_getStatusMessage(62, $args['ent_booking_id']);
        }


        $doc = $this->MongoClass->get_one('location', array('user' => (int) $args['ent_mid']));

        if ($doc['cashBooking'] == '1' && $getBookingData['PayMentType'] == '2') {
            return $this->_getStatusMessage(71, 78);
        }

        if ($doc['status'] != '3') {
            return $this->_getStatusMessage(71, 'not online');
        }

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        if ($getBookingData['PayMentType'] == '2') {
            $getDriverLimit = $this->getDriverHardOrSoftLimit($args['ent_mid']);
            if ($getDriverLimit['flag'] == 2)
                return $this->_getStatusMessage(71, $getDriverLimit);
        }

        $array = array(6, 7, 8, 9, 2);
        if (in_array($getBookingData['status'], $array))
            return $this->_getStatusMessage(93, $args['ent_booking_id']);

        $masArray = $MasterDidntresp = array();

        if (is_array($getBookingData['BOOKING'])) {
            foreach ($getBookingData['BOOKING'] as $Driver) {
                if (($Driver['Status'] != "Accepted" ) && $Driver['DriverId'] != $args['ent_mid'])
                    $masArray[] = (int) $Driver['DriverId'];
            }
        }

        if (!empty($masArray)) {
            $this->MongoClass->update('location', array("inBooking" => 1), array("user" => array('$in' => $masArray)));
        }
        if ($args['ent_mid'] == 0) {
            $status = 10;
            if (count($getBookingData['BOOKING']) == 0)
                $status = 12; // if no driver was there : acknoladge to admin
            $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $status), array("_id" => (int) $args['ent_booking_id']));
            if ($updateAppointment['flag'] == 1)
                return $this->_getStatusMessage(3, $updateResponseQry);

            return $this->_getStatusMessage(71, 78);
        }

        $BookingRequest = array(
            'DriverId' => (int) $args['ent_mid'],
            'Status' => "Not Received",
            'masChn' => isset($doc['chn']) ? $doc['chn'] : "",
            'pPic' => isset($doc['image']) ? $doc['image'] : "",
            'mobile' => isset($doc['mobile']) ? $doc['mobile'] : "",
            'fName' => isset($doc['name']) ? $doc['name'] : "",
            'lName' => isset($doc['lname']) ? $doc['lname'] : "",
            'email' => isset($doc['email']) ? $doc['email'] : "",
            'rating' => isset($doc['rating']) ? $doc['rating'] : "",
            'serverTime' => $startTime,
            'receiveDt' => "",
            "ExpiryTime" => ($startTime + $MINIMUM_FROUD_BOOKING_ALLOW['newBookingPopupTime']),
            'PassangerRequestTime' => $this->curr_date_time,
        );


        $updateAppointment = $this->MongoClass->updatewithpush('appointments', array("BOOKING" => $BookingRequest), array("_id" => (int) $args['ent_booking_id']));
        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);


        if (count($doc) <= 0)
            return $this->_getStatusMessage(64, 64);
        if ((int) $doc['user'] == 0)
            return $this->_getStatusMessage(64, 64);
        if ($doc['inBooking'] == 2)
            return $this->_getStatusMessage(71, $pushNum);
        if ($doc['type'] != $getBookingData['vehicleType']['typeId'])
            return $this->_getStatusMessage(129, $pushNum);


        if ((int) $doc['status'] != 3) {
//do nothing
        } else {

            $this->MongoClass->update('location', array('inBooking' => 2, "LastBookingTime" => time()), array('user' => (int) $doc['user']));

            $message = $this->__getAppointmnetStatus(1, array('firstName' => $doc['name']));

            $this->androidApiKey = ANDROID_DRIVER_PUSH_KEY;

//            $balnace = $this->GetWalletMoney(array('ent_sid' => $this->User['entityId']));

            $andrPushContent = array(
                "payload" => $message,
                'bid' => (string) $getBookingData['_id'],
                'nt' => 7,
                "ServerTime" => $startTime,
                'CustomerWalletBalance' => $getBookingData['CustomerWalletBalance'],
                'sid' => $getBookingData['slave_id']['slave_id'],
                'bid' => $getBookingData['_id'],
                'adr2' => $getBookingData['appointment_address'],
                'pickupDistance' => $getBookingData['pickupDistance'],
                'lt' => $getBookingData['appointment_location']['latitude'],
                'lg' => $getBookingData['appointment_location']['longitude'],
                'DropAddress' => $getBookingData['Drop_address'],
                'DropLat' => $getBookingData['Drop_location']['latitude'],
                'DropLong' => $getBookingData['Drop_location']['longitude'],
                'CutomerBal' => $getBookingData['CustomerWalletBalance'],
                'CustomerName' => $getBookingData['slave_id']['SlaveName'],
                'CustomerPone' => $getBookingData['slave_id']['SlavePone'],
                'additional_info' => $getBookingData['additional_info'],
                'chn' => $getBookingData['slave_id']['SlaveChan'],
                'dt' => $getBookingData['appointment_dt'],
                'iswallet' => $getBookingData['wallet'],
                'PayMentType' => $getBookingData['PayMentType'],
                'ExpirySecond' => ((int) $MINIMUM_FROUD_BOOKING_ALLOW['newBookingPopupTime'] - (time())) > 0 ? ((int) $MINIMUM_FROUD_BOOKING_ALLOW['newBookingPopupTime'] - (time())) : 0
            );

            $pubnubContent = array(
                'a' => (string) 11,
                'bid' => (string) $getBookingData['_id'],
                "ServerTime" => $startTime
            );

//             $notifications123->insert(array('args'=>$args,'channel' => $doc['listner'], 'pubnbcontent' => $andrPushContent));


            if (!is_null($doc['listner']))
                $pushNum['pubnub'] = $this->pubnub->publish(array(
                    'channel' => $doc['listner'],
                    'message' => $pubnubContent
                ));

            $pushNum['push'] = $this->_sendPush($this->User['entityId'], array($args['ent_mid']), $message, '7', $this->User['firstName'], $this->curr_date_time, '1', array('action' => 7, 'bookingData' => $aplPushContent), array('action' => 7, 'bookingData' => $andrPushContent));
        }

        $errMsgArr = $this->_getStatusMessage(21, 78);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], "data" => array(
                'ServerTime' => $startTime
        ));
    }

    /*
     * get config 
     */

    protected function __getConfig() {
        $getLanguate = $this->MongoClass->get('config');
        $data = array();
        foreach ($getLanguate['data'] as $lan) {
            $data[] = $lan;
        }
        return $data[0];
    }

    /*
     *  insert data in driver wallet
     */

    protected function __insertDriverWallet($args) {
        $queryCycleId = "select id from paymentCycle ORDER BY id DESC LIMIT 1";
        $getCycleId = mysql_fetch_assoc(mysql_query($queryCycleId, $this->db->conn));
        $driverQuery = "insert into DriverTxn(mas_id,txnDate,amount,paymentCycleId) values ('" . $args['mas_id'] . "',now(),'" . $args['amount'] . "','" . $getCycleId['id'] . "')";
        mysql_query($driverQuery, $this->db->conn);
        if (mysql_affected_rows() < 0)
            return array('flag' => 1, 'query' => $driverQuery);
        return array('flag' => 0);
    }

    /*
     * get status message of services 
     * 
     */

    protected function __getAppointmnetStatus($status, $userdata = array()) {
        $message = "";
        switch ($status) {
            case '1' :
                $message = "You got a new job request";
                break;
            case '2':
                $message = $userdata['firstName'] . " has Accepted your request.";
                break;
            case '5':
                $message = "Driver cancelled the Booking on " . APP_NAME . "!";
                break;
            case '6' :
                $message = $userdata['firstName'] . " On the way.";
                break;
            case '7' :
                $message = $userdata['firstName'] . " Has arrived at your  location.";
                break;
            case '8' :
                $message = "Trip Started.";
                break;
            case '9' :
                $message = "Trip Completed.";
                break;


            default : $message = "Status Not Available";
        }
        return $message;
    }

    /*
     * 
     * 
     * 
     */

    public function getPubnubKeys($args) {
        $args['status'] = 0;
        $this->mongo->selectCollection('PubnubStops')->insert($args);
        return array('errNum' => 0, 'errFlag' => 0, 'errMsg' => "Pubnub Keys CHnaged", 'pub' => PUBNUB_PUBLISH_KEY,
            'sub' => PUBNUB_SUBSCRIBE_KEY);
    }

    /*
     * get laguage
     * 
     */

    public function getLangueage() {

        $getLanguate = $this->MongoClass->get('lang_hlp');
        $data = array();
        foreach ($getLanguate['data'] as $lan) {
            $data[] = array($lan['lan_id'] => $lan['lan_name']);
        }
        return $data;
    }

    /*
     * 
     * get cancellation reason
     */

    public function getCancellationReson($args) {
        if ($args['ent_lan'] == '')
            return $this->_getStatusMessage(1, 'language ');
        else if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'User type');

        $getLanguate = $this->MongoClass->get_where('can_reason', array('res_for' => $args['ent_user_type'] == 2 ? 'Passenger' : "Driver"));

        $data = array();
        foreach ($getLanguate['data'] as $lan) {
            $data[] = $lan['reasons'][$args['ent_lan']];
        }
        $errMsgArr = $this->_getStatusMessage(21, 78);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'getdata' => $data
        );
    }

    /*
     * Method name: respondToAppointment
     * Desc: Respond to appointment requeted
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function respondToAppointment($args) {

//        $notifications = $this->mongo->selectCollection('notificationsOne');
//        
//        $args = $notifications->findOne(array('_id' => new MongoId('5839457f861e53f60954a7d4')));
        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');
        else if ($args['ent_response'] == '')
            return $this->_getStatusMessage(1, 'Response type');
        else if ($args['ent_book_type'] == '')
            return $this->_getStatusMessage(1, 'Booking type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_pass_chn'] == '')
            return $this->_getStatusMessage(1, 'Passanger Channel');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $args['ent_appnt_dt'] = urldecode($args['ent_appnt_dt']);

        $getBookingData = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));

        if ($getBookingData['flag'] == '1') {
            return $this->_getStatusMessage(62, $args['ent_booking_id']);
        }


        if (is_array($getBookingData['BOOKING'])) {
            foreach ($getBookingData['BOOKING'] as $Driver) {
                if ($Driver['Status'] == "Request" && $Driver['DriverId'] == $this->User['entityId'])
                    if (($Driver['ExpiryTime'] - time()) < 0)
                        return $this->_getStatusMessage(72, $args['ent_booking_id']);
            }
        }

        $array = array(6, 7, 8, 9, 2);
        if (in_array($getBookingData['status'], $array))
            return $this->_getStatusMessage(72, $args['ent_booking_id']);

        if ($getBookingData['status'] == '4')
            return $this->_getStatusMessage(41, 3);


        if ($getBookingData['status'] == '10')
            return $this->_getStatusMessage(72, 72);

//        if ($getBookingData['status'] > '1')
//            return $this->_getStatusMessage(40, 40);


        $Doc = $this->MongoClass->get_one('location', array("user" => (int) $this->User['entityId']));

        $getVehicleDataQry = "select wrk.uniq_identity,wrk.Vehicle_Image,wrk.License_Plate_No,wrk.company,"
                . " (select v.vehiclemodel from vehiclemodel v where wrk.Vehicle_Model = v.id) as vehicle_model "
                . " from workplace wrk where  wrk.workplace_id = '" . $this->User['workplaceId'] . "'";
        $getVehicleDataRes = mysql_query($getVehicleDataQry, $this->db->conn);

        $vehicleData = mysql_fetch_assoc($getVehicleDataRes);


        $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
        $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
        $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;


        if ($args['ent_response'] == '2' || $args['ent_response'] == '6') { // accepted
            $apptData = array(
                'pickLat' => $getBookingData['appointment_location']['latitude'],
                'pickLong' => $getBookingData['appointment_location']['longitude'],
                'addr1' => $getBookingData['appointment_address'],
                'desLat' => $getBookingData['Drop_location']['latitude'],
                'desLong' => $getBookingData['Drop_location']['longitude'],
                'dropAddr1' => $getBookingData['Drop_address'],
                'share' => $getBookingData['Share'] . $getBookingData['_id'],
                'apptDt' => $getBookingData['appointment_dt'],
                'email' => $this->User['email'],
                'bid' => $getBookingData['_id'],
                'mid' => $this->User['entityId'],
                'chn' => 'qd_' . $args['ent_dev_id'],
                'model' => ($vehicleData['vehicle_model'] == "") ? "No Model" : $vehicleData['vehicle_model'],
                'plateNo' => $vehicleData['License_Plate_No'],
                'carMapImage' => $getBookingData['VehicleDetails']['carMapImage'],
                'carImage' => $vehicleData['Vehicle_Image'],
                'r' => $Doc['rating'],
                'pPic' => $this->User['pPic'],
                'mobile' => $this->User['mobile'],
                'fName' => $this->User['firstName'],
                'lName' => $this->User['last_name'],
                'tipPercent' => 0,
                'status' => (int) $args['ent_response'],
                'rateStatus' => 0,
            );


            $message = $this->__getAppointmnetStatus(6, $this->User);

            $aplPushContent = array('alert' => $message, 'nt' => 6, 'data' => $apptData);
            $andrPushContent = array("payload" => $message, 'action' => 6, 'data' => $apptData);
            $pubnubContent = array('a' => 4, 'status' => $args['ent_response'], 'data' => $apptData);

            $dispacher = array('a' => 14, 'bid' => $args['ent_booking_id'], 's' => $args['ent_response'], 'm' => $message);

            $out['pubnub'] = $this->pubnub->publish(array(
                'channel' => 'dispatcher',
                'message' => $dispacher
            ));


            list($date, $time) = explode(' ', $this->curr_date_time);
            list($year, $month, $day) = explode('-', $date);
            list($hour, $minute, $second) = explode(':', $time);

            $startTime = mktime($hour, $minute, $second, $month, $day, $year);
            $statusLog = $this->mongo->selectCollection('statusLog');

            $lastLoggedIn = $statusLog->find(array('master' => (int) $this->User['entityId'], 'status' => 3, 'time' => array('$lte' => $startTime)))->sort(array('time' => -1))->limit(1);
            foreach ($lastLoggedIn as $key) {
                $lastLoggedInStatus[] = $key;
            }

            if ($lastLoggedInStatus[0]['status'] == 3) {
                $statusLog->update(array('master' => (int) $this->User['entityId'], 'status' => 4), array('$set' => array('status' => (int) 4, 'EndTime' => $startTime, 'EndTimeGurentee' => $startTime)));
            }

            $statusLog->insert(array('master' => (int) $this->User['entityId'], 'status' => 5, 'startTime' => $startTime, "EndTime" => 0, 'bid' => (int) $args['ent_booking_id']));

            $this->MongoClass->update('location', array('status' => 5, "inBooking" => 1, "SlaveId" => (int) $getBookingData['slave_id']['slaveId'], "apptStatus" => (int) $args['ent_response']), array('user' => (int) $this->User['entityId']));
        } else {
            if ($args['ent_response'] == '1' || $args['ent_response'] == '3') { // it means rejected
                $aplPushContent = array('alert' => $message, 'nt' => 4);
                $andrPushContent = array("payload" => $message, 'action' => 4);
                $pubnubContent = array('a' => 4, 'status' => (int) $args['ent_response']);
            }
            $this->MongoClass->update('location', array('status' => 3, "inBooking" => 1), array('user' => (int) $this->User['entityId']));
        }


        $updateAppointment = $this->MongoClass->update('appointments', array(
            "status" => (int) $args['ent_response'],
            'mas_id' => (int) $this->User['entityId'],
            'DriverAcceptTimeStampServer' => strtotime($this->curr_date_time),
            'OntheWayTimeStampServer' => time(),
            'BOOKING.$.Status' => ($args['ent_response'] == '2' || $args['ent_response'] == '6') ? "Accepted" : "Rejected",
            'BOOKING.$.pPic' => $this->User['pPic'],
            'VehicleDetails.modal' => ($vehicleData['vehicle_model'] == "") ? "No Model" : $vehicleData['vehicle_model'],
            'VehicleDetails.plateNo' => $vehicleData['License_Plate_No'],
            'VehicleDetails.vehicleID' => $vehicleData['uniq_identity'],
            'VehicleDetails.company' => $vehicleData['company'],
            'VehicleDetails.carImage' => $vehicleData['Vehicle_Image']
                ), array("_id" => (int) $args['ent_booking_id'], "BOOKING.DriverId" => (int) $this->User['entityId']));

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);

        $push['push'] = $this->_sendPush('0', array($this->User['entityId']), $message, '5', $apptDetails['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent);

        $pushNum['pubnub'] = $this->pubnub->publish(array(
            'channel' => $args['ent_pass_chn'],
            'message' => $pubnubContent
        ));
        $driverRedious = $this->__getConfig();
        $errorno = $this->_getStatusMessage(40, 40);
        return array('errNum' => $errorno['errNum'], 'errFlag' => $errorno['errFlag'], 'errMsg' => $errorno['errMsg'], 'amount' => $driverRedious['driverArrivedRadius']);
    }

    public function testdate() {
        date_default_timezone_set("UTC");
        $time1 = time();


        date_default_timezone_set("Europe/Helsinki");
        $time2 = time();
        return array('time1' => $time1, 'time2' => $time2);
    }

    /*
     * Method name: updateSlaveReview
     * Desc: Update appointment review of an appointment
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function updateSlaveReview($args) {

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking date time');
        else if ($args['ent_mid'] == '')
            return $this->_getStatusMessage(1, 'Driver email');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_rating_num'] == '')
            return $this->_getStatusMessage(1, 'Rating');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $insertReviewQry = "insert into master_ratings(mas_id, slave_id, review_dt, star_rating, review, appointment_id,positive_review) values('" . $args['ent_mid'] . "', '" . $this->User['entityId'] . "', '" . $this->curr_date_time . "', '" . $args['ent_rating_num'] . "', '" . $args['ent_review_msg'] . "', '" . $args['ent_booking_id'] . "','" . $args['ent_positive_review'] . "')";
        mysql_query($insertReviewQry, $this->db->conn);

        $selectAvgRatQry = "select avg(star_rating) as avg from master_ratings where mas_id = '" . $args['ent_mid'] . "' and status = 1";
        $selectAvgRatRes = mysql_query($selectAvgRatQry, $this->db->conn);
//
        $avgRow = mysql_fetch_assoc($selectAvgRatRes);

        $updateAppointment = $this->MongoClass->update('appointments', array("UpdateReview" => 0, "rating" => (int) $args['ent_rating_num'], "DriverReviewMessage" => $args['ent_review_msg']), array("_id" => (int) $args['ent_booking_id']));

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);

        $updateAppointment = $this->MongoClass->update('location', array("rating" => $avgRow['avg']), array("user" => (int) $args['ent_mid']));

//        $res = $this->sendComplainMail($args, $this->User['city_id'], 1);

        return $this->_getStatusMessage(63, $res);
    }

    protected function updateDriverReview($args) {

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking date time');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_reason'] == '') {
            return $this->_getStatusMessage(1, 'reason');
        }

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $updateAppointment = $this->MongoClass->update('appointments', array("UpdateCustomerReview" => 1, "Customerrating" => (int) $args['ent_rating_num'], "CusomerReviewMessage" => $args['ent_reason']), array("_id" => (int) $args['ent_booking_id']));

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);

//        $mail = new sendAMail(APP_SERVER_HOST);
//        $subject = "Driver Review";
//        $body = $args['ent_reason'];
//        $recipients = array(($this->User['entityId']) . '@pqup.co' => $this->User['firstName']);
//        $mail->mailFun($recipients, $subject, $body, "driversupport@pqup.co");
//        $res = $this->sendComplainMail($args, "", 6);
        return $this->_getStatusMessage(63, 12);
    }

    public function DriverReviewZendesk($args) {
        if ($args['ent_booking_id'] == '') {
            return $this->_getStatusMessage(1, 'Booking id ');
        }
        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');
        if (is_array($returned))
            return $returned;

//        $res = $this->sendComplainMail($args, $this->User['city_id'], 4);
        return $this->_getStatusMessage(63, $res);
    }

    protected function getSlaveAppointments($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_page_index'] == '')
            return $this->_getStatusMessage(1, 'Page index');

        // $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $pagelimit = ($args['ent_page_index'] * 10);

        $appointmentsCur = $this->mongo->selectCollection('appointments');
        $apptDetaos = $appointmentsCur->find(array("status" => array('$in' => [9, 3]), 'slave_id.slaveId' => (int) $this->User['entityId']))->sort(array('_id' => -1))->limit(11)->skip($pagelimit);
        $appointments = array();

        foreach ($apptDetaos as $appnt) {

            if ($appnt['profile_pic'] == '')
                $appnt['profile_pic'] = $this->default_profile_pic;

            $aptdate = date('Y-m-d', strtotime($appnt['appointment_dt']));

            if ($appnt['status'] == '1')
                $status = 'Booking requested';
            else if ($appnt['status'] == '2')
                $status = 'Driver accepted.';
            else if ($appnt['status'] == '3')
                $status = 'Driver rejected.';
            else if ($appnt['status'] == '4')
                $status = 'You cancelled.';
            else if ($appnt['status'] == '5')
                $status = 'Driver cancelled.';
            else if ($appnt['status'] == '6')
                $status = 'Driver is on the way.';
            else if ($appnt['status'] == '7')
                $status = 'Driver arrived.';
            else if ($appnt['status'] == '8')
                $status = 'Booking started.';
            else if ($appnt['status'] == '9' && $appnt['payment_status'] == '')
                $status = 'Completed';
            else if ($appnt['status'] == '9' && ($appnt['payment_status'] == '1' || $appnt['payment_status'] == '3'))
                $status = 'Completed';
            else if ($appnt['status'] == '9' && $appnt['payment_status'] == '2')
                $status = 'Disputed';
            else if ($appnt['status'] == '10')
                $status = 'Booking expired.';
            else
                $status = 'Status unavailable.';
            $amount = $appnt['amount'];
            if (!empty($appnt['BOOKING'])) {
                foreach ($appnt['BOOKING'] as $data)
                    if ($appnt['mas_id'] == $data['DriverId']) {
                        $pPic = $data['pPic'];
                        $email = $data['email'];
                        $fname = $data['fName'];
                        $rating = $data['rating'];
                    }
            }

//            $amount = ($appnt['cancel_status'] == '3' ? $appnt['cancel_amt'] : ((in_array($appnt['payment_status'], array(1, 3))) ? round($appnt['amount'], 2) : 0));




            $appointments[] = array(
                'apntDt' => $appnt['appointment_dt'],
                'pPic' => $pPic,
                'email' => $email,
                'status' => $status,
                'bid' => $appnt['_id'],
                'fname' => $fname,
                'r' => $appnt['rating'],
                'drop_dt' => $appnt['drop_dt'],
                'apntDate' => date('Y-m-d', strtotime($appnt['appointment_dt'])),
                'addrLine1' => urldecode($appnt['appointment_address']),
                'dropLine1' => urldecode($appnt['Drop_address']),
                'routeImg' => $appnt['routeImg'],
                'invoice' => array(
                    'payType' => $appnt['PayMentType'],
                    'walletDeducted' => $appnt['walletDeducted'],
                    'code' => is_null($args['code']) ? "" : $args['code'],
                    'min_fare' => $appnt['vehicleType']['minmunfare'],
                    'tipPercent' => $appnt['tip_percent'],
                    'amount' => $appnt['invoice'][0]['amount'],
                    'TripDistanceFee' => $appnt['invoice'][0]['TripDistanceFee'],
                    'TripTimeFee' => $appnt['invoice'][0]['TripTimeFee'],
                    'airportFee' => $appnt['invoice'][0]['airportFee'],
                    'airportFee' => $appnt['invoice'][0]['airportFee'],
                    'discountVal' => $appnt['invoice'][0]['discountVal'],
                    'subtotal' => $appnt['invoice'][0]['subtotal'],
                    'tip' => $appnt['invoice'][0]['tip'],
                    'cardlastDigit' => $appnt['invoice'][0]['card']['lastDigit'],
                    'cashCollected' => $appnt['invoice'][0]['cashCollected'],
                    'walletDebitCredit' => $appnt['invoice'][0]['walletDebitCredit'],
                    'walletDeducted' => $appnt['invoice'][0]['walletDeducted'],
                    'TripTime' => $appnt['invoice'][0]['TripTime'],
                    'baseFare' => $appnt['invoice'][0]['baseFare'],
                    'TripDistance' => $appnt['invoice'][0]['TripDistance'],
                    'ServiceFee' => $appnt['invoice'][0]['ServiceFee']
                ),
            );
        }

        $errNum = 31;

        $errMsgArr = $this->_getStatusMessage($errNum, 2);

        return array('errNum' => $errMsgArr['errNum'], 'lastcount' => (count($appointments) >= 10 ? 1 : 0 ), 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'appointments' => $appointments);
    }

    /*
     * Method name: updateDropOff
     * Desc: Update slave profile data
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function updateDropOff($args) {

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');
        if ($args['ent_drop_addr1'] == '')
            return $this->_getStatusMessage(1, 'Drop address');
        else if ($args['ent_lat'] == '' || $args['ent_long'] == '')
            return $this->_getStatusMessage(1, 'Drop location');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_mid'] == '')
            return $this->_getStatusMessage(1, 'mid ');

        // $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));
        $master = $this->MongoClass->get_one('location', array("user" => (int) $apptDet['mas_id']));

        if ($apptDet['flag'] == 1)
            return $this->_getStatusMessage(3, $apptDet);

        if (!is_array($apptDet))
            return $this->_getStatusMessage(32, 32);

        if ($apptDet['status'] == '3')
            return $this->_getStatusMessage(44, 44);

        if ($apptDet['status'] == '4')
            return $this->_getStatusMessage(41, 3);

        if ($apptDet['status'] == '5')
            return $this->_getStatusMessage(82, 3);

        if ($apptDet['status'] == '9')
            return $this->_getStatusMessage(75, 3);

        $updateAppointment = $this->MongoClass->update('appointments', array("Drop_address" => $args['ent_drop_addr1'] . $args['ent_drop_addr2'], "Drop_location.longitude" => isset($args['ent_long']) ? $args['ent_long'] : "", "Drop_location.latitude" => isset($args['ent_lat']) ? $args['ent_lat'] : ""), array("_id" => (int) $args['ent_booking_id']));
        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);

        $aplPushContent = array('alert' => 'Drop off is updated by customer', 'nt' => '22', 'sound' => 'default', 'adr' => $args['ent_drop_addr1'] . $args['ent_drop_addr2'], 'ltg' => $args['ent_lat'] . ',' . $args['ent_long']);
        $andrPushContent = array("payload" => 'Drop off is updated by customer', 'action' => '22', 'adr' => $args['ent_drop_addr1'] . $args['ent_drop_addr2'], 'ltg' => $args['ent_lat'] . ',' . $args['ent_long']);

        $pubnubContent = array('a' => 16, 'e' => $this->User['email'], 'adr' => $args['ent_drop_addr1'] . $args['ent_drop_addr2'], 'ltg' => $args['ent_lat'] . ',' . $args['ent_long'], 'bid' => $apptDet['_id']);

        if (!is_null($master['listner']))
            $pushNum['pubnub'] = $this->pubnub->publish(array(
                'channel' => $master['listner'],
                'message' => $pubnubContent
            ));

        $pushNum['pubnub'] = $this->pubnub->publish(array(
            'channel' => 'dispatcher',
            'message' => $pubnubContent
        ));

        $this->androidApiKey = $this->masterApiKey;
        $this->ios_cert_path = $this->ios_roadyo_driver;
        $this->ios_cert_pwd = $this->ios_dri_pwd;

        $sendPush = $this->_sendPush($this->User['entityId'], array($master['user']), $args['ent_message'], '21', $this->User['firstName'], $this->curr_date_time, '1', $aplPushContent, $andrPushContent);

        return $this->_getStatusMessage(123, $sendPush);
    }

    /*
     * Method name: updateApptDetails
     * Desc: Update appointment details
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function __UpdateApptDetails($apptDet, $args, $googleDistance) {


        $updateAppointment = $this->MongoClass->update('appointments', array('app_route' => $args['app_route']), array("_id" => (int) $args['ent_booking_id']));
        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);


        // here we got time taken by booking
        $duration_in_mts_old = round(abs(time() - $apptDet['BookingStartTimeStampServer']) / 60);
        $duration_in_mts = ((int) $duration_in_mts_old == 0) ? 1 : $duration_in_mts_old;

//        $getDirectionFormMatrix = $this->get_DirectionFormMatrix($apptDet['appointment_location']['latitude'], $apptDet['appointment_location']['longitude'], $args['ent_drop_lat'], $args['ent_dropLong']);
//        $googleDis = $getDirectionFormMatrix['distance'];

        $distance_in_mts = $args['ent_distance']; //0
        $dis_in_km = $surg_price = $distance = 0;

        if ($googleDistance['CalculatedDist'] != 0) {

            $googleFromMap = $dis_in_km = (float) $googleDistance['CalculatedDist'];
        }

        if ($dis_in_km == "0") {
            $dis_in_km = (float) ($distance_in_mts / $this->distanceMetersByUnits);
        }

        if (is_null($dis_in_km) || $dis_in_km == "0") {
            $getDirectionFormMatrix = $this->get_DirectionFormMatrix($apptDet['appointment_location']['latitude'], $apptDet['appointment_location']['longitude'], $args['ent_drop_lat'], $args['ent_dropLong']);
            $googleDis = $getDirectionFormMatrix['distance'];
            $dis_in_km = (float) ($googleDis / $this->distanceMetersByUnits);
        }


        $surg_price = 0;

        $zonefactor = $this->mongo->selectCollection('zone')->findOne(
                array("polygons" =>
                    array('$geoIntersects' =>
                        array('$geometry' =>
                            array("type" => "Point", "coordinates" => array((double) $args['ent_dropLong'], (double) $args['ent_drop_lat']))
                        )
                    )
                )
        );

        if (is_array($zonefactor))
            $surg_price = (int) $zonefactor['surge_price'];
        else {
            $zonefactor_pickup = $this->mongo->selectCollection('zone')->findOne(
                    array("polygons" =>
                        array('$geoIntersects' =>
                            array('$geometry' =>
                                array("type" => "Point", "coordinates" => array((double) $apptDet['appointment_location']['longitude'], (double) $apptDet['appointment_location']['latitude']))
                            )
                        )
                    )
            );
            if (is_array($zonefactor_pickup))
                $surg_price = (int) $zonefactor_pickup['surge_price'];
        }



        $priceperKm = (double) round(($dis_in_km * $apptDet['vehicleType']['PricePerKm']), 2);
        $pricePerMin = (double) round(($duration_in_mts * $apptDet['vehicleType']['pricePerMin']), 2);

        $config = $this->__getConfig();
        $waitingTime = (int) ceil((($apptDet['BookingStartTimeStampServer'] - $apptDet['DriverArrivedTimeStampServer']) / 60));
        $waitingTimeFee = 0;
        if ($waitingTime > $config['limitForwatingTime'])
            $waitingTimeFee = (double) round((($waitingTime - $config['limitForwatingTime']) * $apptDet['vehicleType']['pricePerMin']), 2);

        $newFare = (double) round(($apptDet['vehicleType']['baseFare'] + (round($priceperKm, 2) + $waitingTimeFee) + round($pricePerMin, 2) + round(ServiceFee, 2) + $surg_price), 2);
//        $meterfee = $finalAmount = (double) round(($newFare > $apptDet['amount']) ? round($newFare) : $apptDet['amount']);


        $meterfee = $finalAmount = (double) round($newFare, 2);

        $tip = 0;

        if ($apptDet['tip_percent'] != '')
            $tip = round($apptDet['tip_percent'], 2);


        if ($meterfee < 0)
            $meterfee = 1;

        $RediousPrice = $this->mongo->selectCollection('RediousPrice');
        $appcommisioninpersentage = $RediousPrice->find(array('cityid' => (string) $apptDet['vehicleType']['cityid'], 'from_' => array('$lte' => (int) $meterfee)))->sort(array('from_' => -1))->limit(1);
//        return array('data' => 'test');

        foreach ($appcommisioninpersentage as $key) {
            $Commisiondata[] = $key;
        }

        $defautcommision = PAYMENT_APP_COMMISSION;

        if (!empty($Commisiondata)) {
            $defautcommision = $Commisiondata[0]['price'];
        }

        $finalAmountBeforediscount = $finalAmount;
        $discount = $discountedFare = 0;
        if ($apptDet['code'] != '') {
            $promodata = array(
                'buildAmount' => $finalAmount,
                'UserId' => $apptDet['slave_id']['slaveId'],
                'bookingId' => $apptDet['_id'],
                'ent_coupon' => $apptDet['code'],
            );

//            $this->mongo->selectCollection('testingData')->insert($promodata);

            $Refferal = new campaign();
            $response = $Refferal->getPromoProfit($promodata);

            if ($response['Type'] == 1) {
                $discount = ($response['discount'] > $finalAmount ? $finalAmount : $response['discount']);
                $discountedFare = ($finalAmount - $response['discount']);
            }
        }

        $gatewayCommision = $DrivergatewayCommision = 0;

        if ($apptDet['payment_type'] == '1') {

            $gatewayCommision = round(($config['pgCommission'] / 100 ) * ($finalAmount));
            $DrivergatewayCommision = round(($tip + $surg_price) * pgComission);
        }

        $appCommision = (float) ($finalAmount * ($defautcommision / 100));

        $mas = (float) round(($finalAmount - ($appCommision + $DrivergatewayCommision) - ServiceFee + $tip), 2);

        $profitOrLoss = (($appCommision - ($discount + $gatewayCommision) + ServiceFee) > 0 ? ($appCommision - ($discount + $gatewayCommision) + ServiceFee) : ($appCommision + $gatewayCommision + ServiceFee));

        $finalAmount = round((($finalAmount - $discount) > 0 ? ($finalAmount - $discount) : 0), 2);

        $transactionId = "";


        $balnace = $this->GetWalletMoney(array('ent_sid' => $apptDet['slave_id']['slaveId']));

//        if ($apptDet['PayMentType'] == '1') {
//            
//            $query = "select stripe_id from slave where slave_id = '". $apptDet['slave_id']['slaveId'] ."'";
//
//            $apptDet123 = mysql_fetch_assoc(mysql_query($query, $this->db->conn));
//            
//            $chargeCustomerArr = array('stripe_id' => $apptDet123['stripe_id'], 'amount' => (int) ((float) $finalAmount * 100), 'currency' => PAYMENT_BASE_CURRENCY, 'description' => 'From ' . $apptDet['slave_id']['email']);
//
//            $customer = $this->stripe->apiStripe('chargeCard', $chargeCustomerArr);
//
//            if ($customer['error']) {
//
////                $query = "update appointment set payment_type = 2 where appointment_id = '" . $apptDet['_id'] . "'";
////                $resutlUp = mysql_query($query, $this->db->conn);
////
////                if (mysql_affected_rows() <= 0) {
////                    return $this->_getStatusMessage(3, 3);
////                }
//
//                $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
//                $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
//                $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;
//                $noteType = 101;
//                $message = 'CARD PAYMENT HAS DECLINED! PLEASE PAY VIA CASH!';
//
//                $aplPushContent = array('alert' => $message, 't' => $apptDet['appt_type'], 'nt' => $noteType, 'd' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'sound' => 'default', 'id' => $apptDet['_id']); //, 'n' => $this->User['firstName'] . ' ' . $this->User['last_name']
//                $andrPushContent = array("payload" => $message, 't' => $apptDet['appt_type'], 'action' => $noteType, 'sname' => $this->User['firstName'] . ' ' . $this->User['last_name'], 'dt' => $args['ent_appnt_dt'], 'smail' => $this->User['email'], 'id' => $apptDet['_id']);
//
//                $push['push'] = $this->_sendPush($this->User['entityId'], array($pasData['slave_id']), $message, $noteType, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent, $apptDet['user_device']);
//
//
//                return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => 'CARD PAYMENT HAS DECLINED! PLEASE TAKE PAYMENT VIA CASH!', 'code' => $customer['result']['code']);
//            }
//
//
//
//            $transactionId = $customer['id'];
//        }



        $driverWalltBal = $this->getDriverHardOrSoftLimit($this->User['entityId']);
        $tripamount = $driverTOgetAmt = $finalAmount;
//        $MininumAmtToCollect = $walletDeducted = 0;
//        if ($apptDet['wallet'] == '1') {
//
//
//            $amtafterwallet = (double) ($balnace['amount'] - $driverTOgetAmt); // > 0 ? ($balnace['amount'] - $driverTOgetAmt) : ( $driverTOgetAmt - $balnace['amount']) );
//
//
//            if ($amtafterwallet < 0) { // the amount is in minus
//                // 
//                if ($apptDet['payment_type'] == 1) {
//                    $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,txn_id) values ('" . $apptDet['slave_id']['slaveId'] . "',1,'" . (-$balnace['amount']) . "',now(),'2','" . $args['ent_appnt_id'] . "')";
//                    mysql_query($query, $this->db->conn);
//                    if (mysql_affected_rows() < 0)
//                        return $this->_getStatusMessage(3, $query);
//                }
//                $driverTOgetAmt = (double) ($driverTOgetAmt - $balnace['amount']);
//                $walletDeducted = $balnace['amount'];
//                $MininumAmtToCollect = (double) ($driverTOgetAmt - ALLOW_DRIVER_UPTO);
//            } else {// the amount in plus
//                $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,txn_id) values ('" . $apptDet['slave_id']['slaveId'] . "',1,'" . (-$driverTOgetAmt) . "',now(),'2','" . $args['ent_appnt_id'] . "')";
//                $walletDeducted = abs($driverTOgetAmt);
//                $driverTOgetAmt = 0;
//
//                mysql_query($query, $this->db->conn);
//                if (mysql_affected_rows() < 0)
//                    return $this->_getStatusMessage(3, $query);
//            }
//        }
//        else {
//            if ($balnace['amount'] < 0) {
//                $MininumAmtToCollect = $driverTOgetAmt - $balnace['amount'];
//            } else
//                $MininumAmtToCollect = $driverTOgetAmt;
//        }

        if ($driverTOgetAmt == 0 || $MininumAmtToCollect <= 0 || $apptDet['PayMentType'] == '1') {
            $cond = array('status' => 3, 'apptStatus' => 0);
            $this->MongoClass->update('location', $cond, array('user' => (int) $this->User['entityId']));
        } else if ($apptDet['PayMentType'] == '1') {

//            error while transection
//            if($error){
//            $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,txn_id) values ('" . $apptDet['slave_id']['slaveId'] . "',1,'" . (-$driverTOgetAmt) . "',now(),'2','" . $args['ent_appnt_id'] . "')";
//                $walletDeducted = abs($driverTOgetAmt);
//                $driverTOgetAmt = 0;
//
//                mysql_query($query, $this->db->conn);
//                if (mysql_affected_rows() < 0)
//                    return $this->_getStatusMessage(3, $query);
//            }
//            $cond = array('status' => 3, 'apptStatus' => 0);
//            $this->MongoClass->update('location', $cond, array('user' => (int) $this->User['entityId']));  
        }




        $InvoiceData = array(
            "txn_id" => $transactionId,
            'max_amountTocallect' => round((MAX_AMOUNT_DRIVER_CAN_GET_FROM_CUSTOMER + $finalAmount + $apptDet['slave_id']['sumLastDue']), 2),
            "pg_commission" => round($gatewayCommision, 2),
            "app_commission" => round($appCommision, 2),
            "amount" => (float) round(($finalAmount + $tip), 2),
            "finalAmount" => round(($finalAmount + $tip), 2),
            "subtotal" => (float) round(($finalAmount + $tip - $appCommision - ServiceFee), 2),
//            "subtotal" => (float) (($finalAmountBeforediscount)),
            'discountType' => isset($couponDet['discount_type']) ? $couponDet['discount_type'] : 0,
            'discountVal' => round($discount, 2),
            'customerWalletBal' => $balnace['amount'],
            'commissionApplied' => $defautcommision,
            "mas_earning" => (float) round($mas, 2),
            "profitLoss" => round($profitOrLoss, 2),
            'driverWalltBal' => round($driverWalltBal['amount'], 2),
            "tip" => round($tip, 2),
            "sumLastDue" => ($apptDet['slave_id']['sumAllEarning'] + ($balnace['amount'] < 0 ? abs($balnace['amount']) : 0)),
            "waitingTime" => ($waitingTime - $config['limitForwatingTime']),
            "waitingTimeFee" => $waitingTimeFee,
            'DrivergatewayCommision' => $DrivergatewayCommision,
            'walletDeducted' => round($walletDeducted, 2),
            'walletDebitCredit' => 0,
            'ServiceFee' => ServiceFee,
            "TripTime" => $duration_in_mts,
            "airportFee" => $surg_price,
            "BuildAmout" => round($meterfee, 2),
            "TripDistance" => round($dis_in_km, 2),
            "TripTimeFee" => (float) round(($pricePerMin), 2),
            "TripDistanceFee" => (float) round(($priceperKm), 2),
            "GoogleDistance" => $googleDis,
            "GoogleDistanceFromMap" => $googleFromMap,
            "DriverDistance" => $args['ent_dist'],
            'cashCollected' => 0,
            'min_fare' => round($apptDet['vehicleType']['minmunfare'], 2),
            'card' => array(
                'type' => $customer['payment_option'],
                'lastDigit' => $customer['card_number']
            ),
            'pickup' => $apptDet['appointment_address'],
            'dorp' => $apptDet['Drop_address'] == "" ? $args['ent_dropAddress'] : $apptDet['Drop_address'],
            'baseFare' => (float) round(($apptDet['vehicleType']['baseFare'] * $apptDet['surge']), 2),
            'MininumAmtToCollect' => round($MininumAmtToCollect, 2), 'tripamount' => round(($tripamount - $walletDeducted), 2),
        );

        return array('invoiceData' => $InvoiceData);
    }

    /*
     * Method name: updateApptStatus
     * Desc: Update appointment status
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function updateApptStatus123($args) {
        $args = $this->MongoClass->get_one('tsgitest', array('_id' => new MongoId('5878e52a90fdcfeebb1d13d2')));

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id ');
        else if ($args['ent_response'] == '')
            return $this->_getStatusMessage(1, 'Response type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if (($args['ent_reponse'] == '9' && $args['ent_dist'] == '' && $args['ent_dropLat'] == '' && $args['ent_dropLong'] == '' && $args['ent_dropAddress'] == ''))
            return $this->_getStatusMessage(1, 'not able to complete ');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;


        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));
        if ($apptDet['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);

        if ($apptDet['status'] == '4')
            return $this->_getStatusMessage(41, 3);

        if ($apptDet['status'] == '5')
            return $this->_getStatusMessage(82, 82);

        if ($apptDet['status'] == '9')
            return $this->_getStatusMessage(75, 82);

        if ($apptDet['status'] == '10')
            return $this->_getStatusMessage(72, 72);



        $message = $this->__getAppointmnetStatus($args['ent_response'], $this->User);
        if ($args['ent_response'] == '6') {
            $errNum = 57;
            $this->MongoClass->update('location', array("user" => (int) $this->User['entityId']), array("status" => 5, "apptStatus" => (int) $args['ent_response']));
        } else if ($args['ent_response'] == '7') {
            $errNum = 58;
            $this->MongoClass->update('location', array("user" => (int) $this->User['entityId']), array("status" => 5, "apptStatus" => (int) $args['ent_response']));
        } else if ($args['ent_response'] == '8') {
            $errNum = 83;
            $this->MongoClass->update('location', array("user" => (int) $this->User['entityId']), array("status" => 5, "apptStatus" => (int) $args['ent_response']));
        } else if ($args['ent_response'] == '9') {
            $errNum = 59;
            $url = $this->get_app_route_img($apptDet, $args);
            $updateInvoice = $this->__UpdateApptDetails($apptDet, $args, $url);
            return array('test' => $updateInvoice);
            if (isset($updateInvoice['invoiceData'])) {
                $updateAppointment = $this->MongoClass->updatewithpush('appointments', array('invoice' => $updateInvoice['invoiceData']), array("_id" => (int) $args['ent_booking_id']));
            } else {
                if ($updateInvoice['errNum'] == 16) {
                    $this->MongoClass->update('appointments', array('PayMentType' => "2"), array("_id" => (int) $args['ent_booking_id']));
                    return $updateInvoice;
                }
                return $this->_getStatusMessage(56, $updateInvoice);
            }
            $updateInvoice['invoiceData']['PayMentType'] = $apptDet['payment_type'];

            $insertAppointmentQry = "insert into appointment(mas_id,slave_id,created_dt,last_modified_dt,status,appointment_dt,address_line1,drop_addr1,appt_lat,appt_long,amount,appt_type,payment_type,
            type_id,app_owner_pl,txn_id,mas_earning,pg_commission,app_commission,payment_status,airport_fee,discount,mongoId,BuildAmout,duration) 
            values('" . $this->User['entityId'] . "','" . $apptDet['slave_id']['slaveId'] . "','" . $apptDet['appointment_dt'] . "','" . $this->curr_date_time . "','9','" . $apptDet['appointment_dt'] . "','" . $apptDet['appointment_address'] . "','" . $args['ent_dropAddress'] . "','" . $apptDet['appointment_location']['latitude'] . "','" . $apptDet['appointment_location']['latitude'] . "','" . $updateInvoice['invoiceData']['amount'] . "','" . $apptDet['appt_type'] . "','" . $apptDet['payment_type'] . "','" . $apptDet['vehicleType']['typeId'] . "'," . " '" . $updateInvoice['invoiceData']['profitLoss'] . "','" . $updateInvoice['invoiceData']['txn_id'] . "','" . $updateInvoice['invoiceData']['mas_earning'] . "'," . " '" . $updateInvoice['invoiceData']['pg_commission'] . "','" . $updateInvoice['invoiceData']['app_commission'] . "','1'," . "'" . $updateInvoice['invoiceData']['airportFee'] . "','" . $updateInvoice['invoiceData']['discountVal'] . "','" . $apptDet['_id'] . "','" . $updateInvoice['invoiceData']['BuildAmout'] . "','" . $updateInvoice['invoiceData']['TripTime'] . "')";
            mysql_query($insertAppointmentQry, $this->db->conn);
            $apptId = mysql_insert_id();
            if ($apptId < 0)
                return $this->_getStatusMessage(3, $insertAppointmentQry);
        } else {
            return $this->_getStatusMessage(56, 56);
        }

        $aplPushContent = array('alert' => $message, 'nt' => $args['ent_response'], 'sound' => 'default');
        $andrPushContent = array("payload" => $message, 'action' => $args['ent_response']);
//pickup_route

        $driverId = $this->User['entityId'];
        if ($args['ent_response'] == '7') {
            $arrayCampain = array('ent_latitude' => $apptDet['appointment_location']['latitude'],
                'ent_longitude' => $apptDet['appointment_location']['longitude'],
                'CampaingsType' => '3',
                'PayMentType' => ($apptDet['PayMentType'] == 1 ? 2 : 1)
            );
            $CampainData = $this->Campaings($arrayCampain);
            $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "applicableForXrides" => $CampainData['flag'], "DriverArrivedTimeStampServer" => time(), "mas_id" => (int) $driverId), array("_id" => (int) $args['ent_booking_id']));
        } else if ($args['ent_response'] == '8') {
            $CustomerNotpaid = $this->getCustomerFroud(array('slave_id' => $apptDet['slave_id']['slaveId']));
            if (!empty($CustomerNotpaid)) {
                $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "BookingStartTimeStampServer" => time(), "mas_id" => (int) $driverId, 'pickup_route' => $args['pickup_route'], 'slave_id.lastDue' => $CustomerNotpaid['lastDue'], 'slave_id.sumLastDue' => $CustomerNotpaid['sumLastDue'], 'slave_id.sumAllEarning' => $CustomerNotpaid['sumAllEarning']), array("_id" => (int) $args['ent_booking_id']));
            } else {
                $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "BookingStartTimeStampServer" => time(), "mas_id" => (int) $driverId, 'pickup_route' => $args['pickup_route']), array("_id" => (int) $args['ent_booking_id']));
            }
//            $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "BookingStartTimeStampServer" => time(), "mas_id" => (int) $driverId, 'pickup_route' => $args['pickup_route']), array("_id" => (int) $args['ent_booking_id']));
        } else if ($args['ent_response'] == '9') {

            $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) ($updateInvoice['invoiceData']['MininumAmtToCollect'] <= 0 ? 9 : ($apptDet['PayMentType'] == 1 ? 9 : 9)), "Drop_location.latitude" => isset($args['ent_drop_lat']) ? $args['ent_drop_lat'] : "", "Drop_location.longitude" => isset($args['ent_dropLong']) ? $args['ent_dropLong'] : "", "Drop_address" => $apptDet['Drop_address'] == "" ? $args['ent_dropAddress'] : $apptDet['Drop_address'], "drop_dt" => $this->curr_date_time, "appointment_id" => $apptId, 'routeImg' => $url['url']), array("_id" => (int) $args['ent_booking_id']));
            $cond = array('status' => 3, 'apptStatus' => 0);
            $this->MongoClass->update('location', $cond, array('user' => (int) $this->User['entityId']));
            $mail = new sendAMail(APP_SERVER_HOST);
            $apptDet['routeImg'] = $url['url'];
            $apptDet['drop_dt'] = $this->curr_date_time;
            $push['invoMail'] = $mail->sendInvoice($this->User, array('email' => $apptDet['slave_id']['email'], 'first_name' => $apptDet['slave_id']['SlaveName']), $apptDet, $updateInvoice['invoiceData']);


            list($date, $time) = explode(' ', $this->curr_date_time);
            list($year, $month, $day) = explode('-', $date);
            list($hour, $minute, $second) = explode(':', $time);

            $EndTime = mktime($hour, $minute, $second, $month, $day, $year);
            $statusLog = $this->mongo->selectCollection('statusLog');
            $statusLog->update(array('master' => (int) $this->User['entityId'], 'status' => 5, 'bid' => (int) $args['ent_booking_id']), array('$set' => array('status' => 6, 'EndTime' => $EndTime, 'dist' => ((double) $args['ent_dist'] > 0 ? (double) $args['ent_dist'] : 0))));
            $statusLog->insert(array('master' => (int) $this->User['entityId'], 'status' => 3, 'time' => $EndTime, 'startTime' => $EndTime, "EndTime" => 0, 'EndTimeGurentee' => $EndTime));

//            applicableForXrides

            if ($apptDet['applicableForXrides'] == 0) {
                $CampainData = $this->Campaings(array('CampaingsType' => '4', 'PayMentType' => ($apptDet['PayMentType'] == 1 ? 2 : 1), 'user_id' => (int) $apptDet['slave_id']['slaveId']));
                $this->mongo->selectCollection('campaindata')->insert($CampainData);
            }
        }

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateAppointment);
        else {
            $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
            $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
            $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;

            if (($updateInvoice['invoiceData']['MininumAmtToCollect'] <= 0 && $args['ent_response'] == '9') || $args['ent_response'] == '7' || $args['ent_response'] == '8')
                $this->_sendPush($this->User['entityId'], array($apptDet['slave_id']['slaveId']), $message, $noteType, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent);


            $pubnubContent = array('a' => 14, 'bid' => $apptDet['_id'], 's' => $args['ent_response'], 'm' => $message);

            $out = array('push1' => $push, 'push' => $aplPushContent);
            $out['pubnub'] = $this->pubnub->publish(array(
                'channel' => 'dispatcher',
                'message' => $pubnubContent
            ));

            //maximum amount he can collect


            if ($errNum == 59) {
                $errMsgArr = $this->_getStatusMessage($errNum);
                return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'invoice' => $updateInvoice['invoiceData'], 'appointment_dt' => $apptDet['appointment_dt'], 'drop_dt' => $this->curr_date_time);
            } else {
                return $this->_getStatusMessage($errNum);
            }
        }
    }

    protected function updateApptStatus($args) {

//         $notifications = $this->mongo->selectCollection('tesmaddyamday');
//        $notifications->insert($args);
//        $args = $this->MongoClass->get_one('updateapptstatus',array('_id' =>  new MongoId('57f9000f861e536e0e8b4572')));

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id ');
        else if ($args['ent_response'] == '')
            return $this->_getStatusMessage(1, 'Response type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if (($args['ent_reponse'] == '9' && $args['ent_dist'] == '' && $args['ent_dropLat'] == '' && $args['ent_dropLong'] == '' && $args['ent_dropAddress'] == ''))
            return $this->_getStatusMessage(1, 'not able to complete ');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;


        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));
        if ($apptDet['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);

        if ($apptDet['status'] == '4')
            return $this->_getStatusMessage(41, 3);

        if ($apptDet['status'] == '5')
            return $this->_getStatusMessage(82, 82);

        if ($apptDet['status'] == '9')
            return $this->_getStatusMessage(75, 82);

        if ($apptDet['status'] == '10')
            return $this->_getStatusMessage(72, 72);



        $message = $this->__getAppointmnetStatus($args['ent_response'], $this->User);
        if ($args['ent_response'] == '6') {
            $errNum = 57;
            $this->MongoClass->update('location', array("user" => (int) $this->User['entityId']), array("status" => 5, "apptStatus" => (int) $args['ent_response']));
        } else if ($args['ent_response'] == '7') {
            $errNum = 58;
            $this->MongoClass->update('location', array("user" => (int) $this->User['entityId']), array("status" => 5, "apptStatus" => (int) $args['ent_response']));
        } else if ($args['ent_response'] == '8') {
            $errNum = 83;
            $this->MongoClass->update('location', array("user" => (int) $this->User['entityId']), array("status" => 5, "apptStatus" => (int) $args['ent_response']));
        } else if ($args['ent_response'] == '9') {
            $errNum = 59;
            $url = $this->get_app_route_img($apptDet, $args);
            $updateInvoice = $this->__UpdateApptDetails($apptDet, $args, $url);

            if (isset($updateInvoice['invoiceData'])) {
                $updateAppointment = $this->MongoClass->updatewithpush('appointments', array('invoice' => $updateInvoice['invoiceData']), array("_id" => (int) $args['ent_booking_id']));
            } else {
                if ($updateInvoice['errNum'] == 16) {
                    $this->MongoClass->update('appointments', array('PayMentType' => "2"), array("_id" => (int) $args['ent_booking_id']));
                    return $updateInvoice;
                }
                return $this->_getStatusMessage(56, $updateInvoice);
            }
            $updateInvoice['invoiceData']['PayMentType'] = $apptDet['payment_type'];

            $insertAppointmentQry = "insert into appointment(mas_id,slave_id,created_dt,last_modified_dt,status,appointment_dt,address_line1,drop_addr1,appt_lat,appt_long,amount,appt_type,payment_type,
            type_id,app_owner_pl,txn_id,mas_earning,pg_commission,app_commission,payment_status,airport_fee,discount,mongoId,BuildAmout,duration,app_distance) 
            values('" . $this->User['entityId'] . "','" . $apptDet['slave_id']['slaveId'] . "','" . $apptDet['appointment_dt'] . "','" . $this->curr_date_time . "','9','" . $apptDet['appointment_dt'] . "','" . $apptDet['appointment_address'] . "','" . $args['ent_dropAddress'] . "','" . $apptDet['appointment_location']['latitude'] . "','" . $apptDet['appointment_location']['latitude'] . "','" . $updateInvoice['invoiceData']['amount'] . "','" . $apptDet['appt_type'] . "','" . $apptDet['payment_type'] . "','" . $apptDet['vehicleType']['typeId'] . "'," . " '" . $updateInvoice['invoiceData']['profitLoss'] . "','" . $updateInvoice['invoiceData']['txn_id'] . "','" . $updateInvoice['invoiceData']['mas_earning'] . "'," . " '" . $updateInvoice['invoiceData']['pg_commission'] . "','" . $updateInvoice['invoiceData']['app_commission'] . "','1'," . "'" . $updateInvoice['invoiceData']['airportFee'] . "','" . $updateInvoice['invoiceData']['discountVal'] . "','" . $apptDet['_id'] . "','" . $updateInvoice['invoiceData']['BuildAmout'] . "','" . $updateInvoice['invoiceData']['TripTime'] . "','" . $updateInvoice['invoiceData']['TripDistance'] . "')";
//          $notifications123 = $this->mongo->selectCollection('tesmaddyamday123');
//        $notifications123->insert(array('test' => $insertAppointmentQry));

            mysql_query($insertAppointmentQry, $this->db->conn);
            $apptId = mysql_insert_id();
            if ($apptId < 0)
                return $this->_getStatusMessage(3, $insertAppointmentQry);
        } else {
            return $this->_getStatusMessage(56, 56);
        }

        $aplPushContent = array('alert' => $message, 'nt' => $args['ent_response'], 'sound' => 'default');
        $andrPushContent = array("payload" => $message, 'action' => $args['ent_response']);
//pickup_route

        $driverId = $this->User['entityId'];
        if ($args['ent_response'] == '7') {
            $arrayCampain = array('ent_latitude' => $apptDet['appointment_location']['latitude'],
                'ent_longitude' => $apptDet['appointment_location']['longitude'],
                'CampaingsType' => '3',
                'PayMentType' => ($apptDet['PayMentType'] == 1 ? 2 : 1)
            );
            $CampainData = $this->Campaings($arrayCampain);
            $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "applicableForXrides" => $CampainData['flag'], "DriverArrivedTimeStampServer" => time(), "mas_id" => (int) $driverId), array("_id" => (int) $args['ent_booking_id']));
        } else if ($args['ent_response'] == '8') {
            $CustomerNotpaid = $this->getCustomerFroud(array('slave_id' => $apptDet['slave_id']['slaveId']));
            if (!empty($CustomerNotpaid)) {
                $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "BookingStartTimeStampServer" => time(), "mas_id" => (int) $driverId, 'pickup_route' => $args['pickup_route'], 'slave_id.lastDue' => $CustomerNotpaid['lastDue'], 'slave_id.sumLastDue' => $CustomerNotpaid['sumLastDue'], 'slave_id.sumAllEarning' => $CustomerNotpaid['sumAllEarning']), array("_id" => (int) $args['ent_booking_id']));
            } else {
                $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "BookingStartTimeStampServer" => time(), "mas_id" => (int) $driverId, 'pickup_route' => $args['pickup_route']), array("_id" => (int) $args['ent_booking_id']));
            }
//            $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) $args['ent_response'], "BookingStartTimeStampServer" => time(), "mas_id" => (int) $driverId, 'pickup_route' => $args['pickup_route']), array("_id" => (int) $args['ent_booking_id']));
        } else if ($args['ent_response'] == '9') {

            $tiptime = strtotime($this->curr_date_time) + $this->expireTimeForTip;
            $updateAppointment = $this->MongoClass->update('appointments', array("status" => (int) ($updateInvoice['invoiceData']['MininumAmtToCollect'] <= 0 ? 9 : ($apptDet['PayMentType'] == 1 ? 9 : 9)), "Drop_location.latitude" => isset($args['ent_drop_lat']) ? $args['ent_drop_lat'] : "", "Drop_location.longitude" => isset($args['ent_dropLong']) ? $args['ent_dropLong'] : "", "Drop_address" => $apptDet['Drop_address'] == "" ? $args['ent_dropAddress'] : $apptDet['Drop_address'], "Tip_settle" => '0', "Tip_time" => $tiptime, "drop_dt" => $this->curr_date_time, "appointment_id" => $apptId, 'routeImg' => $url['url']), array("_id" => (int) $args['ent_booking_id']));


//            $cond = array('status' => 3, 'apptStatus' => 0);
//            $this->MongoClass->update('location', $cond, array('user' => (int) $this->User['entityId']));
//            $mail = new sendAMail(APP_SERVER_HOST);
//            $apptDet['routeImg'] = $url['url'];
//            $apptDet['drop_dt'] = $this->curr_date_time;
//            $push['invoMail'] = $mail->sendInvoice($this->User, array('email' => $apptDet['slave_id']['email'], 'first_name' => $apptDet['slave_id']['SlaveName']), $apptDet, $updateInvoice['invoiceData']);


            list($date, $time) = explode(' ', $this->curr_date_time);
            list($year, $month, $day) = explode('-', $date);
            list($hour, $minute, $second) = explode(':', $time);

            $EndTime = mktime($hour, $minute, $second, $month, $day, $year);
            $statusLog = $this->mongo->selectCollection('statusLog');
            $statusLog->update(array('master' => (int) $this->User['entityId'], 'status' => 5, 'bid' => (int) $args['ent_booking_id']), array('$set' => array('status' => 6, 'EndTime' => $EndTime, 'dist' => ((double) $args['ent_dist'] > 0 ? (double) $args['ent_dist'] : 0))));
            $statusLog->insert(array('master' => (int) $this->User['entityId'], 'status' => 3, 'time' => $EndTime, 'startTime' => $EndTime, "EndTime" => 0, 'EndTimeGurentee' => $EndTime));

//            applicableForXrides

            if ($apptDet['applicableForXrides'] == 0) {
                $CampainData = $this->Campaings(array('CampaingsType' => '4', 'PayMentType' => ($apptDet['PayMentType'] == 1 ? 2 : 1), 'user_id' => (int) $apptDet['slave_id']['slaveId']));
                $this->mongo->selectCollection('campaindata')->insert($CampainData);
            }
        }

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateAppointment);
        else {


            $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
            $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
            $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;

            if (($updateInvoice['invoiceData']['MininumAmtToCollect'] <= 0 && $args['ent_response'] == '9') || $args['ent_response'] == '7' || $args['ent_response'] == '8')
                $this->_sendPush($this->User['entityId'], array($apptDet['slave_id']['slaveId']), $message, $noteType, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent);


            $pubnubContent = array('a' => 14, 'bid' => $apptDet['_id'], 's' => $args['ent_response'], 'm' => $message);

            $out = array('push1' => $push, 'push' => $aplPushContent);
            $out['pubnub'] = $this->pubnub->publish(array(
                'channel' => 'dispatcher',
                'message' => $pubnubContent
            ));

            //maximum amount he can collect


            if ($errNum == 59) {
                $errMsgArr = $this->_getStatusMessage($errNum);
                return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'invoice' => $updateInvoice['invoiceData'], 'appointment_dt' => $apptDet['appointment_dt'], 'drop_dt' => $this->curr_date_time);
            } else {
                return $this->_getStatusMessage($errNum);
            }
        }
    }

    public function testtrigger() {

//        $Refferal = new campaign();
//        $returnData = $Refferal->triggerRewardForCompletingxrides(array('CampaingsType' => '4','PayMentType' => '1','user_id' => (int) 749));
        $couponsColl = $this->mongo->selectCollection('Campanians');
        $appointment = $this->mongo->selectCollection('appointments');
        $args['PayMentType'] = '2';
        $args['user_id'] = 760;
        $args['PayMentType'] = '1';
        $GetReferral = $couponsColl->findOne(array('_id' => new MongoId('585ce0a6c791525a258b456c')));
//        $completeRides = $appointment->find(array('slave_id.slaveId' => (int)758,"PayMentType" => ($args['PayMentType'] == '1' ? '2' : '1'),"status" => array('$in' => [8,9])));
        $completeRides = $appointment->find(array('slave_id.slaveId' => (int) $args['user_id'], "PayMentType" => ($args['PayMentType'] == '1' ? '2' : '1'), "status" => array('$in' => [8, 9])));
        if ($completeRides->count() >= $GetReferral['xrides']['xrides_Unit_or_amount'] && ($GetReferral['xrides']['xrides_Paytype'] == $args['PayMentType'] || $GetReferral['xrides']['xrides_Paytype'] == '3')) {
            $applicable = 1;
        } else
            $return = array('flag' => 2, "Xrides_completed" => $completeRides->count(), 'child' => $args['user_id'], "PayMentType" => ($args['PayMentType'] == '1' ? '2' : '1'));

//        $result = $couponsColl->findOne(array('UserId' => (int) 755, 'coupon_type' => "USERCAMPAIN", "Status" => 1));
//        return $couponsColl->update(array('UserId' => (int) $result["ParantId"], 'referred.userId' => (int) 755), array('$set' => array('referred.$.status' => 1)));
        return array('test' => $return, 'capable' => $applicable);
        $couponsColl = $this->mongo->selectCollection('Campanians');
        $appointment = $this->mongo->selectCollection('appointments');
        $GetReferral = $couponsColl->findOne(array('_id' => new MongoId('585bba50c79152bd038b4567')));
        $completeRides = $appointment->find(array('slave_id.slaveId' => (int) 749, "status" => 9));

        $totalamount = $appointment->aggregate(array('$match' => array('slave_id.slaveId' => (int) 751, "PayMentType" => '2', 'status' => 9)), array('$unwind' => '$invoice'), array('$group' => array('_id' => null, 'total' => array('$sum' => '$invoice.amount'))));
        return array('test' => $totalamount['result'][0]['total']);
        $args['PayMentType'] = "2";
        if ($GetReferral['xrides']['xrides_Type'] == 1) { // x Rides
            $completeRides = $appointment->find(array('slave_id.slaveId' => (int) 749, "PayMentType" => "1", "status" => 9));
            if ($completeRides->count() >= $GetReferral['xrides']['xrides_Unit_or_amount'] && ($GetReferral['xrides']['xrides_Unit_or_amount'] == $args['PayMentType'] || $GetReferral['xrides']['xrides_Paytype'] == '3')) {
                $applicable = 1;
            } else
                $return = array('flag' => 2, "Xrides_completed" => $completeRides->count());
        } else if ($GetReferral['xrides']['xrides_Type'] == 2) { // x amount of rides
            $totalamount = $appointment->aggregate(array('$match' => array('slave_id.slaveId' => (int) 749, 'status' => 9)), array('$unwind' => '$invoice'), array('$group' => array('_id' => null, 'total' => array('$sum' => '$invoice.amount'))));
            if ($totalamount >= $GetReferral['xrides']['xrides_Unit_or_amount'] && ($GetReferral['xrides']['xrides_Unit_or_amount'] == $args['PayMentType'] || $GetReferral['xrides']['xrides_Paytype'] == '3')) {
                $applicable = 1;
            } else
                $return = array('flag' => 2, "Xrides_amount" => $totalamount);
        }
        if ($applicable == 1) {
            $data = 1;
        }
        return array('test' => $applicable, 'data' => $data, 'getre' => $GetReferral['xrides']['xrides_Unit_or_amount'], 'compl' => $completeRides->count());
    }

    /*
     * 
     * get app image
     * 
     */

    public function testAppRoutes() {
        $cursor = $this->MongoClass->get_one('appointments', array('_id' => (int) 6513));

//        $route = json_decode($cursor['app_route']);
//        foreach ($route as $val) {
//            $points[] = array(trim($val->lat), trim($val->long));
//        }
//        $encoded = Polyline::encode($points);
//        $url = 'https://maps.googleapis.com/maps/api/directions/json?origin=13.0282443,77.5885169&destination=13.0286779,77.5887332&waypoints=enc:' . $encoded . ':&key=AIzaSyCK5bz3K1Ns_BASkAcZFLAI_oivKKo98VE';
//        $ch = curl_init();
//        curl_setopt($ch, CURLOPT_URL, $url);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
//        $response = json_decode(curl_exec($ch), true);
//
//        $getMapImage = "http://maps.googleapis.com/maps/api/staticmap?key=AIzaSyCK5bz3K1Ns_BASkAcZFLAI_oivKKo98VE&sensor=false&path=color:0xa3ccfe00ff|weight:3|enc:oqonAg_qxMT|EDvADfAcAFI@A@CPCZr@TxBj@bAV`ATRcAVqARqALw@Ju@OCNBTsAVaBHw@@{@QgBM{@k@mCQ{@aBV{AT@PQCQCUD_Bp@s@V]Lj@dAX~@Nl@Pv@Fd@qAH&markers=icon:http://52.59.93.50/LabaihPQ/pics/pickup.png|13.0282443,77.5885169&markers=icon:&markers=icon:http://52.59.93.50/LabaihPQ/pics/drop.png|13.0286779,77.5887332&size=500x500";
//        https://maps.googleapis.com/maps/api/timezone/json?location=13.028847694397,77.5895156860352&timestamp=1458000000&key=AIzaSyDlQKgAL0TjHkLle5iRJ_WbS1b97NEGSjs
        $args['ent_dropLong'] = $cursor['Drop_location']['longitude'];
        $args['ent_drop_lat'] = $cursor['Drop_location']['latitude'];
        $args['app_route'] = $cursor['app_route'];



        $data = $this->get_app_route_img($cursor, $args);
        $duration = $distance = 0;
        foreach ($data['response']['routes'][0]['legs'] as $res) {
            $distance +=$res['distance']['value'];
            $duration +=$res['duration']['value'];
        }


        $route = json_decode($cursor['app_route'], true);
        $origins = "";

        $interval = round(count($route) / 100);
        $counter = 1;
        foreach ($route as $val) {

            if (($counter % $interval) === 0) {
                $origins .= $latlong['lat'] . ',' . $latlong['long'] . '|';
            }
            $counter++;
        }


        $finalsum = 0;
        for ($var = 0; $var < count($route) - 1; $var++) {
            $sumofdistance = $distanceData[] = $this->distance($route[$var]['lat'], $route[$var]['long'], $route[$var + 1]['lat'], $route[$var + 1]['long']);
            $finalsum = $sumofdistance + $finalsum;
        }

        $getDirectionFormMatrix = $this->gettest_DirectionFormMatrix(str_replace(" ", "", rtrim($origins, '|')));
        $googleDis[] = $getDirectionFormMatrix['distance'];




        return array('finalsum' => $finalsum, 'distanceVal' => $distanceData, 'duration' => $duration, 'distance' => $distance, 'routes' => $data, 'googleDistance' => $getDirectionFormMatrix, 'origens' => rtrim($origins, '|'));
    }

    function distance($lat1, $lon1, $lat2, $lon2) {

//        if(APP_DISTANCE_METRIC == "KG")
        $unit = "K";

        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        $unit = strtoupper($unit);

        if ($unit == "K") {
            return ($miles * 1.609344);
        } else {
            return $miles;
        }
    }

    public function testPayment() {

        $chargeCustomerArr = array('email' => "ashish@mobifyi.com", "name" => "ashish", 'token_name' => '4320EBA88D706621E053321E320A48B5', 'amount' => (int) ((float) 1 * 100), 'currency' => 'SAR', 'merchant_reference' => 5642687719, 'description' => "booking transection");
        require 'payfort/payfort-php-sdk-master/PayfortIntegration.php';
        $paymentRequest = new PayfortIntegration();
        $customer = $paymentRequest->PaymentReqeust($chargeCustomerArr);

        if ($customer['response_message'] == Success) {
            
        }

//        if ($customer['response_message'] != 'Success') {
//
//            $query = "update appointment set payment_type = 2 where appointment_id = '" . $apptDet['appointment_id'] . "'";
//            $resutlUp = mysql_query($query, $this->db->conn);
//
//            if (mysql_affected_rows() <= 0) {
//                return $this->_getStatusMessage(3, 3);
//            }
//
//            $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
//            $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
//            $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;
//            $noteType = 101;
//            $message = 'CARD PAYMENT HAS DECLINED! PLEASE PAY VIA CASH!';
//
//            $aplPushContent = array('alert' => $message, 't' => $apptDet['appt_type'], 'nt' => $noteType, 'd' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'sound' => 'default', 'id' => $apptDet['appointment_id']); //, 'n' => $this->User['firstName'] . ' ' . $this->User['last_name']
//            $andrPushContent = array("payload" => $message, 't' => $apptDet['appt_type'], 'action' => $noteType, 'sname' => $this->User['firstName'] . ' ' . $this->User['last_name'], 'dt' => $args['ent_appnt_dt'], 'smail' => $this->User['email'], 'id' => $apptDet['appointment_id']);
//
//            $push['push'] = $this->_sendPush($this->User['entityId'], array($pasData['slave_id']), $message, $noteType, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent, $apptDet['user_device']);
//
//
//            return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => 'CARD PAYMENT HAS DECLINED! PLEASE TAKE PAYMENT VIA CASH!', 'code' => $customer['result']['code']);
//        }
//
//        $tokenId = $customer['fort_id'];

        return array('return' => $customer, 'test' => $this->encrypt_decrypt('encrypt', 15));
    }

    public function get_app_route_img($cursor, $args = array()) {

        $route = json_decode($args['app_route']);

        if ($route == '' || $route == null || count($route) < 3) {
            $appt_lat = $cursor['appointment_location']['latitude'];
            $appt_lng = $cursor['appointment_location']['longitude'];

            $drop_lat = $args['ent_drop_lat'];
            $drop_lng = $args['ent_dropLong'];

            $img_rot[0] = trim($appt_lat) . "," . trim($appt_lng);
            $img_rot[1] = trim($drop_lat) . "," . trim($drop_lng);

            $url = 'https://maps.googleapis.com/maps/api/directions/json?origin=' . $img_rot[0] . '&destination=' . $img_rot[1] . '&key=AIzaSyCK5bz3K1Ns_BASkAcZFLAI_oivKKo98VE';
        } else {
            $points = array();
            $counter = 1;
            $interval = round(count($route) / 22);
            $counter = 1;
            foreach ($route as $val) {

                if (($counter % $interval) === 0) {
                    $points[] = array(trim($val->lat), trim($val->long));
                }
                $counter++;
            }

            $encoded = Polyline::encode($points); //rtrim($Beforeencoded, '|enc:'); //[0].':|via:enc:'.$Beforeencoded[1].':';

            $img_rot[0] = trim($route[0]->lat) . "," . trim($route[0]->long);
            $img_rot[1] = trim($val->lat) . "," . trim($val->long);
            $url = 'https://maps.googleapis.com/maps/api/directions/json?origin=' . $img_rot[0] . '&destination=' . $img_rot[1] . '&waypoints=enc:' . $encoded . ':&key=AIzaSyCK5bz3K1Ns_BASkAcZFLAI_oivKKo98VE&waypoints=optimize:true';
        }


        $img_rot[0] = '&markers=icon:http://52.59.93.50/LabaihPQ/pics/pickup.png|' . $img_rot[0];
        $img_rot[1] = '&markers=icon:http://52.59.93.50/LabaihPQ/pics/drop.png|' . $img_rot[1];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $prev = $response = json_decode(curl_exec($ch), true);

        if ($response["status"] != "OK") {
            $appt_lat = $cursor['appointment_location']['latitude'];
            $appt_lng = $cursor['appointment_location']['longitude'];

            $drop_lat = $args['ent_drop_lat'];
            $drop_lng = $args['ent_dropLong'];

            $newUrl = 'https://maps.googleapis.com/maps/api/directions/json?origin=' . trim($appt_lat) . "," . trim($appt_lng) . '&destination=' . trim($drop_lat) . "," . trim($drop_lng) . '&key=AIzaSyCK5bz3K1Ns_BASkAcZFLAI_oivKKo98VE';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $newUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            $response = json_decode(curl_exec($ch), true);
        }


        $route = json_decode($args['app_route'], true);
        for ($var = 0; $var < count($route) - 1; $var++) {
            $distanceData[] = $this->distance($route[$var]['lat'], $route[$var]['long'], $route[$var + 1]['lat'], $route[$var + 1]['long']);
        }

        $url = "http://maps.googleapis.com/maps/api/staticmap?key=AIzaSyCK5bz3K1Ns_BASkAcZFLAI_oivKKo98VE&sensor=false&path=color:0xa3ccfe00ff|weight:3|enc:" . $response['routes'][0]['overview_polyline']['points'] . $img_rot[0] . $img_rot[1]; // .'&size=400x400';
        return array('points' => $points, 'url' => $url, 'response' => $response, 'count' => count($route), 'CalculatedDist' => array_sum($distanceData));
    }

    /*
     * get approx lat longs
     */

    public function getRandamArray($args) {

        $cursor = $this->MongoClass->get_one('appointments', array('_id' => (int) 3629));
        $route = json_decode($cursor['app_route']);
        $interval = round(count($route) / 22);
        $counter = 1;
        foreach ($route as $val) {

            if (($counter % $interval) === 0) {
                $points[] = array(trim($val->lat), trim($val->long));
            }
            $counter++;
        }

        return array('count' => count($route), 'interval' => $interval, 'pointers' => count($points), 'counter' => $counter);
    }

    /*
     * Method name: getMySlots
     * Desc: get master slots
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function getMySlots($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $getScheduleQry = "select sh.id, sh.day_number, sh.start, sh.mas_id, sh.duration_in_mts, sh.ref_count from master_schedule sh, master doc ";
        $getScheduleQry .= "where sh.mas_id = doc.mas_id and doc.mas_id = '" . $this->User['entityId'] . "' order by sh.start asc";

        $getScheduleRes = mysql_query($getScheduleQry, $this->db->conn);

        $appts = $daysAvlb = $avlbSlots = $avlbDates = array();

        while ($appointment = mysql_fetch_assoc($getScheduleRes)) {

            $appts[$appointment['day_number']]['day'] = $appointment['day_number'];
            $appts[$appointment['day_number']]['time'][] = array('from' => date('h:i a', strtotime($appointment['start'])), 'to' => date("h:i a", strtotime('+' . (int) $appointment['duration_in_mts'] . ' minutes', strtotime($appointment['start']))), 'flag' => $appointment['ref_count']);
        }

        $errMsgArr = $this->_getStatusMessage(21, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'slots' => $appts);
    }

    /*
     * Method name: getMySlots
     * Desc: get master slots
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function updateTipOLD($args) {

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');
        else if ($args['ent_tip'] == '')
            return $this->_getStatusMessage(1, 'Tip amount');
//        else if ($args['ent_date_time'] == '')
//            return $this->_getStatusMessage(1, 'Date time');
        //$this->curr_date_time = urldecode($args['ent_date_time']);
//        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');
//
//        if (is_array($returned))
//            return $returned;

        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));

        $amount = round(($apptDet['invoice'][0]['amount'] + $args['ent_tip']), 2);
        $finalAmount = round(($apptDet['invoice'][0]['finalAmount'] + $args['ent_tip']), 2);
        $subtotal = round(($apptDet['invoice'][0]['subtotal'] + $args['ent_tip']), 2);
        $masEarning = round(($apptDet['invoice'][0]['mas_earning'] + $args['ent_tip']), 2);



        $Time = time();
        // $updateInvoice['invoiceData'] = $args['ent_tip'];
        // updatewithpush('appointments', array('invoice' => $updateInvoice['invoiceData']),
        $updateAppointment = $this->MongoClass->update('appointments', array("invoice.0.tip" => (int) $args['ent_tip'], "invoice.0.amount" => (float) $amount, "invoice.0.finalAmount" => (float) $finalAmount, "invoice.0.subtotal" => (float) $subtotal, "invoice.0.mas_earning" => (float) $masEarning, "Tip_settle" => '1'), array("_id" => (int) $args['ent_booking_id']));
        if ($updateAppointment['flag'] == 1) {
            return $this->_getStatusMessage(142, $updateResponseQry);
        } else {






            $masterDet = $this->MongoClass->get_one('location', array("user" => (int) $apptDet['mas_id']));
            $pubnubContent = array('a' => 9, 'bid' => $args['ent_booking_id'], 's' => '9', 'msg' => $apptDet['slave_id']['SlaveName'] . 'has tip you an amount of $' . $args['ent_tip'] . ' for BID: ' . $args['ent_booking_id']);
            $drivchn = substr($masterDet['chn'], 3); // $apptDet['chn'];

            $out['pubnub'] = $this->pubnub->publish(array(
                'channel' => qdl_ . $drivchn,
                'message' => $pubnubContent
            ));

            $lastid = $this->mongo->selectCollection('JAIN');
            $lastid->insert(array('driverchannel' => qdl_ . $drivchn, 'array' => $pubnubContent));

            return $this->_getStatusMessage(98, 2);
        }
    }

    protected function updateTip($args) {

//         $lastid = $this->mongo->selectCollection('JAIN');        
//        $lastid->insert($args);

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');
        else if ($args['ent_tip'] == '')
            return $this->_getStatusMessage(1, 'Tip amount');
//        else if ($args['ent_date_time'] == '')
//            return $this->_getStatusMessage(1, 'Date time');
        //$this->curr_date_time = urldecode($args['ent_date_time']);
//        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');
//
//        if (is_array($returned))
//            return $returned;

        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));

        $amount = round(($apptDet['invoice'][0]['amount'] + $args['ent_tip']), 2);
        $finalAmount = round(($apptDet['invoice'][0]['finalAmount'] + $args['ent_tip']), 2);
        $subtotal = round(($apptDet['invoice'][0]['subtotal'] + $args['ent_tip']), 2);
        $masEarning = round(($apptDet['invoice'][0]['mas_earning'] + $args['ent_tip']), 2);

        $transactionId = '';


        if ($apptDet['PayMentType'] == '1') {

            $query = "select stripe_id from slave where slave_id = '" . $apptDet['slave_id']['slaveId'] . "'";

            $apptDet123 = mysql_fetch_assoc(mysql_query($query, $this->db->conn));

            $chargeCustomerArr = array('stripe_id' => $apptDet123['stripe_id'], 'amount' => (int) ((float) $finalAmount * 100), 'currency' => PAYMENT_BASE_CURRENCY, 'description' => 'From ' . $apptDet['slave_id']['email']);

            $customer = $this->stripe->apiStripe('chargeCard', $chargeCustomerArr);

            if ($customer['error']) {

//                $query = "update appointment set payment_type = 2 where appointment_id = '" . $apptDet['_id'] . "'";
//                $resutlUp = mysql_query($query, $this->db->conn);
//
//                if (mysql_affected_rows() <= 0) {
//                    return $this->_getStatusMessage(3, 3);
//                }
//                $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
//                $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
//                $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;
//                $noteType = 101;
//                $message = 'CARD PAYMENT HAS DECLINED! PLEASE PAY VIA CASH!';
//
//                $aplPushContent = array('alert' => $message, 't' => $apptDet['appt_type'], 'nt' => $noteType, 'd' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'sound' => 'default', 'id' => $apptDet['_id']); //, 'n' => $this->User['firstName'] . ' ' . $this->User['last_name']
//                $andrPushContent = array("payload" => $message, 't' => $apptDet['appt_type'], 'action' => $noteType, 'sname' => $this->User['firstName'] . ' ' . $this->User['last_name'], 'dt' => $args['ent_appnt_dt'], 'smail' => $this->User['email'], 'id' => $apptDet['_id']);
//
//                $push['push'] = $this->_sendPush($this->User['entityId'], array($pasData['slave_id']), $message, $noteType, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent, $apptDet['user_device']);


                return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => 'CARD PAYMENT HAS DECLINED! PLEASE TAKE PAYMENT VIA CASH!', 'code' => $customer['result']['code']);
            }



            $transactionId = $customer['id'];
        }






        $Time = time();
        // $updateInvoice['invoiceData'] = $args['ent_tip'];
        // updatewithpush('appointments', array('invoice' => $updateInvoice['invoiceData']),
        $updateAppointment = $this->MongoClass->update('appointments', array("invoice.0.tip" => (int) $args['ent_tip'], "invoice.0.amount" => (float) $amount, "invoice.0.finalAmount" => (float) $finalAmount, "invoice.0.subtotal" => (float) $subtotal, "invoice.0.mas_earning" => (float) $masEarning, "invoice.0.txn_id" => $transactionId, "Tip_settle" => '1'), array("_id" => (int) $args['ent_booking_id']));
        if ($updateAppointment['flag'] == 1) {
            return $this->_getStatusMessage(142, $updateResponseQry);
        } else {




            $apptDet1 = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));

            $cond = array('status' => 3, 'apptStatus' => 0);
            $this->MongoClass->update('location', $cond, array('user' => (int) $apptDet['mas_id']));


            $mail = new sendAMail(APP_SERVER_HOST);
            $apptDet1['routeImg'] = $apptDet1['routeImg'];
            $apptDet1['drop_dt'] = $apptDet1['drop_dt'];
            $push['invoMail'] = $mail->sendInvoice($this->User, array('email' => $apptDet1['slave_id']['email'], 'first_name' => $apptDet1['slave_id']['SlaveName']), $apptDet1, $apptDet1['invoice'][0]);

            $masterDet = $this->MongoClass->get_one('location', array("user" => (int) $apptDet['mas_id']));
            $pubnubContent = array('a' => 9, 'bid' => $args['ent_booking_id'], 's' => '9', 'msg' => $apptDet['slave_id']['SlaveName'] . 'has tip you an amount of $' . $args['ent_tip'] . ' for BID: ' . $args['ent_booking_id']);
            $drivchn = substr($masterDet['chn'], 3); // $apptDet['chn'];
//            if($args['ent_tip'] != '0'){
//            $out['pubnub'] = $this->pubnub->publish(array(
//                'channel' => qdl_.$drivchn,
//                'message' => $pubnubContent
//            ));
//            }
//                    $lastid = $this->mongo->selectCollection('JAIN');        
//        $lastid->insert(array('driverchannel'=> qdl_.$drivchn, 'array' => $pubnubContent));

            return $this->_getStatusMessage(98, 2);
        }
    }

    /*
     * Method name: getMasterProfile
     * Desc: get master profile
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function getMasterProfile($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $explodeDateTime = explode(' ', $this->curr_date_time);
        $explodeDate = explode('-', $explodeDateTime[0]);

        $weekData = $this->week_start_end_by_date($this->curr_date_time);

        $selectMasterProfileQry = "select doc.pre_con,doc.first_name, doc.workplace_id, doc.last_name, doc.email, doc.license_num,doc.license_exp, doc.board_certification_expiry_dt, doc.mobile, doc.status, doc.profile_pic, avg(rat.star_rating) as avgRate, count(rat.review_dt) as totRats, (select count(appointment_id) from appointment where mas_id = doc.mas_id and status = 9) as cmpltApts, (select sum(mas_earning) from appointment where mas_id = doc.mas_id and DATE(appointment_dt) = '" . $explodeDateTime[0] . "' and status = 9) as today_earnings, (select amount from appointment where mas_id = doc.mas_id and status = 9 order by appointment_id DESC limit 0, 1) as last_billed_amount, (select sum(mas_earning) from appointment where mas_id = doc.mas_id and status = 9 and DATE(appointment_dt) BETWEEN '" . $weekData['first_day_of_week'] . "' and '" . $weekData['last_day_of_week'] . "') as week_earnings, (select sum(mas_earning) from appointment where mas_id = doc.mas_id and status = 9 and DATE_FORMAT(appointment_dt, '%Y-%m') = '" . $explodeDate[0] . '-' . $explodeDate[1] . "') as month_earnings, (select companyname from company_info where company_id = doc.company_id ) as compname,(select sum(mas_earning) from appointment where mas_id = doc.mas_id and status = 9) as total_earnings from master doc, master_ratings rat where doc.mas_id = rat.mas_id and doc.mas_id = '" . $this->User['entityId'] . "'";
        $selectMasterProfileRes = mysql_query($selectMasterProfileQry, $this->db->conn);

        if (mysql_num_fields($selectMasterProfileRes) <= 0)
            return $this->_getStatusMessage(3, $selectMasterProfileQry);

        $docData = mysql_fetch_assoc($selectMasterProfileRes);

        $getVehicleDataQry = "select wrk.workplace_id, wrk.Vehicle_Insurance_No, wrk.Vehicle_Insurance_Dt, wrk.License_Plate_No, (select wt.max_size from workplace_types wt, workplace w where w.type_id = wt.type_id and w.workplace_id = wrk.workplace_id) as capacity, (select v.vehiclemodel from vehiclemodel v, workplace w where w.Vehicle_Model = v.id and w.workplace_id = wrk.workplace_id) as vehicle_model, (select wt.type_name from workplace_types wt, workplace w where w.type_id = wt.type_id and w.workplace_id = wrk.workplace_id) as vehicle_type, wrk.Vehicle_Color from workplace wrk where wrk.workplace_id = '" . $docData['workplace_id'] . "'";

        $getVehicleDataRes = mysql_query($getVehicleDataQry, $this->db->conn);

        $vehicleData = mysql_fetch_assoc($getVehicleDataRes);

        $errMsgArr = $this->_getStatusMessage(21, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'data' => array('fName' => $docData['first_name'],
                'lName' => $docData['last_name'], 'email' => $docData['email'], 'type' => $docData['type_name'], 'mobile' => ($docData['pre_con'] . $docData['mobile']), 'status' => $docData['status'],
                'pPic' => $docData['profile_pic'], 'expertise' => $docData['expertise'], 'vehicleType' => $vehicleData['vehicle_type'], 'companyname' => $docData['compname'],
                'licNo' => $docData['license_num'], 'licExp' => ($docData['license_exp'] == '') ? '' : date('F d, Y', strtotime($docData['license_exp'])),
                'vehMake' => $vehicleData['vehicle_model'] . ' ' . $vehicleData['Vehicle_Color'], 'licPlateNum' => $vehicleData['License_Plate_No'], 'seatCapacity' => $vehicleData['capacity'], 'vehicleInsuranceNum' => $vehicleData['Vehicle_Insurance_No'], 'vehicleInsuranceExp' => $vehicleData['Vehicle_Insurance_Dt'],
                'avgRate' => round($docData['avgRate'], 1), 'totRats' => $docData['totRats'], 'cmpltApts' => $docData['cmpltApts'], 'todayAmt' => round($docData['today_earnings'], 2), 'lastBilledAmt' => round($docData['last_billed_amount'], 2), 'weekAmt' => round($docData['week_earnings'], 2), 'monthAmt' => round($docData['month_earnings'], 2), 'totalAmt' => round($docData['total_earnings'], 2)
        ));
    }

    /*
     * Method name: cancelAppointment
     * Desc: Passenger can Cancel an appointment requested
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function cancelAppointmentCheck($args) {
        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');
        if (is_array($returned))
            return $returned;


        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));
        $cancleSeconds = $this->__getConfig();
        $after_5min = date('Y-m-d H:i:s', (strtotime($apptDet['appointment_dt']) + ((int) ($cancleSeconds['cancelTime']) * 60)));
        return array('errFlag' => 0, 'flag' => (($this->curr_date_time >= $after_5min) ? 1 : 0), 'errNo' => 505, 'errMsg' => ($this->curr_date_time > $after_5min ? "Are you sure you want to cancel? Minimum fare will be applied for cancelling after " . $cancleSeconds['cancelTime'] . " minutes." : "Are you sure you want to cancel this trip?"));
    }

    protected function cancelAppointment($args) {


        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_mid'] == '')
            return $this->_getStatusMessage(1, 'mid');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $args['ent_appnt_dt'] = urldecode($args['ent_appnt_dt']);

        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));
        if ($apptDet['flag'] == 1)
            return $this->_getStatusMessage(32, $apptDet);

        if ($apptDet['status'] == '3')
            return $this->_getStatusMessage(44, 44);

        if ($apptDet['status'] == '4')
            return $this->_getStatusMessage(41, 3);

        if ($apptDet['status'] == '5')
            return $this->_getStatusMessage(82, 3);

        if ($apptDet['status'] == '9')
            return $this->_getStatusMessage(75, 3);

//        $docData = $this->_getEntityDet($args['ent_dri_email'], '1');
//        if()

        $cancleSeconds = $this->__getConfig();
        $after_5min = date('Y-m-d H:i:s', (strtotime($apptDet['appointment_dt']) + ((int) ($cancleSeconds['cancelTime']) * 60)));

        if ($this->curr_date_time >= $after_5min) {
            $cancelStatus = 3; //"cancel_status = '3', cancel_amt = '5', ";

            $finalAmount = ($apptDet['status'] == '6' ? round(($apptDet['vehicleType']['baseFare'] / 2), 2) : ($apptDet['status'] == '7' ? round(($apptDet['vehicleType']['baseFare']), 2) : $apptDet['vehicleType']['cancilation_fee']));

            if ($apptDet['PayMentType'] == '1') {

                $query = "select stripe_id from slave where slave_id = '" . $apptDet['slave_id']['slaveId'] . "'";

                $apptDet123 = mysql_fetch_assoc(mysql_query($query, $this->db->conn));

                $chargeCustomerArr = array('stripe_id' => $apptDet123['stripe_id'], 'amount' => (int) ((float) $finalAmount * 100), 'currency' => PAYMENT_BASE_CURRENCY, 'description' => 'From ' . $apptDet['slave_id']['email']);

                $customer = $this->stripe->apiStripe('chargeCard', $chargeCustomerArr);

                if ($customer['error']) {

//                $query = "update appointment set payment_type = 2 where appointment_id = '" . $apptDet['_id'] . "'";
//                $resutlUp = mysql_query($query, $this->db->conn);
//
//                if (mysql_affected_rows() <= 0) {
//                    return $this->_getStatusMessage(3, 3);
//                }

                    $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
                    $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
                    $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;
                    $noteType = 101;
                    $message = 'CARD PAYMENT HAS DECLINED! PLEASE PAY VIA CASH!';

                    $aplPushContent = array('alert' => $message, 't' => $apptDet['appt_type'], 'nt' => $noteType, 'd' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'sound' => 'default', 'id' => $apptDet['_id']); //, 'n' => $this->User['firstName'] . ' ' . $this->User['last_name']
                    $andrPushContent = array("payload" => $message, 't' => $apptDet['appt_type'], 'action' => $noteType, 'sname' => $this->User['firstName'] . ' ' . $this->User['last_name'], 'dt' => $args['ent_appnt_dt'], 'smail' => $this->User['email'], 'id' => $apptDet['_id']);

                    $push['push'] = $this->_sendPush($this->User['entityId'], array($pasData['slave_id']), $message, $noteType, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent, $apptDet['user_device']);


                    return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => 'CARD PAYMENT HAS DECLINED! PLEASE TAKE PAYMENT VIA CASH!', 'code' => $customer['result']['code']);
                }
            }

//            $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,txn_id) values ('" . $this->User['entityId'] . "',2,'" . round(-$finalAmount, 2) . "',now(),'" . ($finalAmount > 0 ? 1 : 2) . "','" . $apptDet['_id'] . "')";
//            mysql_query($query, $this->db->conn);
//            $DriverResp = $this->__insertDriverWallet(array('mas_id' => $apptDet['mas_id'], 'amount' => $finalAmount));
//            if ($DriverResp['flag'] == 1)
//                return $this->_getStatusMessage(3, $DriverResp['query']);
        } else {
            $cancelStatus = 2; //"cancel_status = '2', ";
        }

        $cancellatiodate = $this->curr_date_time;


        $updateAppointment = $this->MongoClass->update('appointments', array("status" => 4, 'amount' => $finalAmount, 'cancel_status' => $cancelStatus, "Reason" => $args['ent_cancel_type'], 'cancel_dt' => $cancellatiodate), array("_id" => (int) $args['ent_booking_id']));

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);


        $location = $this->mongo->selectCollection('location');

        $master = $location->findOne(array('user' => (int) $args['ent_mid']));

        $pubnubContent = array('a' => 10, 'dt' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'bid' => $apptDet['_id'], 't' => $apptDet['appt_type'], 'r' => $args['ent_cancel_type']);

        if (!is_null($master['listner']))
            $pushNum['pubnub'] = $this->pubnub->publish(array(
                'channel' => $master['listner'],
                'message' => $pubnubContent
            ));

        $message = "Passenger cancelled the Booking on " . APP_NAME . "!";

        $this->ios_cert_path = IOS_DRIVER_PEM_PATH;
        $this->ios_cert_pwd = IOS_DRIVER_PEM_PASS;
        $this->androidApiKey = ANDROID_DRIVER_PUSH_KEY;
        $aplPushContent = array('alert' => $message, 'nt' => '10', 'd' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'sound' => 'default', 'id' => $apptDet['_id'], 'r' => $args['ent_cancel_type'], 't' => $apptDet['appt_type']);
        $andrPushContent = array('payload' => $message, 'action' => '10', 'sname' => $this->User['firstName'], 'dt' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'bid' => $apptDet['_id'], 'r' => $args['ent_cancel_type'], 't' => $apptDet['appt_type']);
        $pushNum['push'] = $this->_sendPush($this->User['entityId'], array($apptDet['mas_id']), $message, '10', $this->User['firstName'], $this->curr_date_time, '1', $aplPushContent, $andrPushContent);


        $location->update(array('user' => (int) $apptDet['mas_id']), array('$set' => array('status' => 3, 'apptStatus' => 0)));

        $pubnubContent = array('a' => 14, 'bid' => $apptDet['_id'], 's' => 5, 'm' => 'passenger has cancelled');

        $out = array('push1' => $push, 'push' => $aplPushContent);
        $out['pubnub'] = $this->pubnub->publish(array(
            'channel' => 'dispatcher',
            'message' => $pubnubContent
        ));


        list($date, $time) = explode(' ', $this->curr_date_time);
        list($year, $month, $day) = explode('-', $date);
        list($hour, $minute, $second) = explode(':', $time);

        $EndTime = mktime($hour, $minute, $second, $month, $day, $year);
        $statusLog = $this->mongo->selectCollection('statusLog');
        $statusLog->update(array('master' => (int) $apptDet['mas_id'], 'status' => 5, 'bid' => (int) $args['ent_booking_id']), array('$set' => array('status' => 6, 'EndTime' => $EndTime, 'dist' => ((double) $args['ent_dist'] > 0 ? (double) $args['ent_dist'] : 0))));

//        $res = $this->sendComplainMail($args['ent_booking_id'], $this->User['city_id'], 2);

        if ($this->curr_date_time >= $after_5min)
            return $this->_getStatusMessage(43, $cancelApntQry . $after_5min);
        else
            return $this->_getStatusMessage(42, $cancelApntQry . $after_5min);
    }

//    protected function sendComplainMail($args, $cityid, $action) {
//
//        if ($action != 5) {
//            if ($cityid == '') {
//                $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));
//                $cityid = $apptDet['vehicleType']['cityid'];
//            }
//            $CityQuery = "select City_Name from city_available where City_Id = '" . $cityid . "'";
//            $cityId = mysql_fetch_assoc(mysql_query($CityQuery, $this->db->conn));
//        } else {
//            $cityId['City_Name'] = $cityid;
//        }
//
//
//        switch ($action) {
//            case 1: // customer block
////                $subject = "I rated my trip [" . $args['ent_booking_id'] . " - " . $cityId['City_Name'] . "] [" . $args['ent_rating_num'] . "] for [" . $args['ent_review_msg'] . "]";
//                $subject = "I rated my trip [" . $args['ent_rating_num'] . "] [" . $args['ent_booking_id'] . " - " . $cityId['City_Name'] . "] ";
//                $recipients = array(($this->User['email']) => $this->User['firstName']);
//                $to = "feedback@pqup.co";
//                $body = $args['ent_reason'];
//                break;
//            case 2:
////                 $subject = " Assistance request from [".$this->User['firstName']." - ".$this->User['entityId']."] for [".$args['ent_cancel_type']."]";
//                $subject = " I cancelled my trip  [" . $args['ent_booking_id'] . " - " . $cityId['City_Name'] . "]";
//                $recipients = array(($this->User['entityId']) . '@pqup.co' => $this->User['firstName']);
//                $to = "cancellations@pqup.co";
//                $body = $args['ent_reason'];
//                break;
//            case 4: // driver block when driver go to history  
//                $subject = "[" . $this->User['firstName'] . ' ' . $this->User['last_name'] . " - " . $this->User['entityId'] . "] claims for [" . $args['ent_booking_id'] . " - " . $cityId['City_Name'] . "]";
//                $recipients = array(($this->User['entityId']) . '@pqup.co' => $this->User['firstName'] . ' ' . $this->User['last_name']);
//                $to = "driverclaims@pqup.co";
//                $body = $args['ent_reason'];
//                break;
//            case 5: // driver block in support tab 
//                $subject = "[" . $this->User['firstName'] . ' ' . $this->User['last_name'] . " - " . $this->User['entityId'] . "] from [" . $cityId['City_Name'] . "] has sent the below query";
//                $recipients = array(($this->User['entityId']) . '@pqup.co' => $this->User['firstName'] . ' ' . $this->User['last_name']);
//                $to = "driversupport@pqup.co";
//                $body = $args['ent_reason'];
//                break;
//            case 6: // driver block while rating to customer   $args['ent_rating_num'], "CusomerReviewMessage" => $args['ent_reason']
//                $subject = "I rated my guest [" . $args['ent_rating_num'] . "],[" . $apptDet['slave_id']['SlaveName'] . " – " . $apptDet['slave_id']['slaveId'] . "] for [" . $apptDet['_id'] . " - " . $cityId['City_Name'] . "]";
//                $recipients = array(($this->User['entityId']) . '@pqup.co' => $this->User['firstName'] . ' ' . $this->User['last_name']);
//                $to = "driverfeedback@pqup.co";
//                $body = $args['ent_reason'];
//                break;
//        }
//        $mail = new sendAMail(APP_SERVER_HOST);
//        if ($action == 1 || $action == 2 || $action == 3)
//            $data = $mail->mailFun(array($to => 'Pq-passanger'), $subject, "<p>" . $body . "</p>", $this->User['email']);
//        else
//            $data = $mail->mailFun(array($to => 'Pq-driver'), $subject, "<p>" . $body . "</p>", $this->User['entityId'] . '@pqup.co');
//        return $data;
//    }

    protected function DriverPresnalChatZendesk($args) {
        if ($args['ent_reason'] == '') {
            return $this->_getStatusMessage(1, 'body');
        }

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;


        $CityQuery = "select ca.City_Name from city_available ca,company_info ci where ca.City_Id = ci.city and ci.company_id ='" . $this->User['company_id'] . "'";
        $cityId = mysql_fetch_assoc(mysql_query($CityQuery, $this->db->conn));

//        $res = $this->sendComplainMail($args, $cityId['City_Name'], 5);
        $err = $this->_getStatusMessage(39, 2);
        return array('errNum' => $err['errNum'], 'errFlag' => $err['errFlag'], 'errMsg' => "Request Submited !", 'test' => $res);
    }

    /*
     * Method name: abortJourney
     * Desc: Driver can Cancel an appointment in any time
     * Input: Request data
     * Output:  success if got it else error according to the result
     */

    protected function abortJourney($args) {

        if ($args['ent_booking_id'] == '')
            return $this->_getStatusMessage(1, 'Booking id');
        else if ($args['ent_sid'] == '')
            return $this->_getStatusMessage(1, 'Passenger sid');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_cancel_type'] == '')
            return $this->_getStatusMessage(1, 'Cancel type');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $args['ent_appnt_dt'] = urldecode($args['ent_appnt_dt']);

        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));

        $driverCabAbour = $this->__getConfig();
        if (((time() - $apptDet['DriverArrivedTimeStampServer']) < (((int) $driverCabAbour['cancelTimeDriver']) * 60))) {
            return array('errNum' => 135, 'errFlag' => 1, 'errMsg' => "You Can Cancel The Booking after " . (((int) $driverCabAbour['cancelTimeDriver'])) . " minutes");
        }

        if ($apptDet['flag'] == 1)
            return $this->_getStatusMessage(32, $apptDet);

        if ($apptDet['status'] == '3')
            return $this->_getStatusMessage(44, 44);

        if ($apptDet['status'] == '4')
            return $this->_getStatusMessage(41, 3);

        if ($apptDet['status'] == '9')
            return $this->_getStatusMessage(75, 75);

        if ($apptDet['status'] == 7 && ((time() - $apptDet['DriverArrivedTimeStampServer']) >= $this->DriverCancelTime)) {
            $finalAmount = $apptDet['vehicleType']['baseFare'];
            $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,txn_id) values ('" . $apptDet['slave_id']['slaveId'] . "',2,'" . round(-$finalAmount, 2) . "',now(),'" . ($finalAmount > 0 ? 1 : 2) . "','" . $apptDet['_id'] . "')";
            mysql_query($query, $this->db->conn);
            if (mysql_affected_rows() < 0)
                return $this->_getStatusMessage(3, $query);

            $DriverResp = $this->__insertDriverWallet(array('mas_id' => $this->User['entityId'], 'amount' => $finalAmount));
            if ($DriverResp['flag'] == 1)
                return $this->_getStatusMessage(3, $DriverResp['query']);
        }

        $pasData = $this->_getEntityDet($args['ent_sid'], '2', '1');


        $updateAppointment = $this->MongoClass->update('appointments', array("status" => 5, "CancelationType" => $args['ent_cancel_type']), array("_id" => (int) $args['ent_booking_id']));

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);


        $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
        $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
        $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;

        $aplPushContent = array('alert' => $this->__getAppointmnetStatus(5), 'nt' => '10', 't' => $apptDet['appt_type'], 'sound' => 'default', 'id' => $apptDet['_id'], 'r' => (int) $args['ent_cancel_type']); //, 'd' => $apptDet['appointment_dt'], 'e' => $this->User['email']
        $andrPushContent = array('payload' => $this->__getAppointmnetStatus(5), 'action' => '10', 't' => $apptDet['appt_type'], 'sname' => $this->User['firstName'], 'dt' => $apptDet['appointment_dt'], 'e' => $this->User['email'], 'bid' => $apptDet['_id'], 'r' => (int) $args['ent_cancel_type']);
        $pushNum['push'] = $this->_sendPush($this->User['entityId'], array($apptDet['slave_id']), $message, '10', $this->User['firstName'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent);


        $pubnubContent = array('a' => 14, 'bid' => $apptDet['_id'], 'm' => $this->__getAppointmnetStatus(5), 's' => 9);

        $out = array('push1' => $push, 'push' => $aplPushContent);
        $out['pubnub'] = $this->pubnub->publish(array(
            'channel' => 'dispatcher',
            'message' => $pubnubContent
        ));

        list($date, $time) = explode(' ', $this->curr_date_time);
        list($year, $month, $day) = explode('-', $date);
        list($hour, $minute, $second) = explode(':', $time);

        $EndTime = mktime($hour, $minute, $second, $month, $day, $year);
        $statusLog = $this->mongo->selectCollection('statusLog');
        $statusLog->update(array('master' => (int) $this->User['entityId'], 'status' => 5, 'bid' => (int) $args['ent_booking_id']), array('$set' => array('status' => 6, 'EndTime' => $EndTime, 'dist' => ((double) $args['ent_dist'] > 0 ? (double) $args['ent_dist'] : 0))));

        $location = $this->mongo->selectCollection('location');
        $location->update(array('user' => (int) $this->User['entityId']), array('$set' => array('status' => 3)));

        return $this->_getStatusMessage(42, $cancelApntQry . $pushNum);
    }

    /*
     * Method name: cancelAppointmentRequest
     * Desc: Passenger can Cancel an appointment requested
     * Input: Request data
     * Output:  success if cancelled else error according to the result
     */

    protected function cancelAppointmentRequest($args) {

        if ($args['ent_booking_id'] == '3')
            return $this->_getStatusMessage(44, 44);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $apptDet = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_booking_id']));

        $updateAppointment = $this->MongoClass->update('appointments', array("status" => 4), array("_id" => (int) $args['ent_booking_id']));

        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);
        else
            return $this->_getStatusMessage(74, 74);
    }

    /*
     * Method name: reportDispute
     * Desc: Get workplace types data
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function reportDispute($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_report_msg'] == '')
            return $this->_getStatusMessage(1, 'Dispute message');

        //$this->curr_date_time = urldecode($args['ent_date_time']);
        $args['ent_appnt_dt'] = urldecode($args['ent_appnt_dt']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $getApptDetQry = "select a.status,a.appt_lat,a.appt_long,a.address_line1,a.address_line2,a.created_dt,a.arrive_dt,a.appointment_dt,a.amount,a.appointment_id,a.last_modified_dt,a.mas_id from appointment a where a.appointment_dt = '" . $args['ent_appnt_dt'] . "' and a.slave_id = '" . $this->User['entityId'] . "'";
        $apptDet = mysql_fetch_assoc(mysql_query($getApptDetQry, $this->db->conn));

        if ($apptDet['status'] == '4')
            return $this->_getStatusMessage(41, 3);

        $insertIntoReportQry = "insert into reports(mas_id,slave_id,appointment_id,report_msg,report_dt) values('" . $apptDet['mas_id'] . "','" . $this->User['entityId'] . "','" . $apptDet['appointment_id'] . "','" . $args['ent_report_msg'] . "','" . $this->curr_date_time . "')";
        mysql_query($insertIntoReportQry, $this->db->conn);

        if (mysql_insert_id() > 0) {
            $updateQryReq = "update appointment set payment_status = '2' where appointment_id = '" . $apptDet['appointment_id'] . "'";
            mysql_query($updateQryReq, $this->db->conn);

            $message = "Dispute reported for appointment dated " . date('d-m-Y h:i a', strtotime($apptDet['appointment_dt'])) . " on " . APP_NAME . "!";

            $aplPushContent = array('alert' => $message, 'nt' => '13', 'n' => $this->User['firstName'] . ' ' . $this->User['last_name'], 'd' => $args['ent_appnt_dt'], 'e' => $this->User['email'], 'bid' => $apptDet['appointment_id']);
            $andrPushContent = array("payload" => $message, 'action' => '13', 'sname' => $this->User['firstName'] . ' ' . $this->User['last_name'], 'dt' => $args['ent_appnt_dt'], 'smail' => $this->User['email'], 'bid' => $apptDet['appointment_id']);

            $this->ios_cert_path = $this->ios_uberx_driver;
            $this->ios_cert_pwd = $this->ios_mas_pwd;
            $this->androidApiKey = ANDROID_DRIVER_PUSH_KEY;
            $push = $this->_sendPush($this->User['entityId'], array($apptDet['mas_id']), $message, '13', $this->User['email'], $this->curr_date_time, '1', $aplPushContent, $andrPushContent);

            $errMsgArr = $this->_getStatusMessage(85, $push);
        } else {
            $errMsgArr = $this->_getStatusMessage(86, 76);
        }

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 't' => $insertIntoReportQry);
    }

    /*
     * Method name: getProfile
     * Desc: Get slave profile data
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function getProfile($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $selectProfileQry = "select * from slave where slave_id = '" . $this->User['entityId'] . "'";
        $profileData = mysql_fetch_assoc(mysql_query($selectProfileQry, $this->db->conn));

        if (!is_array($profileData))
            $errMsgArr = $this->_getStatusMessage(20, 20);

        $errMsgArr = $this->_getStatusMessage(33, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'fName' => $profileData['first_name'], 'lName' => $profileData['last_name'], 'email' => $profileData['email'], 'phone' => $profileData['phone'], 'pPic' => ($profileData['profile_pic'] == '' ? $this->default_profile_pic : $profileData['profile_pic']), 'gender' => $profileData['gender'], 'dob' => $profileData['dob']);
    }

    /*
     * Method name: getWorkplaces
     * Desc: Get workplace types data
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function getWorkplaces($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $errMsgArr = $this->_getStatusMessage(33, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'types' => $this->getWorkplaceTypes());
    }

    /*
     * Method name: updateProfile
     * Desc: Update slave profile data
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function updateProfile($args) {

        if (($args['ent_first_name'] == '' && $args['ent_email'] == '' && $args['ent_last_name'] == '' && $args['ent_phone'] == '') || $args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Update');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        if ($args['ent_first_name'] != '')
            $update_name = " first_name = '" . $args['ent_first_name'] . "',";

        if ($args['ent_phone'] != '')
            $update_phone = " phone = '" . $args['ent_phone'] . "',";

        if ($args['ent_last_name'] != '')
            $update_lname = " last_name = '" . $args['ent_last_name'] . "',";

        if ($args['ent_dob'] != '')
            $dob = " dob = '" . $args['ent_dob'] . "',";

        if ($args['ent_email'] != '') {

            $checkEmailQry = "select slave_id from user where email = '" . $args['ent_email'] . "' and slave_id != '" . $this->User['entityId'] . "'";
            $checkEmailRes = mysql_query($checkEmailQry, $this->db->conn);

            if (mysql_num_rows($checkEmailRes) > 0)
                return $this->_getStatusMessage(2, 10);

            $update_email = " email = '" . $args['ent_email'] . "',";
        }

        $update_str = rtrim($update_name . $update_email . $update_phone . $update_lname . $dob, ',');

        $updateQry = "update slave set " . $update_str . ",last_active_dt = '" . $this->curr_date_time . "' where slave_id = '" . $this->User['entityId'] . "'";
        $updateRes = mysql_query($updateQry, $this->db->conn);

        if (mysql_affected_rows() > 0)
            return $this->_getStatusMessage(54, 39);
        else if ($updateRes)
            return $this->_getStatusMessage(54, 40);
        else
            return $this->_getStatusMessage(3, $updateQry);
    }

    /*
     * Method name: getMasterCarDetails
     * Desc: Get master car details that are active currently
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function getMasterCarDetails($args) {

        if ($args['ent_email'] == '')
            return $this->_getStatusMessage(1, 'Email');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $masDet = $this->_getEntityDet($args['ent_email'], '1');

        if (!is_array($masDet))
            return $this->_getStatusMessage(37, 37);

        if ($masDet['workplace_id'] == 0)
            return $this->_getStatusMessage(37, 37);

        $getVehicleDataQry = "select wrk.workplace_id,wrk.License_Plate_No,(select v.vehiclemodel from vehiclemodel v,workplace w where w.Vehicle_Model = v.id  and w.workplace_id = wrk.workplace_id) as vehicle_model from workplace wrk,master m where m.workplace_id = wrk.workplace_id and m.mas_id = '" . $masDet['mas_id'] . "'";

        $getVehicleDataRes = mysql_query($getVehicleDataQry, $this->db->conn);

        $vehicleData = mysql_fetch_assoc($getVehicleDataRes);

        $errMsgArr = $this->_getStatusMessage(21, 50);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'model' => $vehicleData['vehicle_model'], 'plateNo' => $vehicleData['License_Plate_No']);
    }

    /*
     * Method name: addCard
     * Desc: Add a card to the passenger profile
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function addCard($args) {

        if ($args['ent_token'] == '')
            return $this->_getStatusMessage(1, 'Card token');
        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        if ($this->User['stripe_id'] == '') {

            $createCustomerArr = array('token' => $args['ent_token'], 'email' => $this->User['email']);

            $customer = $this->stripe->apiStripe('createCustomer', $createCustomerArr);

            if ($customer['error'])
                return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => $customer['error']['message'], 'test' => 1);

            $updateQry = "update slave set stripe_id = '" . $customer['id'] . "',last_active_dt = '" . $this->curr_date_time . "' where slave_id = '" . $this->User['entityId'] . "'";
            mysql_query($updateQry, $this->db->conn);
            if (mysql_affected_rows() <= 0)
                return $this->_getStatusMessage(51, 50);

            $getCardArr = array('stripe_id' => $customer['id']);

            $card = $this->stripe->apiStripe('getCustomer', $getCardArr);

            if ($card['error'])
                return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => $card['error']['message'], 'test' => 2);

            foreach ($card['sources']['data'] as $c) {
                $cardRes = array('id' => $c['id'], 'last4' => $c['last4'], 'type' => $c['brand'], 'exp_month' => $c['exp_month'], 'exp_year' => $c['exp_year']);
            }

            $errMsgArr = $this->_getStatusMessage(50, 50);
            return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'cards' => array($cardRes), 'def' => $card['default_source']); //, 'cards' => array('id' => $customer['data']['id'], 'last4' => $customer['data']['last4'], 'type' => $customer['data']['type'], 'exp_month' => $customer['data']['exp_month'], 'exp_year' => $customer['data']['exp_year']));
        }

        $addCardArr = array('stripe_id' => $this->User['stripe_id'], 'token' => $args['ent_token']);

        $card = $this->stripe->apiStripe('addCard', $addCardArr);

        if ($card['error'])
            return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => $card['error']['message'], 'test' => 2);

        $getCard = $this->stripe->apiStripe('getCustomer', $addCardArr);

        foreach ($getCard['sources']['data'] as $card) {
            $cardsArr[] = array('id' => $card['id'], 'last4' => $card['last4'], 'type' => $card['brand'], 'exp_month' => $card['exp_month'], 'exp_year' => $card['exp_year']);
        }

        $errMsgArr = $this->_getStatusMessage(50, 50);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'cards' => $cardsArr, 'def' => $getCard['default_source']);
    }

    protected function getCards($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $balnace = $this->GetWalletMoney(array('ent_sid' => $this->User['entityId']));

        if ($this->User['stripe_id'] == '')
            return array('errNum' => 51, 'errFlag' => 1, 'errMsg' => 'card not found', 'walletBal' => $balnace['amount'], 'test' => 2);
        // return $this->_getStatusMessage(51, 51);

        $getCardArr = array('stripe_id' => $this->User['stripe_id']);

        $cardsArr = array();

        $card = $this->stripe->apiStripe('getCustomer', $getCardArr);

        if ($card['error'])
            return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => $card['error']['message'], 'test' => 2);

        foreach ($card['sources']['data'] as $c) {
            $cardsArr[] = array('id' => $c['id'], 'last4' => $c['last4'], 'type' => $c['brand'], 'exp_month' => $c['exp_month'], 'exp_year' => $c['exp_year']);
        }

        if (count($cardsArr) > 0)
            $errNum = 52;
        else
            $errNum = 51;

        $errMsgArr = $this->_getStatusMessage($errNum, 52);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'cards' => $cardsArr, 'def' => $card['default_source'], 'paypal' => ($this->User['paypal'] == '' ? 1 : 2), 'walletBal' => $balnace['amount']);
    }

    /*
     * Method name: removeCard
     * Desc: Add a card to the passenger profile
     * Input: Request data
     * Output:  success array if got it else error according to the result
     */

    protected function removeCard($args) {

//          parse_str('ent_sess_token=46443941363643DahNcReaIvVIDKnfwqll352D364646312D344439412D423430462D383142344346424631433730DahNcReaIvVIDKnfwqll&ent_dev_id=FD9A66C5-6FF1-4D9A-B40F-81B4CFBF1C70&ent_cc_id=card_19U9H6LiLh81MCkztSbAoWXo&ent_date_time=2016-12-24 12:16:08',$args);
        if ($args['ent_cc_id'] == '')
            return $this->_getStatusMessage(1, 'Card id');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        if ($this->User['stripe_id'] == '')
            return $this->_getStatusMessage(51, 51);

        $remCardArr = array('stripe_id' => $this->User['stripe_id'], 'card_id' => $args['ent_cc_id']);

        $cardsArr = array();

        $card = $this->stripe->apiStripe('deleteCard', $remCardArr);

        if ($card->error)
            return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => $card->error->message);

        foreach ($card->data as $card) {
            $cardsArr = array('id' => $card->data->id, 'last4' => $card->data->last4, 'type' => $card->data->brand, 'exp_month' => $card->data->exp_month, 'exp_year' => $card->data->exp_year);
        }

        $errMsgArr = $this->_getStatusMessage(52, 52);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'cards' => $cardsArr);
    }

    protected function makeCardDefault($args) {
        //$notifications = $this->mongo->selectCollection('cohekmakedefault');
        //    $args = $notifications->findOne(array('_id' => new MongoId('589c700c9f90850f3a44486b')));
        //$notifications->insert($args);

        if ($args['ent_cc_id'] == '')
            return $this->_getStatusMessage(1, 'Card id');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        $this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        if ($this->User['stripe_id'] == '')
            return $this->_getStatusMessage(51, 51);

        $remCardArr = array('stripe_id' => $this->User['stripe_id'], 'card_id' => $args['ent_cc_id']);

        $cardsArr = array();

        $card = $this->stripe->apiStripe('updateCustomerDefCard', $remCardArr);

        if ($card->error) {
            return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => $card->error->message);
        }

        //return array('test'=> $card);
        foreach ($card->sources->data as $c) {
            $cardsArr[] = array('id' => $c->id, 'last4' => $c->last4, 'type' => $c->brand, 'exp_month' => $c->exp_month, 'exp_year' => $c->exp_year);
        }

        $errMsgArr = $this->_getStatusMessage(52, 52);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'cards' => $cardsArr, 'def' => $card->default_source);
    }

    /*
     * Method name: validateEmailZip
     * Desc: Validates the email and zipcode
     * Input: Token
     * Output:  gives error array if unavailable
     */

    protected function validateEmailZip($args) {

        if ($args['ent_email'] == '')
            return $this->_getStatusMessage(1, 'Email');
        else if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'User type');



        if ($args['ent_user_type'] == '1')
            $verifyEmail = $this->_verifyEmail($args['ent_email'], 'mas_id', 'master'); //_verifyEmail($email,$field,$table);
        else
            $verifyEmail = $this->_verifyEmail($args['ent_email'], 'slave_id', 'slave'); //_verifyEmail($email,$field,$table);

        if (is_array($verifyEmail))
            $email = array('errFlag' => 1);
        else
            $email = array('errFlag' => 0);


//                $vmail = new verifyEmail();
//
//                if ($vmail->check($args['ent_email'])) {
//                    $email = $this->_getStatusMessage(34, $args['ent_email']);
//                } else if ($vmail->isValid($args['ent_email'])) {
//                    $email = $this->_getStatusMessage(24, $args['ent_email']); //_getStatusMessage($errNo, $test_num);
//                    //echo 'email valid, but not exist!';
//                } else {
//                    $email = $this->_getStatusMessage(25, $args['ent_email']); //_getStatusMessage($errNo, $test_num);
//                    //echo 'email not valid and not exist!';
//                }
//        $selectZipQry = "select zipcode from zipcodes where zipcode = '" . $args['zip_code'] . "'";
//        $selectZipRes = mysql_query($selectZipQry, $this->db->conn);
//        if (mysql_num_rows($selectZipRes) > 0)
        $zip = array('errFlag' => 0);
//        else
//            $zip = array('errFlag' => 1);


        if ($email['errFlag'] == 0 && $zip['errFlag'] == 0)
            return $this->_getStatusMessage(47, $verifyEmail);
        else if ($email['errFlag'] == 1 && $zip['errFlag'] == 1)
            return $this->_getStatusMessage(46, $verifyEmail);
        else if ($email['errFlag'] == 0 && $zip['errFlag'] == 1)
            return $this->_getStatusMessage(46, $verifyEmail);
        else if ($email['errFlag'] == 1 && $zip['errFlag'] == 0)
            return $this->_getStatusMessage(2, $verifyEmail);
    }

    /*
     * add favourateAdresss address 
     * 
     */

//    protected function favourateAdresss($args) {
//        if ($args['ent_sid'] == '')
//            return $this->_getStatusMessage(1, 'sid');
//        else if ($args['ent_action'] == '')
//            return $this->_getStatusMessage(1, 'action id');
//        else if ($args['ent_action'] == '1' && $args['ent_address'] == '') {
//            return $this->_getStatusMessage(1, 'address');
//        }
//
//        if ($args['ent_action'] == 1) {
//            $apptDet = $this->MongoClass->get_one('SlaveFavoriteAddress', array("slaveId" => (int) $args['ent_sid']));
//            if ($apptDet['flag'] == 1) {
//                $response = $this->MongoClass->insert('SlaveFavoriteAddress', array('Addresses' => array($args['ent_address']), 'slaveId' => (int) $args['ent_sid']));
//                if ($response['flag'] == '1') {
//                    return $this->_getStatusMessage(3, $MongoAppointmnet);
//                }
//            } else {
//                $updateAppointment = $this->MongoClass->updatewithpush('SlaveFavoriteAddress', array("aid" => (string) new MongoId(), "Addresses" => $args['ent_address']), array("slaveId" => (int) $args['ent_sid']));
//                if ($updateAppointment['flag'] == 1)
//                    return $this->_getStatusMessage(3, $updateResponseQry);
//            }
//        } else if ($args['ent_action'] == 2) {
//            $deletedata = $this->MongoClass->updatewithpull('SlaveFavoriteAddress', array("aid" => (string) new MongoId(), "Addresses" => $args['ent_address']), array("slaveId" => (int) $args['ent_sid']));
//            if ($deletedata['flag'] == 1)
//                return $this->_getStatusMessage(3, $deletedata);
//            $apptDet = $this->MongoClass->get_one('SlaveFavoriteAddress', array("slaveId" => (int) $args['ent_sid']));
//        }
//
//        $errMsgArr = $this->_getStatusMessage(21, 2);
//        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'],
//            'paymentLoc' => $this->makeZeroIfNull($PaymentLocs),
//            'Trips' => $this->makeZeroIfNull($tripdata)
//        );
//    }

    /*
     * Method name: validateEmail
     * Desc: Validates the email
     * Input: Token
     * Output:  gives error array if unavailable
     */

    protected function validateEmail($args) {

        if ($args['ent_email'] == '')
            return $this->_getStatusMessage(1, 'Email');

        $vmail = new verifyEmail();

        if ($vmail->check($args['ent_email'])) {
            return $this->_getStatusMessage(34, $args['ent_email']);
        } else if ($vmail->isValid($args['ent_email'])) {
            return $this->_getStatusMessage(24, $args['ent_email']); //_getStatusMessage($errNo, $test_num);
//echo 'email valid, but not exist!';
        } else {
            return $this->_getStatusMessage(25, $args['ent_email']); //_getStatusMessage($errNo, $test_num);
//echo 'email not valid and not exist!';
        }
    }

    /*
     * Method name: resetPassword
     * Desc: User can reset the password from with in the app
     * Input: Token
     * Output:  gives error array if failed
     */

    protected function resetPassword($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $deleteAllSessionsQry = "update user_sessions set loggedIn = 2 where oid = '" . $this->User['entityId'] . "' and user_type = '1'";
        mysql_query($deleteAllSessionsQry, $this->db->conn);

        if (mysql_affected_rows() <= 0)
            return $this->_getStatusMessage(6, $deleteAllSessionsQry);

        $randData = $this->_generateRandomString(20) . '_1';

        $mail = new sendAMail(APP_SERVER_HOST);
        $resetRes = $mail->forgotPassword($this->User, $randData);

        if ($resetRes['flag'] == 0) {
            $updateResetDataQry = "update master set resetData = '" . $randData . "', resetFlag = 1 where email = '" . $this->User['email'] . "'";
            mysql_query($updateResetDataQry, $this->db->conn);
//            $resetRes['update'] = $updateResetDataQry;
            return $this->_getStatusMessage(67, $resetRes);
        } else {
            return $this->_getStatusMessage(68, $resetRes);
        }
    }

    /*
     * Method name: updateMasterStatus
     * Desc: Update master status
     * Input: Token
     * Output:  gives error array if failed
     */

    protected function updateMasterStatus($args) {
        $arr = array('3', '4');

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_status'] == '')
            return $this->_getStatusMessage(1, 'Status');
        else if (!in_array($args['ent_status'], $arr))
            return $this->_getStatusMessage(1, 'Status');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $location = $this->mongo->selectCollection('location');
        $statusLog = $this->mongo->selectCollection('statusLog');

        list($date, $time) = explode(' ', $this->curr_date_time);
        list($year, $month, $day) = explode('-', $date);
        list($hour, $minute, $second) = explode(':', $time);

        $timestamp = time(); //mktime($hour, $minute, $second, $month, $day, $year);


        $update['location'] = $location->update(array('user' => (int) $this->User['entityId']), array('$set' => array('status' => (int) $args['ent_status'],'loginTime' =>time())));
        $lastLoggedInStatus = array();
        $lastLoggedIn = $statusLog->find(array('master' => (int) $this->User['entityId'], 'status' => 3, 'time' => array('$lte' => $timestamp)))->sort(array('time' => -1))->limit(1);
        foreach ($lastLoggedIn as $key) {
            $lastLoggedInStatus[] = $key;
        }

        if ($lastLoggedInStatus[0]['status'] == 3) {
            $update['status_log'] = $statusLog->update(array('master' => (int) $this->User['entityId'], 'status' => 3), array('$set' => array('status' => (int) $args['ent_status'], 'EndTime' => $timestamp, 'EndTimeGurentee' => $timestamp, 'dist' => ((double) $args['ent_overall_dist'] > 0 ? (double) $args['ent_overall_dist'] : 0))));
        } else
            $update['status_log'] = $statusLog->insert(array('master' => (int) $this->User['entityId'], 'status' => (int) $args['ent_status'], 'time' => $timestamp, 'startTime' => $timestamp, "EndTime" => 0, 'EndTimeGurentee' => $timestamp, "timeDiff" => ($timestamp - time())));

        return $this->_getStatusMessage(69, $update);
    }

    /*
     * Method name: forgotPassword
     * Desc: send mail for forgot password
     * Input: Token
     * Output:  gives error array if failed
     */

    protected function forgotPassword($args) {

        if ($args['ent_email'] == '')
            return $this->_getStatusMessage(1, 'Email');
        else if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'User type');

        if ($args['ent_user_type'] == '1') {
            $table = 'master';
            $uid = 'mas_id';
        } else if ($args['ent_user_type'] == '2') {
            $table = 'slave';
            $uid = 'slave_id';
        } else {
            return $this->_getStatusMessage(1, 'User type');
        }

        $selectUserQry = "select status,email,password,$uid from $table where email = '" . $args['ent_email'] . "'";
        $selectUserRes = mysql_query($selectUserQry, $this->db->conn);

        if (mysql_num_rows($selectUserRes) <= 0)
            return $this->_getStatusMessage(66, $selectUserQry);

        $userData = mysql_fetch_assoc($selectUserRes);

        if ($userData['status'] == '1' || $userData['status'] == '2')
            return $this->_getStatusMessage(10, $selectUserQry);

        if ($userData['status'] == '4')
            return $this->_getStatusMessage(94, $selectUserQry);

        $randData = $this->_generateRandomString(20) . '_' . $args['ent_user_type'];

        $mail = new sendAMail(APP_SERVER_HOST);
        $resetRes = $mail->forgotPassword($userData, $randData);

        if ($resetRes['flag'] == 0) {
            $updateResetDataQry = "update $table set resetData = '" . $randData . "', resetFlag = 1 where email = '" . $args['ent_email'] . "'";
            mysql_query($updateResetDataQry, $this->db->conn);
//$resetRes['update'] = $updateResetDataQry;
            return $this->_getStatusMessage(67, $resetRes);
        } else {
            return $this->_getStatusMessage(68, $resetRes);
        }
    }

    /*
     * 
     * forgot password with otp
     */

    protected function ForgotPasswordWithOtp($args) {
        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_mobile'] == '') {
            return $this->_getStatusMessage(1, 'mobile');
        }

        if ($args['ent_user_type'] == 2)
            $query = "select * from slave where  phone = '" . $args['ent_mobile'] . "' ";
        else if ($args['ent_user_type'] == 1) {
            $query = "select * from master where mobile = '" . $args['ent_mobile'] . "' ";
        }
        $searchRes = mysql_query($query, $this->db->conn);

        if (mysql_num_rows($searchRes) <= 0) {
            return $this->_getStatusMessage(133, $query);
        }

        if ($searchRes['status'] == '4')
            return $this->_getStatusMessage(79, 79);

        $rand = $args['ent_rand'] = rand(10000, 99999);
        $args['ent_mobile'] = $args['ent_mobile'];

        $resutl = $this->mobileVerification($args, 2, APP_NAME . ", Reset password code is : " . $args['ent_rand']);

        $verification = $this->mongo->selectCollection('verification');
        if (is_array($verification->findOne(array('mobile' => $args['ent_mobile']))))
            $verification->update(array('mobile' => $args['ent_mobile']), array('$set' => array('code' => (int) $rand, 'ts' => time())));
        else
            $verification->insert(array('mobile' => $args['ent_mobile'], 'code' => (int) $rand, 'ts' => time()));

        return $this->_getStatusMessage(107, 1);
    }

    /*
     * update password 
     * 
     */

    protected function updatePasswordForUser($args) {
        if ($args['ent_mobile'] == '') {
            return $this->_getStatusMessage(1, 'mobile');
        } else if ($args['ent_pass'] == '') {
            return $this->_getStatusMessage(1, 'password ');
        }

        if ($args['ent_user_type'] == 2) {
            $query = "select * from slave where   phone = '" . $args['ent_mobile'] . "' ";
            $Updatequery = "update slave set  password = md5('" . $args['ent_pass'] . "') where phone = '" . $args['ent_mobile'] . "' ";
        } else if ($args['ent_user_type'] == 1) {
            $query = "select * from master where  mobile = '" . $args['ent_mobile'] . "' ";
            $Updatequery = "update master set  password = md5('" . $args['ent_pass'] . "') where mobile = '" . $args['ent_mobile'] . "' ";
        }
        $searchRes = mysql_query($query, $this->db->conn);

        if (mysql_num_rows($searchRes) <= 0)
            return $this->_getStatusMessage(8);

        mysql_query($Updatequery, $this->db->conn);

        return $this->_getStatusMessage(23);
    }

    /*
     * Method name: checkSession
     * Desc: Check session of any users
     * Input: Request data
     * Output:  Complete profile details if available, else error message
     */

    protected function checkSession($args) {

        if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'User type');
        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_user_type']);

        if (is_array($returned))
            return $returned;
        else
            return $this->_getStatusMessage(73, 15);
    }

    /*
     * Method name: checkCoupon
     * Desc: Check coupon exists or not, if exists check the expirty
     * Input: Request data
     * Output:  Success if available else error
     */

    protected function checkCoupon($args) {

        if ($args['ent_coupon'] == '')
            return $this->_getStatusMessage(1, 'Coupon');
        if ($args['ent_lat'] == '' || $args['ent_long'] == '')
            return $this->_getStatusMessage(1, 'Location');

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;


        $Refferal = new campaign();
        $promodata = array(
            'ent_latitude' => $args['ent_lat'],
            'ent_longitude' => $args['ent_long'],
            'userId' => $this->User['entityId'],
            'ent_coupon' => $args['ent_coupon'],
            'ent_from_long' => $args['ent_long'],
            'ent_from_lat' => $args['ent_lat']
        );

        $this->mongo->selectCollection('testingData')->insert($promodata);
        $response = $Refferal->checkCoupons($promodata);
        if ($response['flag'] == 1) {
            $errMsgArr = $this->_getStatusMessage(116, 52);
            return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $response['msg']);
        } else {
            return $this->_getStatusMessage(119, 52);
        }
    }

    /*
     * Method name: verifyCode
     * Desc: Check coupon exists or not, if exists check the expirty
     * Input: Request data
     * Output:  Success if available else error
     */

    protected function verifyCode($args) {

        if ($args['ent_coupon'] == '')
            return $this->_getStatusMessage(1, 'Coupon');
        else if ($args['ent_lat'] == '' || $args['ent_long'] == '')
            return $this->_getStatusMessage(1, 'Location');


        $Refferal = new campaign();
        $resultArr = $Refferal->checkReferral(array('ent_referral_code' => $args['ent_coupon']));

        if ($resultArr['flag'] == 0) {
            return $this->_getStatusMessage(101, 1);
        } else {
            return $this->_getStatusMessage(100, $resultArr);
        }
    }

    /*
     * Method name: updateMasterRating
     * Desc: Update master rating for slave
     * Input: Rating
     * Output:  gives error array if failed
     */

    protected function updateMasterRating($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_rating'] == '')
            return $this->_getStatusMessage(1, 'Rating');
        else if ($args['ent_appnt_dt'] == '')
            return $this->_getStatusMessage(1, 'Booking date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $slvDet = $this->_getEntityDet($args['ent_slv_email'], '2');

        $selectApptQry = "select appointment_id from appointment where slave_id = '" . $slvDet['slave_id'] . "' and mas_id = '" . $this->User['entityId'] . "' and appointment_dt = '" . $args['ent_appnt_dt'] . "'";
        $selectApptRes = mysql_query($selectApptQry, $this->db->conn);

        if (mysql_num_rows($selectApptRes) <= 0)
            return $this->_getStatusMessage(62, 62);

        $appt = mysql_fetch_assoc($selectApptRes);

        $updateReviewQry = "insert into passenger_rating(mas_id,slave_id,rating,status,rating_dt,appointment_id) values ('" . $this->User['entityId'] . "','" . $slvDet['slave_id'] . "','" . $args['ent_rating'] . "','1','" . $this->curr_date_time . "','" . $appt['appointment_id'] . "')";
        mysql_query($updateReviewQry, $this->db->conn);

        if (mysql_affected_rows() < 0)
            return $this->_getStatusMessage(70, $updateReviewQry);

        return $this->_getStatusMessage(69, $updateReviewQry);
    }

    /*
     * Method name: updateMasterRating
     * Desc: Update master rating for slave
     * Input: Rating
     * Output:  gives error array if failed
     */

    protected function getMasterStatus($args) {
        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $location = $this->mongo->selectCollection('location');

        $findOne = $location->findOne(array('user' => (int) $this->User['entityId']));

        $errMsgArr = $this->_getStatusMessage(114, 52);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'status' => $findOne['status']);
    }

    function addTofavourite($args) {

        if ($args['ent_dri_email'] == '')
            return $this->_getStatusMessage(1, 'Driver email');


        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        $query = "SELECT mas_id from master where email = '" . $args['ent_dri_email'] . "'";

        $res = mysql_query($query, $this->db->conn);

        if (mysql_num_rows($res) <= 0)
            return $this->_getStatusMessage(128, 'dir');

        $masDet = mysql_fetch_assoc($res);

        $favourite = $this->mongo->selectCollection('location');

//        $insertData = array('passenger' => (int) $this->User['entityId'], 'driver' => (int) $masDet['mas_id'], 'pasEmail' => $this->User['email']);
        $insertData = array('user' => (int) $masDet['mas_id'], 'followers' => (int) $this->User['entityId']);
        if (!is_array($favourite->findOne($insertData)))
            $favourite->update(array('user' => (int) $masDet['mas_id']), array('$push' => array('followers' => (int) $this->User['entityId'])));
        else
            return $this->_getStatusMessage(138, 'not added');


        return $this->_getStatusMessage(139, 'added');
    }

    /*
     * Method name: getFavourites
     * Desc: Get all favourite drivers
     * Input: Request data
     * Output:  Complete details if available, else error message
     */

    protected function getFavourites($args) {

        if ($args['ent_latitude'] == '' || $args['ent_longitude'] == '')
            return $this->_getStatusMessage(1, 'Location');

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;


        $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
            'geoNear' => 'location',
            'near' => array(
                (double) $args['ent_longitude'], (double) $args['ent_latitude']
            ), 'spherical' => true, 'maxDistance' => 1, 'distanceMultiplier' => 6378137,
                )//'query' => array('followers' => (int) $this->User['entityId'])
        );

        $md_arr = $md_arr_offline = array();
//
        $vechicledesc = $this->mongo->selectCollection('vehicleTypes');
        foreach ($resultArr['results'] as $res) {
            $doc = $res['obj'];
            $fav = 0;

            if (in_array($this->User['entityId'], $doc['followers']))
                $fav = 1;
//            return array('favtag'=> $fav,'data'=> $doc ,'followresarray' => $doc['followers']);

            $vData = $vechicledesc->findOne(array('type' => (int) $doc['type']));

            if ($doc['status'] == 4) {

                $md_arr_offline[] = array("name" => $doc["name"] . ' ' . $doc['lname'], "image" => $doc['image'], "rating" => (float) $doc['rating'], 'vechicleDesc' => $vData['type_name'] . ' ' . $vData['type_desc'],
                    'fav' => $fav, 'email' => $doc['email'], 'lat' => $doc['location']['latitude'], 'lon' => $doc['location']['longitude'], 'dis' => number_format((float) $res['dis'] / $this->distanceMetersByUnits, 2, '.', ''));
            } else if ($doc['status'] == 3)
                $md_arr[] = array("name" => $doc["name"] . ' ' . $doc['lname'], "image" => $doc['image'], "rating" => (float) $doc['rating'], 'tid' => $doc['type'], 'vechicleDesc' => $vData['type_name'] . ' ' . $vData['type_desc'],
                    'fav' => $fav, 'email' => $doc['email'], 'lat' => $doc['location']['latitude'], 'lon' => $doc['location']['longitude'], 'dis' => number_format((float) $res['dis'] / $this->distanceMetersByUnits, 2, '.', ''));
        }

        if (count($md_arr) > 0)
            $errMsgArr = $this->_getStatusMessage(140, 52);
        else
            $errMsgArr = $this->_getStatusMessage(141, 52);

        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'mastersOnline' => $md_arr, 'mastersOffline' => $md_arr_offline);
    }

    /*
     * Method name: removeFavourites
     * Desc: Remove driver from favorites
     * Input: Request data
     * Output:  success if removed, else error message
     */

    protected function removeFavourites($args) {

        if ($args['ent_dri_email'] == '')
            return $this->_getStatusMessage(1, 'Master email');


        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $location = $this->mongo->selectCollection('location');

        $location->update(array('email' => $args['ent_dri_email']), array('$pull' => array('followers' => (int) $this->User['entityId'])));

        return $this->_getStatusMessage(142, 52);
    }

    /*
     * Method name: logout
     * Desc: Edit profile of any users
     * Input: Request data
     * Output:  Complete profile details if available, else error message
     */

    protected function logout($args) {

        if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'User type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_user_type'], '1');

        if (is_array($returned))
            return $returned;

        $logoutQry = "update user_sessions set loggedIn = '2' where oid = '" . $this->User['entityId'] . "' and sid = '" . $this->User['sid'] . "' and user_type = '" . $args['ent_user_type'] . "'";
        $logoutRes = mysql_query($logoutQry, $this->db->conn);

        if (mysql_affected_rows() > 0 || $logoutRes) {

            if ($args['ent_user_type'] == '1') {
                $statusLog = $this->mongo->selectCollection('statusLog');

                $lastLoggedInStatus = array();
                $lastLoggedIn = $statusLog->find(array('master' => (int) $this->User['entityId'], 'status' => 3, 'time' => array('$lte' => time())))->sort(array('time' => -1))->limit(1);
                foreach ($lastLoggedIn as $key) {
                    $lastLoggedInStatus[] = $key;
                }

                if ($lastLoggedInStatus[0]['status'] == 3) {
                    $update['status_log'] = $statusLog->update(array('master' => (int) $this->User['entityId'], 'status' => 3), array('$set' => array('status' => 4, 'EndTime' => time(), 'dist' => ((double) $args['ent_overall_dist'] > 0 ? (double) $args['ent_overall_dist'] : 0))));
                }

                $updateWorkplaceIdQry = "update master set workplace_id = '' where mas_id = '" . $this->User['entityId'] . "'";
                mysql_query($updateWorkplaceIdQry, $this->db->conn);

                $updateWorkplaceQry = "update workplace set Status = 2,last_logout_lat = '" . $args['ent_lat'] . "',last_logout_long = '" . $args['ent_long'] . "' where workplace_id = '" . $this->User['workplaceId'] . "'";
                mysql_query($updateWorkplaceQry, $this->db->conn);

                $location = $this->mongo->selectCollection('location');

                $location->update(array('user' => (int) $this->User['entityId']), array('$set' => array('status' => 4, 'type' => 0, 'carId' => 0, 'chn' => '', 'listner' => '')));
            }
            return $this->_getStatusMessage(29, 55);
        } else {
            return $this->_getStatusMessage(3, $logoutQry);
        }
    }

    /*
     * Method name: support 
     * Desc: Edit profile of any users
     * Input: Request data
     * Output:  Complete profile details if available, else error message
     */

    protected function support($args) {
        if ($args['ent_lan'] == '')
            return $this->_getStatusMessage(1, 'language ');

        $helpText = $this->MongoClass->get('support_txt');
        $HelpedTextArray = array();
        $args['ent_lan'] = 0;
        $HelpedTextArray = $childes = array();

        foreach ($helpText['data'] as $res) {

            if ($res['has_scat']) {

                foreach ($res['sub_cat'] as $subcat) {
                    $childes[] = array(
                        'tag' => $subcat['name'][$args['ent_lan']],
                        'link' => APP_SERVER_HOST . 'helpText/supporttext.php?cat=' . ((string) $res['_id']) . '&lan=' . $args['ent_lan'] . '&scat=' . (string) $subcat['scat_id']
                    );
                }
                $HelpedTextArray [] = array(
                    'tag' => $res['name'][$args['ent_lan']],
                    'childs' => $childes
                );
            } else {
                $HelpedTextArray [] = array(
                    'tag' => $res['name'][$args['ent_lan']],
                    'link' => APP_SERVER_HOST . 'helpText/supporttext.php?cat=' . ((string) $res['_id']) . '&lan=' . $args['ent_lan'],
                    'childs' => array()
                );
            }
        }

        $errMsgArr = $this->_getStatusMessage(33, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'support' => $HelpedTextArray);
    }

    /*
     * 
     * help text  
     */

    protected function helptext($args) {

        if ($args['ent_lan'] == '')
            return $this->_getStatusMessage(1, 'Date time');
        else if ($args['ent_sid'] == '') {
            return $this->_getStatusMessage(1, 'Date time');
        }
//        
        $helpText = $this->MongoClass->get('hlp_txt');

        $HelpedTextArray = array();
        $args['ent_lan'] = 0;
        $HelpedTextArray = $childes = array();

        foreach ($helpText['data'] as $res) {

            if ($res['has_scat']) {

                foreach ($res['sub_cat'] as $subcat) {
                    $childes[] = array(
                        'tag' => $subcat['name'][$args['ent_lan']],
                        'link' => APP_SERVER_HOST . 'helpText/helpText.php?cat=' . ((string) $res['_id']) . '&lan=' . $args['ent_lan'] . '&sid=' . $args['ent_sid'] . '&scat=' . (string) $subcat['scat_id'] . '&bid=' . $args['ent_bookingId']
                    );
                }
                $HelpedTextArray [] = array(
                    'tag' => $res['name'][$args['ent_lan']],
                    'childs' => $childes
                );
            } else {
                $HelpedTextArray [] = array(
                    'tag' => $res['name'][$args['ent_lan']],
                    'link' => APP_SERVER_HOST . 'helpText/helpText.php?cat=' . ((string) $res['_id']) . '&lan=' . $args['ent_lan'] . '&sid=' . $args['ent_sid'] . '&bid=' . $args['ent_bookingId'],
                    'childs' => array()
                );
            }
        }

        $errMsgArr = $this->_getStatusMessage(33, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'HelpedTextArray' => $HelpedTextArray);
    }

    /*     * *********************************
      /*pendingrequest
     */

    protected function getPendingRequests($args) {

        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $dateExploded = explode(' ', $this->curr_date_time);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;

        $selectAppntsQry = "select p.profile_pic,p.first_name,p.phone,p.email,p.phone,a.appt_lat,a.appt_long,a.appointment_dt,a.appointment_id,a.extra_notes,a.address_line1,a.address_line2,a.drop_addr1,a.drop_addr2,a.drop_lat,a.drop_long,a.complete_dt,a.arrive_dt,a.status,a.payment_status,a.amount,a.distance_in_mts,a.appt_type from appointment a, slave p ";
        $selectAppntsQry .= " where p.slave_id = a.slave_id and a.mas_id = '" . $this->User['entityId'] . "' and a.status IN (1,2,6,7,8)  order by a.appointment_dt ASC"; // and a.appointment_dt >= '" . $curr_date_bfr_1hr . "'        a.status NOT in (1,3,4,7) and



        /*
          $selectAppntsQry = "select p.profile_pic,p.first_name,p.phone,p.email,p.phone,a.appt_lat,a.appt_long,a.appointment_dt,a.appointment_id,a.extra_notes,a.address_line1,a.address_line2,a.drop_addr1,a.drop_addr2,a.drop_lat,a.drop_long,a.complete_dt,a.arrive_dt,a.status,a.payment_status,a.amount,a.distance_in_mts,a.appt_type from appointment a, slave p ";
          $selectAppntsQry .= " where p.slave_id = a.slave_id and (" . $pendingString . " (a.mas_id = '" . $this->User['entityId'] . "' and a.status IN (2,6,7,8))) and DATE(a.appointment_dt) = '" . $dateExploded[0] . "' order by a.appointment_dt ASC"; // and a.appointment_dt >= '" . $curr_date_bfr_1hr . "'        a.status NOT in (1,3,4,7) and
         */

        $selectAppntsRes = mysql_query($selectAppntsQry, $this->db->conn);

        if (mysql_num_rows($selectAppntsRes) <= 0)
            return $this->_getStatusMessage(30, $selectAppntsQry);

        $appointments = $daysArr = array();


        while ($appnt = mysql_fetch_assoc($selectAppntsRes)) {

            if ($appnt['profile_pic'] == '')
                $appnt['profile_pic'] = $this->default_profile_pic;

            $durationSec = abs(strtotime($appnt['complete_dt']) - strtotime($appnt['start_dt']));

            $durationMin = round($durationSec / 60);

            if ($appnt['status'] == '1')
                $status = 'Booking requested';
            else if ($appnt['status'] == '2')
                $status = 'Driver accepted.';
//            else if ($appnt['status'] == '3')
//                $status = 'Driver rejected.';
//            else if ($appnt['status'] == '4')
//                $status = 'You cancelled.';
//            else if ($appnt['status'] == '5')
//                $status = 'Driver cancelled.';
//            else
            else if ($appnt['status'] == '6')
                $status = 'Driver is on the way.';
            else if ($appnt['status'] == '7')
                $status = 'Driver arrived.';
            else if ($appnt['status'] == '8')
                $status = 'Booking started.';
            else if ($appnt['status'] == '9')
                $status = 'Booking completed.';
//            else if ($appnt['status'] == '10')
//                $status = 'Booking expired.';
            else
                $status = 'Status unavailable.';

            $appointments[] = array('bid' => $appnt['appointment_id'], 'pPic' => $appnt['profile_pic'], 'email' => $appnt['email'], 'statCode' => $appnt['status'], 'status' => $status,
                'fname' => $appnt['first_name'], 'apntTime' => date('h:i a', strtotime($appnt['appointment_dt'])), 'apntDt' => $appnt['appointment_dt'], 'mobile' => $appnt['phone'],
                'addrLine1' => urldecode($appnt['address_line1']), 'payStatus' => ($appnt['payment_status'] == '') ? 0 : $appnt['payment_status'], 'apptLat' => $appnt['appt_lat'], 'apptLong' => $appnt['appt_long'],
                'dropLine1' => urldecode($appnt['drop_addr1']), 'duration' => $durationMin, 'distance' => round($appnt['distance_in_mts'] / $this->distanceMetersByUnits, 2), 'amount' => $appnt['amount']);
        }

        $errMsgArr = $this->_getStatusMessage(31, 2);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'appointments' => $appointments); //,'test'=>$selectAppntsQry,'test1'=>$appointments);
    }

    /*     * *********************************



      /*
     * Method name: getWorkplaceTypes
     * Desc: Get workplace data
     * Input: nothing
     * Output:  gives workplace details if available else error msg
     */

    protected function getWorkplaceTypes($cityName = NULL, $lat = NULL, $long = NULL) {

        if ($lat != NULL && $long != NULL) {
            $typesData = array();
            $cond = array(
                'geoNear' => 'vehicleTypes',
                'near' => array(
                    (double) $long, (double) $lat
                ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137);

            $resultArr1 = $this->mongo->selectCollection('$cmd')->findOne($cond);

            foreach ($resultArr1['results'] as $res) {
                $doc = $res['obj'];

                $types[] = (int) $doc['type'];
                $typesData[$doc['type']] = array(
                    'type_id' => (int) $doc['type'],
                    'type_name' => $doc['type_name'],
                    'max_size' => (int) $doc['max_size'],
                    'basefare' => (float) $doc['basefare'],
                    'min_fare' => (float) $doc['min_fare'],
                    'price_per_min' => (float) $doc['price_per_min'],
                    'price_per_km' => (float) $doc['price_per_km'],
                    'type_desc' => $doc['type_desc'],
                    'MapIcon' => $doc['type_map_image'],
                    'vehicle_img' => $doc['type_on_image'],
                    'vehicle_img_off' => $doc['type_off_image'],
                    'order' => $doc['vehicle_order']
                );
            }


            $typesDataNew = $order = array();

            $types = array_filter(array_unique($types));


            foreach ($types as $t) {
                $typesDataNew[] = $typesData[$t];
                $order[$t] = $typesData[$t]['order'];
            }

            array_multisort($order, SORT_ASC, $typesDataNew);
            return $typesDataNew;
        }

        if ($cityName == NULL)
            $selectWkTypesQry = "select wt.type_id,wt.type_name,wt.max_size,wt.basefare,wt.min_fare,wt.price_per_min,wt.price_per_km,wt.type_desc from workplace_types wt";
        else
            $selectWkTypesQry = "select wt.type_id,wt.type_name,wt.max_size,wt.basefare,wt.min_fare,wt.price_per_min,wt.price_per_km,wt.type_desc from workplace_types wt,city c where wt.city_id = c.City_Id and c.City_Name = '" . $cityName . "'";

        $selectWkTypesRes = mysql_query($selectWkTypesQry, $this->db->conn);

        $reviewsArr = array();

        while ($review = mysql_fetch_assoc($selectWkTypesRes)) {
            $reviewsArr[] = $review;
        }

        return $reviewsArr;
    }

    protected function getTypes($args) {

        $getCompQry = "select company_id,companyname from company_info where Status = 3";
        $getCompRes = mysql_query($getCompQry, $this->db->conn);

        while ($type = mysql_fetch_assoc($getCompRes)) {
            $compList[] = $type;
        }
        $compList[] = array('company_id' => 0, 'companyname' => 'Other');
        $errMsgArr = $this->_getStatusMessage(21, 52);
        return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'types' => $compList);
    }

    /*
     * Method name: checkCity
     * Desc: Check the cars available in this area or not.
     * Input: Request data
     * Output:  image name if uploaded and status message according to the result
     */

    protected function checkCity($args) {

        if ($args['ent_city'] == '')
            return $this->_getStatusMessage(1, 'City');

        if (count($this->getWorkplaceTypes($args['ent_city'])) <= 0)
            return $this->_getStatusMessage(80, 80);
        else
            return $this->_getStatusMessage(81, 51);
    }

    /*
     * Method name: updateSession
     * Desc: Updates user session
     * Input: Request data
     * Output:  Complete profile details if available, else error message
     */

    protected function updateSession($args) {

        if ($args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 'User type');
        else if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date time');

        //$this->curr_date_time = $args['ent_date_time'];

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_user_type']);
//print_r($returned);

        if (!is_array($returned)) {
            return $this->_getStatusMessage(73, $this->testing);
        } else if ((is_array($returned) && $returned['errNum'] == 6)) {// || 
            $token_obj = new ManageToken($this->db);

            $updateArr = $token_obj->updateSessToken($this->User['entityId'], $args['ent_dev_id'], '0', $args['ent_user_type'], $args['ent_date_time']);

            $errMsgArr = $this->_getStatusMessage(89, 71);
            return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'], 'token' => $updateArr['Token'], 'expiryLocal' => $updateArr['Expiry_local'], 'expiryGMT' => $updateArr['Expiry_GMT'], 'flag' => $updateArr['Flag'], 'status' => ($this->User['status'] == '') ? $returned['status'] : $this->User['status']); //, 't' => $updateArr);
        } else {
            return $this->_getStatusMessage(90, 72);
        }
    }

    /*
     * Method name: truncateDB
     * Desc: Uploads media to the server folder named "pics"
     * Input: Request data
     * Output:  image name if uploaded and status message according to the result
     */

    protected function _truncateDB1($args) {

        $num = 0;

        $qry2 = "truncate table master";
        mysql_query($qry2, $this->db->conn);
        $num += mysql_affected_rows();

        $qry12 = "truncate table slave";
        mysql_query($qry12, $this->db->conn);
        $num += mysql_affected_rows();

        $qry32 = "truncate table coupons";
        mysql_query($qry32, $this->db->conn);
        $num += mysql_affected_rows();

        $qry33 = "truncate table coupon_usage";
        mysql_query($qry33, $this->db->conn);
        $num += mysql_affected_rows();

        $qry21 = "truncate table user_sessions";
        mysql_query($qry21, $this->db->conn);
        $num += mysql_affected_rows();

        $qry22 = "truncate table master_ratings";
        mysql_query($qry22, $this->db->conn);
        $num += mysql_affected_rows();

        $qry23 = "truncate table appointment";
        mysql_query($qry23, $this->db->conn);
        $num += mysql_affected_rows();

        $qry25 = "truncate table images";
        mysql_query($qry25, $this->db->conn);
        $num += mysql_affected_rows();

        $qry24 = "truncate table workplace";
        mysql_query($qry24, $this->db->conn);
        $num += mysql_affected_rows();

        $qry26 = "truncate table appointments_later";
        mysql_query($qry26, $this->db->conn);
        $num += mysql_affected_rows();

        $qry27 = "truncate table company_info";
        mysql_query($qry27, $this->db->conn);
        $num += mysql_affected_rows();

        $qry28 = "truncate table vehicledoc";
        mysql_query($qry28, $this->db->conn);
        $num += mysql_affected_rows();

        $qry29 = "truncate table docdetail";
        mysql_query($qry29, $this->db->conn);
        $num += mysql_affected_rows();

        $qry30 = "truncate table workplace_types";
        mysql_query($qry30, $this->db->conn);
        $num += mysql_affected_rows();


        $location = $this->mongo->selectCollection('location');
        $response = $location->drop();

        $pat = $this->mongo->selectCollection('pat');
        $response1 = $pat->drop();

        $notifications = $this->mongo->selectCollection('notifications');
        $response2 = $notifications->drop();

        $vTypes = $this->mongo->selectCollection('vehicleTypes');
        $response3 = $vTypes->drop();

        $location->ensureIndex(array("location" => "2d"));

        $cursor = $location->find();

        $data = array();

        foreach ($cursor as $doc) {
            $data[] = $doc;
        }

        $cursor1 = $pat->find();

        foreach ($cursor1 as $doc) {
            $data[] = $doc;
        }

        $dir = 'pics/';
        $leave_files = array('aa_default_profile_pic.gif');

        $image = 0;

        foreach (glob("$dir/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir/$file/*") as $file1) {
                    if (!in_array(basename($file1), $leave_files)) {
                        unlink($file);
                        $image++;
                    }
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }
        $dir = 'pics/mdpi/';
        $leave_files = array('aa_default_profile_pic.gif');

        $image = 0;

        foreach (glob("$dir/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir/$file/*") as $file1) {
                    if (!in_array(basename($file1), $leave_files)) {
                        unlink($file);
                        $image++;
                    }
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }
        $dir = 'pics/hdpi/';
        $leave_files = array('aa_default_profile_pic.gif');

        $image = 0;

        foreach (glob("$dir/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir/$file/*") as $file1) {
                    if (!in_array(basename($file1), $leave_files)) {
                        unlink($file);
                        $image++;
                    }
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }
        $dir = 'pics/xhdpi/';
        $leave_files = array('aa_default_profile_pic.gif');

        $image = 0;

        foreach (glob("$dir/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir/$file/*") as $file1) {
                    if (!in_array(basename($file1), $leave_files)) {
                        unlink($file);
                        $image++;
                    }
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }
        $dir = 'pics/xxhdpi/';
        $leave_files = array('aa_default_profile_pic.gif');

        $image = 0;

        foreach (glob("$dir/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir/$file/*") as $file1) {
                    if (!in_array(basename($file1), $leave_files)) {
                        unlink($file);
                        $image++;
                    }
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }


        $dir1 = 'invoice/';

        foreach (glob("$dir1/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir1/$file/*") as $file1) {
                    unlink($file);
                    $image++;
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }

        $dir2 = 'admin/pics/';

        foreach (glob("$dir2/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir2/$file/*") as $file1) {
                    unlink($file);
                    $image++;
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }

        $dir3 = 'admin/upload_images/';

        foreach (glob("$dir3/*") as $file) {
            if (is_dir($file)) {
                foreach (glob("$dir3/$file/*") as $file1) {
                    unlink($file);
                    $image++;
                }
            } else if (!in_array(basename($file), $leave_files)) {
                unlink($file);
                $image++;
            }
        }

        return array('mongodb' => $response . '--' . $response1 . '--' . $response2 . '--' . $response3, 'data' => $data, 'rows' => $num, 'images' => $image);
    }

    protected function testMon($args) {




//        $resultArr = $this->mongo->selectCollection('$cmd')->findOne(array(
//            'geoNear' => 'Campanians',
//            'near' => array(
//                (double) 12.98245955, (double) 77.56375545
//            ), 'spherical' => true, 'maxDistance' => 50000 / 6378137, 'distanceMultiplier' => 6378137,
//            'query' => array('coupon_type' => 'REFERREL', 'status' => 2))
//        );
//        return array('test' => $resultArr);
//        $args['ent_mid'] = '117';
//        $masDet = $this->_getEntityDet($args['ent_mid'], '1', '1');
//        $logoutQry = "update user_sessions set loggedIn = '2' where oid = '117' and user_type = 1";
//        mysql_query($logoutQry, $this->db->conn);
//        $logoutQry = "update user_sessions set loggedIn = '2' where oid = '117' and user_type = 1";
//        mysql_query($logoutQry, $this->db->conn);
//        return array('count' => mysql_affected_rows(), 'qiery' => $logoutQry, 'marray' => $masDet);
//
//        $arr = array(
//            'test' => date('Y-m-d H:i:s', time()));
//        date_default_timezone_set("UTC");
//        return array(
//            'test' => date('Y-m-d H:i:s', time()), 'arr' => $arr);
//
//        $driverWalltBal = $this->getDriverHardOrSoftLimit(70);
//        return $driverWalltBal;
//
//        $beginOfDay = strtotime("midnight", time());
//        $endOfDay = strtotime("tomorrow", $beginOfDay) - 1;
//        $args['ent_dev_id'] = '357422071086024';
//
//        $todayCount = $this->mongo->selectCollection('appointments')->find(array('timpeStamp_appointment_dt' => array('$gt' => $beginOfDay, '$lt' => $endOfDay), "status" => 9, "slave_id.DeviceId" => $args['ent_dev_id']))->count();
//
//        if ($todayCount > MINIMUM_FROUD_BOOKING_ALLOW)
//            return $this->_getStatusMessage(135, 'Date time');
//
//        return array('test' => $todayCount, 'query' => array('timpeStamp_appointment_dt' => array('$gt' => $beginOfDay, '$lt' => $endOfDay), "status" => 9, "slave_id.DeviceId" => $args['ent_dev_id']));
//
//
//        $currentTime = (string) strtotime('today midnight');
//
//        $beginOfDay = strtotime("midnight", time());
//        $endOfDay = strtotime("tomorrow", $beginOfDay) - 1;
//
//        $todayCount = $this->mongo->selectCollection('appointments')->find(array('timpeStamp_appointment_dt' => array('$gt' => $currentTime)))->count();
//        echo $beginOfDay;
//        echo "here";
//        echo $endOfDay;
//        exit();
//        $args['ent_wrk_type'] = 1;
//
//        $getAmountQry = $this->MongoClass->get_one('vehicleTypes', array('type' => (int) $args['ent_wrk_type']));
////        $getAmountQry = $this->MongoClass->aggrigation('appointments', 'BOOKING', array('BOOKING.DriverId' => 15));
//        return array('test' => $getAmountQry);
//     
//        $getBookingData = $this->MongoClass->get_one('appointments', array("_id" => "57ed9076861e53fa778b4585"));
//
//        if ($getBookingData['flag'] == '1') {
//            return $this->_getStatusMessage(62, $args['ent_booking_id']);
//        }
//
//        $masArray =  array();
//        
//        if(is_array($getBookingData['BOOKING'])){
//            foreach($getBookingData['BOOKING'] as $Driver){
//             if($Driver['Status'] == "Request" && $Driver['DriverId'] != $args['ent_mid'])
//                   $masArray[] = (int)$Driver['DriverId'];
//            }
//          }
//$data = 1;
//        if(!empty($masArray))
//         $data = $this->MongoClass->update('location', array("inBooking" => 1),array("user" => array('$in' => $masArray))); 
//        
//        return  $this->_getStatusMessage(21, $data);
//        
//        exit();
//        $getAmountQry = $this->MongoClass->aggrigation('appointments', 'BOOKING', array('BOOKING.DriverId' => 15, "status" => array('$in' => [6, 7, 8, 2, 1])), 'NeedAllData');
//
//        if ($getAmountQry['flag'] == '1')
//            return $this->_getStatusMessage(38, $getAmountQry);
//
//        return array('test' => $getAmountQry,
//            'test2' => !(($getAmountQry['status'] == '1') && ($getAmountQry['BookingRequestServerTime'][0] - (time()) <= 0))
//        );
//
//        $booking_data_livetrack = $this->mongo->selectCollection('booking_data_livetrack');
//        $booking_route = $this->mongo->selectCollection('booking_route');
//        $args = $booking_data_livetrack->findOne(array('_id' => new MongoId('574982805853f2ec18a0fe97')));
//        $booking_route->update(array('bid' => 1090), array('$push' => array('app_route' => $args['args']['ent_app_jsonLatLong'])));
//
//        return array('data' => $args['args']['ent_app_jsonLatLong'], 'test' => $args);
//        exit();



        $location = $this->mongo->selectCollection('location');
        $types = $this->mongo->selectCollection('vehicleTypes');

//        $location->remove(array('type' => array('$in' => array(16, 17, 91, 92))), array('multiple' => 1));
//        $types->remove(array('type' => array('$in' => array(16, 17, 91, 92))), array('multiple' => 1));

        $arr = array();
        $arr[] = time();
        $arr[] = date('Y-m-d H:i:s', time());
//        $response = $location->drop();
//        
        $location->ensureIndex(array("location" => "2d"));

        $cursor1 = $types->find();
        $cursor2 = $location->find();

        foreach ($cursor1 as $doc) {
            $arr[] = $doc;
        }
        foreach ($cursor2 as $doc) {
            $arr[] = $doc;
        }

        return $arr;
    }

    protected function pushSent($args) {
        $notifications = $this->mongo->selectCollection('notifications');

        $cursor2 = $notifications->find();

        foreach ($cursor2 as $doc) {
            $arr[] = $doc;
        }
        $notifications->drop();
        return $arr;
    }

    public function addCustomer() {
//        $customerfname = array(
//            'Aliah', 'Aida', 'Aisha', 'Amal', 'Amina', 'Elham', 'Ehsan', 'Fatema', 'Iman', 'Iesha',
//            'Nabila', 'Sara', 'Soha', 'Souad', 'Nahla',
//            'Abbas', 'Adel', 'Ahmed', 'Ali', 'Amir', 'Azzam', 'Bassam', 'Farouk',
//            'Fayez', 'Hany', 'Husein',
//            'Gamal', 'Khaled', 'Karim',
//            'Khalil', 'Kamal', 'Nasr', 'Omar', 'Amr',
//            'Rashad', 'Ramy', 'Samir', 'Talal', 'Sherif', 'Shawky', 'Tamer', 'Walid', 'Zeyad'
//        );
//        $customerLastname = array(
//            'Abbas', 'Adel', 'Ahmed', 'Ali',
//            'Amir', 'Azzam', 'Bassam', 'Farouk', 'Fayez',
//            'Hany', 'Husein', 'Gamal',
//            'Khaled', 'Karim', 'Khalil', 'Kamal', 'Nasr', 'Omar', 'Amr',
//            'Rashad', 'Ramy', 'Samir', 'Talal', 'Sherif', 'Shawky', 'Tamer', 'Walid', 'Zeyad'
//        );
//
//        $email = array(
//            '@gmail.com',
//            '@yahoo.com',
//            '@hotmail.com',
//            '@live.com'
//        );
//
//        $phonenumber = array(
//            '+2010',
//            '+2011',
//            '+2012'
//        );
//
//
////        
////        
////       date("Y-m-d H:i:s",mt_rand(1481329550,1481761550));
//        for ($var = 1; $var < 500; $var++) {
//            $emailName = $customerfname[array_rand($customerfname)];
//            
//            $insertSlaveQry = "
//                        insert into 
//                        slave(first_name,last_name,email,password,phone,status,
//                        created_dt,last_active_dt,latitude,longitude,city_id) 
//                        values('" . $emailName . "','" . $customerLastname[array_rand($customerLastname)] . "','" . $emailName . rand(333, 666) . $email[array_rand($email)] . "',md5('" . rand(1111, 3333) . "'),'" . $phonenumber[array_rand($phonenumber)] . rand(11111111, 99999999) . "','3',
//                                '" . date("Y-m-d H:i:s", mt_rand(1481329550, 1481761550)) . "','" . date("Y-m-d H:i:s", mt_rand(1481329550, 1481761550)) . "','0.00','0.00','2')";
//
//            mysql_query($insertSlaveQry, $this->db->conn);
//        }
//        return array('test' => $insertSlaveQry);
    }

    protected function testMon1($args) {
        $zone = $this->mongo->selectCollection('zone');
        $getData = $zone->find();
        $count = 0;
        foreach ($getData as $zonedata) {
            foreach ($zonedata['polygonProps']['paths'] as $lat) {
                $data[] = $lat;
                $count += 1;
            }
        }
        return array_values($data);
    }

    /*             ----------------                 HELPER METHODS             ------------------             */

    protected function _createCoupon($couponsColl) {

        $coupOn = $this->_generateRandomString(7);

        $find = $couponsColl->findOne(array('coupon_code' => (string) $coupOn, 'user_type' => 1));

        if (is_array($find) || count($find) > 0) {
            return $this->_createCoupon($couponsColl);
        } else {
            return $coupOn;
        }
    }

    protected function _createCoupon1() {

        $coupOn = $this->_generateRandomString(7);
        $checkPrevCouponQry = "select id from coupons where coupon_code = '" . $coupOn . "' and coupon_type IN (1,3) and user_type = 1";

        $res = mysql_query($checkPrevCouponQry, $this->db->conn);

        if (mysql_num_rows($res) > 0) {
            return $this->_createCoupon();
        } else {
            return $coupOn;
        }
    }

    private function week_start_end_by_date($date, $format = 'Y-m-d') {

//Is $date timestamp or date?
        if (is_numeric($date) AND strlen($date) == 10) {
            $time = $date;
        } else {
            $time = strtotime($date);
        }

        $week['week'] = date('W', $time);
        $week['year'] = date('o', $time);
        $week['year_week'] = date('oW', $time);
        $first_day_of_week_timestamp = strtotime($week['year'] . "W" . str_pad($week['week'], 2, "0", STR_PAD_LEFT));
        $week['first_day_of_week'] = date($format, $first_day_of_week_timestamp);
        $week['first_day_of_week_timestamp'] = $first_day_of_week_timestamp;
        $last_day_of_week_timestamp = strtotime($week['first_day_of_week'] . " +6 days");
        $week['last_day_of_week'] = date($format, $last_day_of_week_timestamp);
        $week['last_day_of_week_timestamp'] = $last_day_of_week_timestamp;

        return $week;
    }

    /*
     * Method name: _getSlvApptStatus
     * Desc: Get user appointment booking status
     * Input: Slave id
     * Output:  status available
     */

    protected function _getSlvApptStatus($slave) {

        $getApptStatusQry = "select booking_status from slave where slave_id = '" . $slave . "'";
        $getApptStatusres = mysql_query($getApptStatusQry, $this->db->conn);
        return mysql_fetch_assoc($getApptStatusres);
    }

    /*
     * Method name: _updateSlvApptStatus
     * Desc: Update user appointment booking status
     * Input: Slave id and status
     * Output:  true if updated else false
     */

    protected function _updateSlvApptStatus($slave, $status) {

        $getApptStatusQry = "update slave set booking_status = '" . $status . "' where slave_id = '" . $slave . "'";
        mysql_query($getApptStatusQry, $this->db->conn);
        if (mysql_affected_rows() > 0)
            return 0;
        else
            return 1;
    }

    protected function getApptStatusforPassenegr($args) {



//              $notifications123 = $this->mongo->selectCollection('JianLpsu');
//              $notifications123->insert($args);
//
//        $args = $notifications123->findOne(array('_id' => new MongoId('58a5c1ee0d5bbd98841f3370')));


        if ($args['ent_date_time'] == '')
            return $this->_getStatusMessage(1, 'Date');

        $this->curr_date_time = urldecode($args['ent_date_time']);
        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_user_type']);

        if (is_array($returned))
            return $returned;



//        $masStatus = $this->MongoClass->get_one("location", array('user' => (int) $this->User['entityId']));
//        $getAmountQry = $this->MongoClass->aggrigation('appointments', array('slave_id.slaveId' => (int) $this->User['entityId'], "status" => array('$in' => [6, 7, 8, 2, 11])));

        if ($args['ent_appnt_dt'] == '') {
            $appointmentsCur = $this->mongo->selectCollection('appointments');
            $getAmountQry = $appointmentsCur->findOne(array("status" => array('$in' => [6, 7, 8]), 'slave_id.slaveId' => (int) $this->User['entityId']));
        } else {
            $appointmentsCur = $this->mongo->selectCollection('appointments');
            $getAmountQry = $appointmentsCur->findOne(array("status" => array('$in' => [9, 3, 4]), 'slave_id.slaveId' => (int) $this->User['entityId'], "appointment_dt" => $args['ent_appnt_dt']));
        }


        if ($getAmountQry['flag'] == '1')
            $data = array();
        else {

            if (!empty($getAmountQry['BOOKING'])) {
                foreach ($getAmountQry['BOOKING'] as $data)
                    if ($getAmountQry['mas_id'] == $data['DriverId']) {
                        $pPic = $data['pPic'];
                        $email = $data['email'];
                        $fname = $data['fName'];
                        $rating = $data['rating'];
                        $mobile = $data['mobile'];
                        $dchn = $data['masChn'];
                    }
            }


            $data = array(
                'sid' => $getAmountQry['slave_id']['slaveId'],
                'pPic' => $pPic,
                'email' => $email,
                'Dname' => $fname,
                'Drating' => $rating,
                'Dmobile' => $mobile,
                'Dchn' => $dchn,
                'Driver_id' => $getAmountQry['mas_id'],
                'bid' => $getAmountQry['_id'],
                'CustomerWalletBalance' => $getAmountQry['CustomerWalletBalance'],
                'adr2' => $getAmountQry['appointment_address'],
                'carImage' => $getAmountQry['VehicleDetails']['carImage'],
                'platreNO' => $getAmountQry['VehicleDetails']['plateNo'],
                'vehicleID' => $getAmountQry['VehicleDetails']['vehicleID'],
                'carmodal' => $getAmountQry['VehicleDetails']['modal'],
                'status' => $getAmountQry['status'],
                'additional_info' => $getAmountQry['additional_info'],
                'pickupDistance' => $getAmountQry['pickupDistance'],
                'pickupAddress' => $getAmountQry['appointment_address'],
                'appointment_dt' => $getAmountQry['appointment_dt'],
                'lt' => $getAmountQry['appointment_location']['latitude'],
                'lg' => $getAmountQry['appointment_location']['longitude'],
                'DropAddress' => $getAmountQry['Drop_address'],
                'DropLat' => $getAmountQry['Drop_location']['latitude'],
                'DropLong' => $getAmountQry['Drop_location']['longitude'],
                'CutomerBal' => $getAmountQry['CustomerWalletBalance'],
                'CustomerName' => $getAmountQry['slave_id']['SlaveName'],
                'CustomerPone' => $getAmountQry['slave_id']['SlavePone'],
                'chn' => $getAmountQry['slave_id']['SlaveChan'],
                'dt' => $getAmountQry['appointment_dt'],
                'sumLastDue' => $getAmountQry['slave_id']['sumLastDue'],
                'PayMentType' => $getAmountQry['PayMentType'],
                'ServerTime' => time(),
                'AcceptenceRadiou' => AcceptenceRadiou,
                'iswallet' => $getAmountQry['wallet'],
                'invoice' => ($getAmountQry['status'] == 9 ? $getAmountQry['invoice'] : array()),
            );
        }

//        if ($args['ent_user_type'] == 2) {
//
//            $queyrDrivervehicleInfo = "select (select count(appointment_id) from appointment where appointment_dt like '%" . date('Y-m-d') . "%' and status = 9 and mas_id = '" . $this->User['entityId'] . "') as tripsToday,"
//                    . "(select IFNULL(sum(mas_earning),0) from appointment where appointment_dt like '%" . date('Y-m-d') . "%' and status = 9 and mas_id = '" . $this->User['entityId'] . "') as earningsToday,"
//                    . "(select IFNULL(amount,0) from appointment where status = 9 and mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as lastTripPrice,"
//                    . "(select IFNULL(tip_amount,0) from appointment where status = 9 and mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as lastTripTip,"
//                    . "(select appointment_dt from appointment where  status = 9 and mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as lastTripTime,"
//                    . "(select type_name  from appointment a,workplace_types wt where  a.type_id = wt.type_id and a.status = 9 and a.mas_id = '" . $this->User['entityId'] . "' order by appointment_id desc limit 1) as carType";
//            $driverRechargeData = mysql_fetch_assoc(mysql_query($queyrDrivervehicleInfo, $this->db->conn));
//        }

        $errMsgArr = $this->_getStatusMessage(21, $queyrDrivervehicleInfo);
//
//        $driverWalltBal = $this->getDriverHardOrSoftLimit($this->User['entityId']);


        if ($args['ent_user_type'] == '2') {
            return array('errNum' => $errMsgArr['errNum'], 'errFlag' => $errMsgArr['errFlag'], 'errMsg' => $errMsgArr['errMsg'],
                'data' => empty($data) ? (object) array() : $data);
        }
    }

    /*
     * Method name: _getDirectionsData
     * Desc: Get google directions data from and to latlongs
     * Input: Keys, form and to latlongs
     * Output:  gives directions details if available else error msg
     */

    protected function _getDirectionsData($from, $to, $key = NULL) {

        if (is_null($key))
            $index = 0;
        else
            $index = $key;

        $keys_all = array('AIzaSyAp_1Skip1qbBmuou068YulGux7SJQdlaw', 'AIzaSyDczTv9Cu9c0vPkLoZtyJuCYPYRzYcx738', 'AIzaSyBZtOXPwL4hmjyq2JqOsd0qrQ-Vv0JtCO4', 'AIzaSyDXdyLHngG-zGUPj7wBYRKefFwcv2wnk7g', 'AIzaSyCibRhPUiPw5kOZd-nxN4fgEODzPgcBAqg', 'AIzaSyB1Twhseoyz5Z6o5OcPZ-3FqFNxne2SnyQ', 'AIzaSyCgHxcZuDslVJNvWxLs8ge4syxLNbokA6c', 'AIzaSyDH-y04IGsMRfn4z9vBis4O4LVLusWYdMk', 'AIzaSyB1Twhseoyz5Z6o5OcPZ-3FqFNxne2SnyQ', 'AIzaSyBQ4dTEeJlU-neooM6aOz4HlqPKZKfyTOc'); //$this->dirKeys;

        $url = 'https://maps.googleapis.com/maps/api/directions/json?origin=' . $from['lat'] . ',' . $from['long'] . '&destination=' . $to['lat'] . ',' . $to['long'] . '&sensor=false&key=' . $keys_all[$index];

        $ch = curl_init();
// Disable SSL verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
// Will return the response, if false it print the response
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// Set the url
        curl_setopt($ch, CURLOPT_URL, $url);
// Execute
        $result = curl_exec($ch);

// echo $result->routes;
// Will dump a beauty json :3
        $arr = json_decode($result, true);

        if (!is_array($arr['routes'][0])) {

            $index++;

            $arr['key_arr'] = array('key' => $keys_all[$index], 'index' => $index, 'all' => $keys_all);

            if (count($keys_all) > $index)
                return $this->_getDirectionsData($from, $to, $index);
            else
                return $arr;
        }

        $arr['key_arr'] = array('key' => $keys_all[$index], 'index' => $index, 'all' => $keys_all);

        return $arr;
    }

    /*
     * Method name: _getMasterReviews
     * Desc: Get master reviews with pagination
     * Input: Master email, page number
     * Output:  gives review details if available else error msg
     */

    protected function _getMasterReviews($args) {

        $pageNum = (int) $args['ent_page'];
        $reviewsArr = array();

        if ($args['ent_page'] == '')
            $pageNum = 1;

        $lowerLimit = ($this->reviewsPageSize * $pageNum) - $this->reviewsPageSize;
        $upperLimit = $this->reviewsPageSize * $pageNum;

        $selectReviewsQry = "select rev.mas_id,rev.slave_id,rev.review_dt,rev.star_rating,rev.review,(select count(*) from master_ratings where mas_id = rev.mas_id) as total_rows,(select first_name from slave where slave_id = rev.slave_id) as slave_name,d.profile_pic from slave_ratings rev,master d where d.email = '" . $args['ent_dri_email'] . "' and d.mas_id = rev.mas_id and rev.status = 1 and rev.review != '' order by rev.star_rating DESC limit $lowerLimit,$upperLimit";
        $selectReviewsRes = mysql_query($selectReviewsQry, $this->db->conn);

        if (mysql_num_rows($selectReviewsRes) <= 0)
            return $this->_getStatusMessage(28, $selectReviewsQry);

        while ($review = mysql_fetch_assoc($selectReviewsRes)) {
            $reviewsArr[] = array('docPic' => $review['profile_pic'], 'rating' => $review['star_rating'], 'review' => $review['review'], 'by' => $review['slave_name'], 'dt' => $review['review_dt'], 'total' => $review['total_rows']);
        }
        return $reviewsArr;
    }

    /*
     * Method name: _validate_token
     * Desc: Authorizes the user with token provided
     * Input: Token
     * Output:  gives entity details if available else error msg
     */

    protected function _validate_token($ent_sess_token, $ent_dev_id, $user_type, $test = NULL) {

        if ($ent_sess_token == '') {
            return $this->_getStatusMessage(1, 'Session');
        } else if ($ent_dev_id == '') {
            return $this->_getStatusMessage(1, 'Device id');
        } else {

            $sessDetArr = $this->_getSessDetails($ent_sess_token, $ent_dev_id, $user_type, $test);
//            print_r($sessDetArr);
            if ($sessDetArr['flag'] == '0') {
                $this->_updateActiveDateTime($sessDetArr['entityId'], $user_type);
                $this->User = $sessDetArr;
            } else if ($sessDetArr['flag'] == '3') {
                return $this->_getStatusMessage($sessDetArr['errNum'], 999);
            } else if ($sessDetArr['flag'] == '1') {

                $updateSessionQry = "update user_sessions set loggedIn = 2 where oid = '" . $sessDetArr['entityId'] . "' and user_type = '" . $user_type . "'";
                mysql_query($updateSessionQry, $this->db->conn);

                if ($user_type == '1') {
                    $updateWorkplaceQry = "update workplace set Status = 2 where workplace_id = '" . $sessDetArr['workplaceId'] . "'";
                    mysql_query($updateWorkplaceQry, $this->db->conn);

                    $location = $this->mongo->selectCollection('location');
                    $location->update(array('user' => (int) $sessDetArr['entityId']), array('$set' => array('type' => 0, 'carId' => 0, 'status' => 4)));
                }
                $this->User = $sessDetArr;
                return $this->_getStatusMessage(6, 102);
            } else {

                return $this->_getStatusMessage(7, $sessDetArr);
            }
        }
    }

    /*
     * Method name: _checkEntityLogin
     * Desc: Checks the unique id with the authentication type
     * Input: Unique id and the auth type
     * Output:  entity details if true, else false
     */

    protected function _checkEntityLogin($id, $auth_type) {

        $checkFBIdQry = "select ent.Entity_Id as entId,edet.Profile_Pic_Url,ent.Create_Dt,ent.Status from entity ent,entity_details edet where ent.Entity_Id = edet.Entity_Id and ent.Unique_Identifier = '" . $id . "' and ent.authType = '" . $auth_type . "'";
        $checkFBIdRes = mysql_query($checkFBIdQry, $this->db->conn);

        if (mysql_num_rows($checkFBIdRes) == 1) {

            $userDet = mysql_fetch_assoc($checkFBIdRes);

            if ($userDet['Profile_Pic_Url'] == "")
                $userDet['Profile_Pic_Url'] = $this->default_profile_pic;

            return array('flag' => '1', 'entityId' => $userDet['entId'], 'profilePic' => $userDet['Profile_Pic_Url'], 'joined' => $userDet['Create_Dt'], 'status' => $userDet['Status'], 'test' => $checkFBIdQry);
        } else {

            return array('flag' => '0', 'test' => $checkFBIdQry);
        }
    }

    /*
     * Method name: _getDeviceTypeName
     * Desc: Returns device name using device type id
     * Input: Device type id
     * Output:  Array with Device type name if true, else false
     */

    protected function _getDeviceTypeName($devTypeId) {

        $getDeviceNameQry = "select name from dev_type where dev_id = '" . $devTypeId . "'";
        $devNameRes = mysql_query($getDeviceNameQry, $this->db->conn);
        if (mysql_num_rows($devNameRes) > 0) {

            $devNameArr = mysql_fetch_assoc($devNameRes);
            return array('flag' => true, 'name' => $devNameArr['name']);
        } else {

            return array('flag' => false);
        }
    }

    /*
     * Method name: _verifyEmail
     * Desc: Checks email for uniqueness
     * Input: Email id to be checked
     * Output:  true if available else false
     */

    protected function _verifyEmail($email, $field, $table) {

        $searchEmailQry = "select $field,status from $table where email = '" . $email . "'";
        $searchEmailRes = mysql_query($searchEmailQry, $this->db->conn);

        if (mysql_num_rows($searchEmailRes) > 0)
            return mysql_fetch_assoc($searchEmailRes);
        else
            return false;
    }

    /*
     * Method name: _getStatusMessage
     * Desc: Get details of an error from db
     * Input: Error number that need details
     * Output:  Returns an array with error details
     */

    protected function _getStatusMessage($errNo, $text) {

        $msg = $this->MongoClass->aggrigation('statusmessage', 'status', array('status.sid' => (int) $errNo));

        if ($msg['flag'] == '1') {
            return array('errFlag' => $msg['sid'], 'errMsg' => $msg['statusMessage'], 'errNum' => 2000);
        }
        if ($errNo == '1')
            $msg['statusMessage'] = $text . " is missing.";

        return array('errNum' => $msg['sid'], 'errFlag' => $msg['statusNumber'], 'errMsg' => $msg['statusMessage'], 'test' => $text);
    }

    /*
     * Method name: _getSessDetails
     * Desc: retrieves a session details
     * Input: Object Id, Token and user_type
     * Output: 1 for Success and 0 for Failure
     */

    protected function _getSessDetails($token, $device_id, $user_type, $test = NULL) {

        if ($user_type == '1')
            $getDetQry = "select  us.oid, us.expiry, us.device, us.type, us.loggedIn, us.sid,doc.first_name,doc.last_name,doc.profile_pic,doc.company_id,doc.email,doc.stripe_id,doc.mobile,doc.workplace_id,doc.status from user_sessions us, master doc where us.oid = doc.mas_id and us.token = '" . $token . "' and us.device = '" . $device_id . "' and us.user_type = '" . $user_type . "'"; // and us.loggedIn = 1
        else if ($user_type == '2')
            $getDetQry = "select  us.oid, us.expiry, us.device, us.type, us.loggedIn, us.sid,pat.city_id,pat.coupon,pat.first_name,pat.last_name,pat.profile_pic,pat.email,pat.stripe_id,pat.phone as mobile,pat.status ,pat.paypal_token from user_sessions us, slave pat where us.oid = pat.slave_id and us.token = '" . $token . "' and us.device = '" . $device_id . "' and us.user_type = '" . $user_type . "'"; // and us.loggedIn = 1
//echo $getDetQry;

        $getDetRes = mysql_query($getDetQry, $this->db->conn);

        if (mysql_num_rows($getDetRes) > 0) {

            $sessDet = mysql_fetch_assoc($getDetRes);
//print_r($sessDet);


            if ($test == NULL)
                if ($sessDet['status'] == '4' || $sessDet['status'] == '5')
                    return array('flag' => '3', 'errNum' => 94);
                else if ($sessDet['status'] == '2' && $user_type == '1')
                    return array('flag' => '3', 'errNum' => 10);



            if ($sessDet['loggedIn'] == '2')
                return array('flag' => '2', 'sectest' => $getDetQry);
            else if ($sessDet['loggedIn'] == '3')
                return array('flag' => '3', 'errNum' => 96);


//            return array('query' => $getDetQry);
            if ($sessDet['profile_pic'] == "")
                $sessDet['profile_pic'] = $this->default_profile_pic;

//            if ($sessDet['expiry'] > $this->curr_date_time)
            return array('flag' => '0', 'status' => $sessDet['status'], 'sid' => $sessDet['sid'], 'coupon' => $sessDet['coupon'], 'company_id' => $sessDet['company_id'], 'entityId' => $sessDet['oid'], 'city_id' => $sessDet['city_id'], 'deviceId' => $sessDet['device'], 'deviceType' => $sessDet['type'], 'firstName' => $sessDet['first_name'], 'last_name' => $sessDet['last_name'], 'pPic' => $sessDet['profile_pic'], 'email' => $sessDet['email'], 'stripe_id' => $sessDet['stripe_id'], 'mobile' => $sessDet['mobile'], 'workplaceId' => $sessDet['workplace_id'], 'paypal' => $sessDet['paypal_token']); // 'currLat' => $sessDet['Current_Lat'], 'currLong' => $sessDet['Current_Long'],
//            else
//                return array('flag' => '1', 'entityId' => $sessDet['oid'], 'workplaceId' => $sessDet['workplace_id']);
        } else {
            return array('flag' => '2', 'datatest' => $token);
        }
    }

    /*
     * Method name: _checkSession
     * Desc: Check a session details
     * Input: Object Id, Token and user_type
     * Output: returns array of updated session details or new session details
     */

    protected function _checkSession($args, $oid, $user_type, $device_name, $workplaceArr = NULL) {

        $deleteAllOtherSessionsQry = "update user_sessions set loggedIn = '3' where user_type = '" . $user_type . "' and loggedIn = '1' and ((oid = '" . $oid . "' and device != '" . $args['ent_dev_id'] . "') or (oid != '" . $oid . "' and device = '" . $args['ent_dev_id'] . "'))";
        mysql_query($deleteAllOtherSessionsQry, $this->db->conn);

        $token_obj = new ManageToken($this->db);

//        if ($args['ent_device_type'] == '1') {
//            $AmazonSns = new AwsPush();
//            $resPush = $AmazonSns->createPlatformEndpoint($args['ent_push_token'], $user_type);
//            if ($resPush === false)
//                $args['ent_push_token'] = 123;
//            else
//                $args['ent_push_token'] = $resPush['EndpointArn'];
//        }

        if ($user_type == '1') {
            $checkUserSessionQry = "select sid, token, expiry,device from user_sessions where oid = '" . $oid . "' and user_type = '" . $user_type . "' and loggedIn = '1'"; // and device != '" . $args['ent_dev_id'] . "'

            $checkUserSessionRes = mysql_query($checkUserSessionQry, $this->db->conn);

            $num = mysql_num_rows($checkUserSessionRes);

            $res = mysql_fetch_assoc($checkUserSessionRes);

            if ($num == 1 && $res['device'] == $args['ent_dev_id']) {
                return $token_obj->updateSessToken($oid, $args['ent_dev_id'], $args['ent_push_token'], $user_type, $this->curr_date_time, $args);
            } else if ($num >= 1 && $res['device'] != $args['ent_dev_id']) {
                $deleteAllOtherSessionsQry = "update user_sessions set loggedIn = '2' where user_type = '" . $user_type . "' and oid = '" . $oid . "'";
                mysql_query($deleteAllOtherSessionsQry, $this->db->conn);

                if (is_array($workplaceArr)) {
                    $updateWorkplaceQry = "update workplace set Status = 2,last_logout_lat = '" . $workplaceArr['lat'] . "',last_logout_long = '" . $workplaceArr['lng'] . "' where workplace_id = '" . $workplaceArr['workplaceId'] . "'";
                    mysql_query($updateWorkplaceQry, $this->db->conn);
                }

                return $token_obj->createSessToken($oid, $device_name, $args['ent_dev_id'], $args['ent_push_token'], $user_type, $this->curr_date_time, $args);
//                return $this->_getStatusMessage(13, 108);
            } else {
                return $token_obj->createSessToken($oid, $device_name, $args['ent_dev_id'], $args['ent_push_token'], $user_type, $this->curr_date_time, $args);
            }
        } else {

            $checkUserSessionQry = "select sid, token, expiry from user_sessions where oid = '" . $oid . "' and device = '" . $args['ent_dev_id'] . "' and user_type = '" . $user_type . "'";
            $checkUserSessionRes = mysql_query($checkUserSessionQry, $this->db->conn);

            if (mysql_num_rows($checkUserSessionRes) == 1)
                return $token_obj->updateSessToken($oid, $args['ent_dev_id'], $args['ent_push_token'], $user_type, $this->curr_date_time, $args);
            else
                return $token_obj->createSessToken($oid, $device_name, $args['ent_dev_id'], $args['ent_push_token'], $user_type, $this->curr_date_time, $args);
        }
    }

    /*
     * Method name: _getEntityDet
     * Desc: Gives facebook id for entity id 
     * Input: Request data, entity_id
     * Output: entity details for success or error array
     */

    protected function _getEntityDet($eid, $userType, $IdFor = null) {

        $qry = "email = '" . $eid . "'";
        if ($IdFor == 1) {
            if ($userType == 1)
                $qry = "mas_id = '" . $eid . "'";
            else
                $qry = "slave_id = '" . $eid . "'";
        }

        if ($userType == '1')
            $getEntityDetQry = "select profile_pic,first_name,last_name,mas_id,workplace_id,stripe_id from master where " . $qry;
        else
            $getEntityDetQry = "select profile_pic,first_name,slave_id,last_name,email,stripe_id from slave where " . $qry;

        $getEntityDetRes = mysql_query($getEntityDetQry, $this->db->conn);

        if (mysql_num_rows($getEntityDetRes) > 0) {

            $det = mysql_fetch_assoc($getEntityDetRes);

            if ($det['profile_pic'] == '')
                $det['profile_pic'] = $this->default_profile_pic;

            return $det;
        } else {
            return false;
        }
    }

    /*
     * Method name: _sendPush
     * Desc: Divides the tokens according to device type and sends a push accordingly
     * Input: Request data, entity_id
     * Output: 1 - success, 0 - failure
     * 
     * 
     * 
     * 
     * 
     */

//    protected  function tesy(){
//        
//          
//            $this->ios_cert_path = IOS_PASSENGER_PEM_PATH;
//            $this->ios_cert_pwd = IOS_PASSENGER_PEM_PASS;
//            $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;
//
//            if (($updateInvoice['invoiceData']['MininumAmtToCollect'] <= 0 && $args['ent_response'] == '9') || $args['ent_response'] == '7' || $args['ent_response'] == '8')
//                $this->_sendPush($this->User['entityId'], array($apptDet['slave_id']['slaveId']), $message, $noteType, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent);
//
//        
//    }

    protected function _sendPush($senderId, $recEntityArr, $message, $notifType, $sname, $datetime, $user_type, $aplContent, $andrContent, $user_device = NULL) {

        $entity_string = '';
        $aplTokenArr = array();
        $andiTokenArr = array();
        $return_arr = array();

//        $notifications = $this->mongo->selectCollection('notificationsPush');

        foreach ($recEntityArr as $entity) {

            $entity_string = $entity . ',';
        }

        $entity_comma = rtrim($entity_string, ',');
//echo '--'.$entity_comma.'--';

        $device_check = '';

        if ($user_device != NULL)
            $device_check = " and device = '" . $user_device . "'";

        $getUserDevTypeQry = "select distinct type,push_token from user_sessions where oid in (" . $entity_comma . ") and loggedIn = '1' and user_type = '" . $user_type . "' and LENGTH(push_token) > 63" . $device_check;
        $getUserDevTypeRes = mysql_query($getUserDevTypeQry, $this->db->conn);
//$notifications->insert(array("query" => $getUserDevTypeQry));
        if (mysql_num_rows($getUserDevTypeRes) > 0) {

            while ($tokenArr = mysql_fetch_assoc($getUserDevTypeRes)) {

                if ($tokenArr['type'] == 1)
                    $aplTokenArr[] = $tokenArr['push_token'];
                else if ($tokenArr['type'] == 2)
                    $andiTokenArr[] = $tokenArr['push_token'];
            }

            $aplTokenArr = array_values(array_filter(array_unique($aplTokenArr)));
            $andiTokenArr = array_values(array_filter(array_unique($andiTokenArr)));
//            print_r($andiTokenArr);
//            if (count($aplTokenArr) > 0)
//                $aplResponse = $this->_sendApplePush($aplTokenArr, $aplContent, $user_type);
//            if (count($andiTokenArr) > 0)
            $notifications = $this->mongo->selectCollection('JianLpsu');
            $notifications->insert(array('query' => $getUserDevTypeQry, 'devicecheck' => $device_check, 'online' => $recEntityArr, 'andiTokenArr' => $andiTokenArr, 'aplTokenArr' => $aplTokenArr, 'andrContent' => $andrContent, 'aplContent' => $aplContent, 'user_type' => $user_type));
            $andiResponse = $this->_sendFcmPush($andiTokenArr, $aplTokenArr, $andrContent, $aplContent, $user_type);
//                $andiResponse = $this->_sendAndroidPush($andiTokenArr, $andrContent, $user_type);

            foreach ($recEntityArr as $entity) {

                $ins_arr = array('notif_type' => (int) $notifType, 'sender' => (int) $senderId, 'reciever' => (int) $entity, 'message' => $message, 'notif_dt' => $datetime, 'apl' => $aplTokenArr, 'andr' => $andiTokenArr, 'aplres' => $aplResponse); //'aplTokens' => $aplTokenArr, 'andiTokens' => $andiTokenArr, 'andiRes' => $andiResponse, 
//                $notifications->insert($ins_arr);

                $newDocID = $ins_arr['_id'];

                $return_arr[] = array($entity => $newDocID);
            }

            $return_arr[] = $aplResponse;
            $return_arr[] = $aplTokenArr;
            $return_arr[] = $recEntityArr;

            if ($aplResponse['errorNo'] != '')
                $errNum = $aplResponse['errorNo'];
            else if ($andiResponse['errorNo'] != '')
                $errNum = $andiResponse['errorNo'];
            else
                $errNum = 46;

            return array('insEnt' => $return_arr, 'errNum' => $errNum, 'andiRes' => $andiResponse);
        } else {
            return array('insEnt' => $return_arr, 'errNum' => 45, 'andiRes' => $andiResponse); //means push not sent
        }
    }

    protected function _sendFcmPush($andiTokenArr, $aplTokenArr, $andrContent, $aplContent, $user_type) {


//    $aplContent['alert'] = 'alert';
        $aplContent['sound'] = 'default';
        $andrContent['sound'] = 'default';
        $applPush = array(
            'to' => '',
            'collapse_key' => 'your_collapse_key',
            'priority' => 'high',
            'notification' => array(
                'title' => '',
                'body' => $aplContent['alert'],
                'sound' => 'default'
            ),
            'data' => $aplContent
        );
        $andPush = array(
            'to' => '',
            'collapse_key' => 'your_collapse_key',
            'priority' => 'high',
            'notification' => $andrContent,
            'data' => $andrContent
        );
        $header = array('Content-Type: application/json', "Authorization: key=");
        foreach ($andiTokenArr as $token) {
            $applPush['to'] = $token;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://fcm.googleapis.com/fcm/send");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($andPush));

            $result = curl_exec($ch);
            curl_close($ch);
            $res_dec = $result;
        }
        foreach ($aplTokenArr as $token) {
            $applPush['to'] = $token; //'d21H5-fZZRc:APA91bHllUZY5cexR9G3CxbaTvtiC_m62wwoVyRQ4i23ow9PeRIgvlfCLwNPrq-IdIBe9gXRG1D89uFSj_oRFj7dDiaGdVA0Y_l7fz3WiTAOPpIsZ89IwDSqVXwMPi6kKAiisOv6mDws';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($applPush));
            $result = curl_exec($ch);
            curl_close($ch);
            $res_dec = $result;
        }

        if ($res_dec['success'] >= 1)
            return array('errorNo' => 44, 't' => $applPush, 'tok' => $aplTokenArr, 'ret' => $res_dec->result, 'res' => $res_dec);
        else
            return array('errorNo' => 46, 't' => $applPush, 'tok' => $aplTokenArr, 'res' => $res_dec);
    }

    protected function _sendApplePush($tokenArr, $aplContent, $user_type) {

        if (IOS_PUSH_TYPE === 'PUSHWOOSH') {

            $pushwoosh = new PushWoosh();

            $title = $aplContent['alert'];

            unset($aplContent['alert']);

            if ($user_type == '1')
                $pushReturn = $pushwoosh->pushDriver($title, $aplContent, $tokenArr);
            else
                $pushReturn = $pushwoosh->pushPassenger($title, $aplContent, $tokenArr);

            if ($pushReturn['info']['http_code'] == 200)
                return array('errorNo' => 44, 't' => $aplContent, 'tok' => $tokenArr, 'ret' => $pushReturn);
            else
                return array('errorNo' => 46);
        } else if (IOS_PUSH_TYPE === 'AMAZON') {
            $amazon = new AwsPush();
            $pushReturn = array();

            foreach ($tokenArr as $endpointArn)
                $pushReturn[] = $amazon->publishJson(array(
                    'MessageStructure' => 'json',
                    'TargetArn' => $endpointArn,
                    'Message' => json_encode(array(
                        ($user_type == '2' ? 'APNS' : 'APNS_SANDBOX') => json_encode(array(
                            'aps' => $aplContent
                        ))
                    )),
                ));

            if ($pushReturn[0]['MessageId'] == '')
                return array('errorNo' => 44, 't' => $aplContent, 'tok' => $tokenArr, 'ret' => $pushReturn);
            else
                return array('errorNo' => 46, 'apleerror' => $pushReturn[0]);
        }else if (IOS_PUSH_TYPE == "APN_PUSH") {

            $host = 'http://localhost:2040/sendpush';
            $argstopass = array("payload" => $aplContent, 'registrationId' => $tokenArr, 'ent_dev_type' => 1, 'user_type' => $user_type);
            $json = json_encode($argstopass);
            $max_exe_time = 250; // time in milliseconds
            $ch = curl_init($host);
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_TIMEOUT_MS, $max_exe_time);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(//<--- Added this code block
                'Content-Type: application/json',
                'Content-Length: ' . strlen($json))
            );

            $result = curl_exec($ch);
            return true;
        }


        $ctx = stream_context_create();
        stream_context_set_option($ctx, 'ssl', 'local_cert', $this->ios_cert_path);
        stream_context_set_option($ctx, 'ssl', 'passphrase', $this->ios_cert_pwd);
        $apns_fp = stream_socket_client($this->ios_cert_server, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);

        if ($apns_fp) {


            $body['aps'] = $aplContent;

            $payload = json_encode($body);

            $msg = '';
            foreach ($tokenArr as $token) {
                $msg .= chr(0) . pack('n', 32) . pack('H*', $token) . pack('n', strlen($payload)) . $payload;
            }

            $result = fwrite($apns_fp, $msg, strlen($msg));

            if (!$result)
                return array('errorNo' => 46);
            else
                return array('errorNo' => 44);
        } else {
            return array('errorNo' => 30, 'error' => $errstr);
        }
    }

    protected function _sendAndroidPush($tokenArr, $andrContent, $user_type) {

        $fields = array(
            'registration_ids' => $tokenArr,
            'data' => $andrContent,
        );

        if ($user_type == '1')
            $apiKey = ANDROID_DRIVER_PUSH_KEY;
        else
            $apiKey = ANDROID_PASSENGER_PUSH_KEY;

        $headers = array(
            'Authorization: key=' . $apiKey,
            'Content-Type: application/json'
        );
// Open connection
        $ch = curl_init();

// Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $this->androidUrl);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

// Execute post
        $result = curl_exec($ch);

        curl_close($ch);
//        echo 'Result from google:' . $result . '---';
        $res_dec = json_decode($result);

        if ($res_dec->success >= 1)
            return array('errorNo' => 44, 'result' => $tokenArr, 'key' => $apiKey);
        else
            return array('errorNo' => 46, 'result' => $tokenArr);
    }

    public function android_push($args) {


        define('API_ACCESS_KEY_ONE', $args['ent_severkey']);
        $registrationIds = array($args['ent_push_token']);
// prep the bundle
        $msg = array
            (
            'message' => $args['ent_msg']
        );
        $fields = array
            (
            'registration_ids' => $registrationIds,
            'data' => $msg
        );

        $headers = array
            (
            'Authorization: key=AIzaSyD_KxaOHjQLsBReYf6EmeWlxOsVevJESJw',
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->androidUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
    }

    /*
     * method name: generateRandomString
     * Desc: Generates a random string according to the length of the characters passed
     * Input: length of the string
     * Output: Random string
     */

    protected function _generateRandomString($length) {

        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';

        $randomString = '';

        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }

        return $randomString;
    }

    protected function _updateActiveDateTime($entId, $user_type) {
//
//        if (////$this->curr_date_time == '')
//            return true;

        if ($user_type == '1')
            $updateQry = "update master set last_active_dt = '" . $this->curr_date_time . "' where mas_id = '" . $entId . "'";
        else if ($user_type == '2')
            $updateQry = "update slave set last_active_dt = '" . $this->curr_date_time . "' where slave_id = '" . $entId . "'";

        mysql_query($updateQry, $this->db->conn);

        if (mysql_affected_rows() > 0)
            return true;
        else
            return false;
    }

    /*
     * Method name: _check_zip
     * Desc: Authorizes the user with token provided
     * Input: Zipcode
     * Output:  gives entity details if available else error msg
     */

    protected function _check_zip($zip_code) {

        $selectZipQry = "select zipcode from zipcodes where zipcode = '" . $zip_code . "'";
        $selectZipRes = mysql_query($selectZipQry, $this->db->conn);
        if (mysql_num_rows($selectZipRes) > 0)
            return true;
        else
            return false;
    }

    protected function updateLanguage($args) {

        if ($args['ent_lang'] == '' || $args['ent_user_type'] == '')
            return $this->_getStatusMessage(1, 15);


        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], $args['ent_user_type']);

        if (is_array($returned))
            return $returned;


        if ($args['ent_user_type'] == '1') {
            $table = "master";
            $id = "mas_id";
        } else {
            $table = "slave";
            $id = "slave_id";
        }
        $getApptStatusQry = "update $table set lang = '" . $args['ent_lang'] . "' where $id = '" . $this->User['entityId'] . "'";
        mysql_query($getApptStatusQry, $this->db->conn);

        if (mysql_affected_rows() <= 0)
            $cardRes = $this->_getStatusMessage(3, $getApptStatusQry);

        return $this->_getStatusMessage(23, 15);
    }

    protected function testUpdateLoc($args) {

        $location = $this->mongo->selectCollection('location');

        if ($args['ent_lat'] != '' && $args['ent_long'] != '')
            $setArr['location'] = array('longitude' => (float) $args['ent_long'], 'latitude' => (float) $args['ent_lat']);

        if ($args['ent_status'] != '')
            $setArr['status'] = (int) $args['ent_status'];

        $data = $location->findOne(array("user" => (int) $args['ent_doc']));

        $setArr['email'] = strtolower($data['email']);

        $newdata1 = array('$set' => $setArr);

        $location->update(array("user" => (int) $args['ent_doc']), $newdata1);

        $cursor2 = $location->find(array("user" => (int) $args['ent_doc']));

        foreach ($cursor2 as $doc) {
            var_dump($doc);
        }
    }

    public function logoutAllDrivers($args) {
        $insertAppointmentQry = "delete from user_sessions where user_type = 1";

        mysql_query($insertAppointmentQry, $this->db->conn);

        $location = $this->mongo->selectCollection('location');

        $masterDet = $location->update(array(), array('$set' => array('status' => 4)), array('multi' => 1));

        return array('message' => $masterDet);
    }

    public function checkAvlblCarsInCompany($args) {
        $getCarsQry = "select w.workplace_id,(select type_name from workplace_types where type_id = w.type_id) as type_name from workplace w where w.company = '" . $args['ent_comp_id'] . "' and w.status IN (2,3)";
        $getCarsRes = mysql_query($getCarsQry, $this->db->conn);

        $cars = array();

        while ($car = mysql_fetch_assoc($getCarsRes)) {
            $cars[] = array('carId' => $car['workplace_id'], 'type' => $car['type_name']);
        }
        return array('available_car_ids' => $cars);
    }

    protected function testPushWoosh($args) {

        $amazon = new AwsPush();
        $pushReturn = array();

        $pushReturn[] = $amazon->publishJson(array(
            'MessageStructure' => 'json',
            'TargetArn' => "arn:aws:sns:ap-south-1:529740336289:endpoint/APNS_SANDBOX/DriverSendBOX/0afca62b-4a75-34da-8564-1d8bbcc438bb",
            'Message' => json_encode(array(
                'default' => "test",
                'badge' => '0',
                'sound' => 'default',
                'content-available' => '1',
                'APNS_SANDBOX' => json_encode(array(
                    'aps' => array("deault" => "", "test" => 1)
                ))
            )),
        ));

        if ($pushReturn[0]['MessageId'] == '')
            return array('errorNo' => 44, 't' => $aplContent, 'tok' => $tokenArr, 'ret' => $pushReturn);
        else
            return array('errorNo' => 46, 'apleerror' => $pushReturn);
    }

    protected function removePax($args) {

        $verifyEmail = $this->_verifyEmail($args['ent_token'], 'slave_id', 'slave'); //_verifyEmail($email,$field,$table);

        if (!is_array($verifyEmail))
            return $this->_getStatusMessage(20, $verifyEmail); //_getStatusMessage($errNo, $test_num);

        $email = $this->_loopUser($args, 'slave_id', 'slave', $verifyEmail['slave_id']);

        $updateUser = "update slave set email = '" . $email . "',phone = '' where email = '" . $args['ent_token'] . "'";
        mysql_query($updateUser, $this->db->conn);
        if (mysql_affected_rows() > 0) {
            $removeSession = "update user_sessions set loggedIn = 2 where oid = '" . $verifyEmail['slave_id'] . "' and user_type = 2 and loggedIn != 2";
            mysql_query($removeSession, $this->db->conn);
            return array('message' => 'user removed');
        } else {
            return array('message' => 'Failed');
        }
    }

    protected function removeDriver($args) {
        $verifyEmail = $this->_verifyEmail($args['ent_token'], 'mas_id', 'master'); //_verifyEmail($email,$field,$table);

        if (!is_array($verifyEmail))
            return $this->_getStatusMessage(20, 2); //_getStatusMessage($errNo, $test_num);

        $email = $this->_loopUser($args, 'slave_id', 'slave', $verifyEmail['slave_id']);

        $location = $this->db->mongo->selectCollection('location');
        $masDet = $location->findOne(array('user' => (int) $verifyEmail['mas_id']));

        $updateUser = "update master set email = '" . $email . "',workplace_id = '',mobile = '' where email = '" . $args['ent_token'] . "'";
        mysql_query($updateUser, $this->db->conn);
        if (mysql_affected_rows() > 0) {

            $location->update(array('user' => (int) $verifyEmail['mas_id']), array('email' => $email, 'status' => 4, 'carId' => 0, 'type' => 0));

            $removeSession = "update user_sessions set loggedIn = 2 where oid = '" . $verifyEmail['mas_id'] . "' and user_type = 1 and loggedIn != 2";
            mysql_query($removeSession, $this->db->conn);

            $removeSession = "update workplace set Status = 2 where workplace_id = '" . $masDet['workplace_id'] . "'";
            mysql_query($removeSession, $this->db->conn);

            return array('message' => 'user removed');
        } else {
            return array('message' => 'Failed');
        }
    }

    protected function _loopUser($args, $id, $table) {

        $rand = rand(111, 999) * rand(111, 999) . '-' . $args['ent_token'];

        $verifyEmail1 = $this->_verifyEmail($rand, $id, $table); //_verifyEmail($email,$field,$table);

        if (!is_array($verifyEmail1)) {
            return $rand;
        } else {
            return $this->_loopUser($args, $id, $table);
        }
    }

    // end of helper function 

    protected function AddMoneyToWallet($args) {

        if ($args['ent_amount'] == '' || $args['ent_amount'] <= 0) {
            return $this->_getStatusMessage(1, 'Amount');
        } else if ($args['ent_date_time'] == '') {
            return $this->_getStatusMessage(1, 'date and time');
        } else if ($args['ent_token'] == '') {
            return $this->_getStatusMessage(1, 'token');
        }

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

        $pgcommission = ($args['ent_amount'] * pgComission);

        $chargeCustomerArr = array('email' => $this->User['email'], "name" => $this->User['firstName'], 'token_name' => $args['ent_token'], 'amount' => ($args['ent_amount'] * 100), 'currency' => 'EGP', 'merchant_reference' => rand(5555555, 9999999), 'description' => "wallet " . $this->User['entityId']);
        $paymentRequest = new PayfortIntegration();
        $customer = $paymentRequest->PaymentReqeust($chargeCustomerArr);


        if ($customer['response_message'] != 'Success') {
            return array('errNum' => 16, 'errFlag' => 1, 'errMsg' => 'CARD PAYMENT HAS DECLINED!', 'code' => $customer, 'req' => $chargeCustomerArr);
        }

        $args['ent_txn_id'] = $customer['fort_id'];

        $getLastDue = $this->getCustomerFroud(array('slave_id' => $this->User['entityId']));
        if ($getLastDue['sumLastDue'] > 0) {
            $returnAmt = $this->settleDriverPayment($args['ent_amount'], array('slave_id' => array('lastDue' => $getLastDue['lastDue'])));
        }

        $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,txn_id,pgcommission) values ('" . $this->User['entityId'] . "',1,'" . round($args['ent_amount'], 2) . "','" . $this->curr_date_time . "','" . ($args['ent_amount'] > 0 ? 1 : 2) . "','" . $args['ent_txn_id'] . "','" . $pgcommission . "')";
        mysql_query($query, $this->db->conn);

        if (mysql_affected_rows() < 0)
            return $this->_getStatusMessage(3, $query);

        $balnace = $this->GetWalletMoney(array('ent_sid' => $this->User['entityId']));

        $errorno = $this->_getStatusMessage(132, 'test');
        return array('errNum' => $errorno['errNum'], 'errFlag' => $errorno['errFlag'], 'errMsg' => $errorno['errMsg'], 'amount' => $balnace['amount']);
    }

    // the service biend used by driver will update money
    protected function UpdateCustomerWallet($args) {
//        $this->MongoClass->insert('InvoiceData', $args);
        if ($args['ent_sid'] == '') {
            return $this->_getStatusMessage(1, 'sid');
        } else if ($args['ent_amount'] == '') {
            return $this->_getStatusMessage(1, 'Amount');
        } else if ($args['ent_balance_type'] == '' || ($args['ent_balance_type'] > '1' && $args['ent_balance_type'] < '0')) { // 0 means credit 1 means debit
            return $this->_getStatusMessage(1, 'Balance type');
        } else if ($args['ent_appnt_id'] == "") {
            return $this->_getStatusMessage(1, 'booking id');
        } else if ($args['ent_actual_amt'] == "") {
            return $this->_getStatusMessage(1, 'ent_actual_amt ');
        }

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '1');

        if (is_array($returned))
            return $returned;


        $getBookingData = $this->MongoClass->get_one('appointments', array("_id" => (int) $args['ent_appnt_id']));
        $returnData = array();
        if ($getBookingData['PayMentType'] == 1) {
            return $this->_getStatusMessage(136, $args['ent_booking_id']);
        }

        if ($getBookingData['flag'] == '1') {
            return $this->_getStatusMessage(62, $args['ent_booking_id']);
        }

        if ($getBookingData['slave_id']['slaveId'] != $args['ent_sid'])
            return $this->_getStatusMessage(131, $args['ent_booking_id']);

        if ($args['ent_amount'] == 0) {
            $balnace = $this->GetWalletMoney(array('ent_sid' => $getBookingData['slave_id']['slaveId']));
            $args['ent_amount'] = ($balnace['amount'] > 0 ? $balnace['amount'] : 0);
        }

        $givenAmt = (double) round(((float) $args['ent_amount'] - $getBookingData['invoice'][0]['amount']), 2);

        if ($args['ent_amount'] == 0) {
//            $getBookingData['invoice'][0]['tripamount'] = abs($getBookingData['CustomerWalletBalance'] - $getBookingData['invoice'][0]['tripamount']);
            $returnData = $this->ModifyiBookingonInvoiceDisrupt($args, $getBookingData);
            if ($returnData['flag'] == 1)
                return $this->_getStatusMessage(3, $returnData);
        }

        if ($givenAmt != 0) {
            if ($givenAmt > 0) {
                if ($getBookingData['slave_id']['sumLastDue'] != 0) {

                    $resp = $this->settleDriverPayment($givenAmt, $getBookingData);
//                    $givenAmt = $resp['amount'];
                }
            }

            $query = "insert into CustomerWallet(slave_id,creditedBy,CreditedAmount,CreditedDate,TransactionType,txn_id) values ('" . $getBookingData['slave_id']['slaveId'] . "',1,'" . round($givenAmt, 2) . "',now(),'" . ($givenAmt > 0 ? 1 : 2) . "','" . InvoiceTwoDegit . '_' . $args['ent_appnt_id'] . "')";
            mysql_query($query, $this->db->conn);

            if (mysql_affected_rows() < 0)
                return $this->_getStatusMessage(3, $query);
        }

        $updateQery = "";
        if (!empty($returnData)) {
            $updateQery = ",app_owner_pl='" . $returnData['appEarning'] . "',pg_commission='" . $returnData['pgCommsion'] . "',app_commission='" . $returnData['appCommission'] . "',mas_earning='" . $returnData['mas_earning'] . "'";
        }
        $query = "update appointment set wallet_settled = 1,status='9',cashCollected='" . $args['ent_amount'] . "' $updateQery where appointment_id = '" . $getBookingData['appointment_id'] . "'";
        mysql_query($query, $this->db->conn);

        if (mysql_affected_rows() < 0)
            return $this->_getStatusMessage(3, $query);

        if ($updateQery == "")
            $updateAppointment = $this->MongoClass->update('appointments', array("status" => 9, 'invoice.0.walletDebitCredit' => $givenAmt, 'invoice.0.cashCollected' => (int) $args['ent_amount']), array("_id" => (int) $args['ent_appnt_id']));
        else
            $updateAppointment = $this->MongoClass->update('appointments', array("status" => 9,
                'invoice.0.cashCollected' => (int) $args['ent_amount'],
                'invoice.0.walletDebitCredit' => $givenAmt,
                'invoice.0.app_commission' => (int) $returnData['appCommission'],
                'invoice.0.profitLoss' => (int) $returnData['appEarning'],
                'invoice.0.mas_earning' => (int) $returnData['mas_earning'],
                'invoice.0.pg_commission' => (int) $returnData['pgCommsion']), array("_id" => (int) $args['ent_appnt_id']));


        $this->androidApiKey = ANDROID_PASSENGER_PUSH_KEY;

        $message = $this->__getAppointmnetStatus('9');
        $aplPushContent = array('alert' => $message, 'nt' => '9', 'sound' => 'default');
        $andrPushContent = array("payload" => $message, 'action' => '9');

        $this->_sendPush($this->User['entityId'], array($getBookingData['slave_id']['slaveId']), $message, 59, $this->User['email'], $this->curr_date_time, '2', $aplPushContent, $andrPushContent);


        if ($updateAppointment['flag'] == 1)
            return $this->_getStatusMessage(3, $updateResponseQry);

        $cond = array('status' => 3, 'apptStatus' => 0);


        $location = $this->mongo->selectCollection('location');
        $location->update(array('user' => (int) $this->User['entityId']), array('$set' => $cond));

        return $this->_getStatusMessage(69, '');
    }

    protected function ModifyiBookingonInvoiceDisrupt($args, $apptDet) {

        $appCommision = $mas = $profitOrLoss = $error = $defautcommision = 0;
        if ($args['ent_amount'] != '0') {

            $RediousPrice = $this->mongo->selectCollection('RediousPrice');
            $appcommisioninpersentage = $RediousPrice->find(array('cityid' => (string) $apptDet['vehicleType']['cityid'], 'from_' => array('$lte' => (int) $args['ent_amount'])))->sort(array('from_' => -1))->limit(1);

            foreach ($appcommisioninpersentage as $key) {
                $Commisiondata[] = $key;
            }

            $defautcommision = PAYMENT_APP_COMMISSION;

            if (!empty($Commisiondata)) {
                $defautcommision = $Commisiondata[0]['price'];
            }

            $appCommision = (float) ($args['ent_amount'] * ($defautcommision / 100));

            $mas = (float) round(($args['ent_amount'] - ($appCommision)));

            $profitOrLoss = (($appCommision - ($apptDet['discountVal'])) > 0 ? ($appCommision - ($apptDet['discountVal'])) : ($appCommision));
        } else {
            $insertCustomerFrouds = "insert into CustomerFrouds (amount,mas_id,slave_id,mongoId,totalamt) values('" . $apptDet['invoice'][0]['mas_earning'] . "','" . $this->User['entityId'] . "','" . $apptDet['slave_id']['slaveId'] . "','" . $args['ent_appnt_id'] . "','" . $apptDet['invoice'][0]['tripamount'] . "')";
            mysql_query($insertCustomerFrouds, $this->db->conn);
            if (mysql_insert_id() < 0) {
                $error = 1;
            }
        }

        return array('appEarning' => $profitOrLoss, 'mas_earning' => $mas, 'appCommission' => $appCommision, 'pgCommsion' => $defautcommision, 'flag' => $error, 'query' => $insertCustomerFrouds);
    }

    public function testsettelamt() {
//        $getLastDue = $this->getCustomerFroud(array('slave_id' => 743));
//        $getLastDue['amount'] = 40;
//        if ($getLastDue['sumLastDue'] > 0) {
//             $resp = $this->settleDriverPayment($getLastDue['slave_id']['sumLastDue'], $getLastDue);
//               
//            $returnAmt = $this->settleDriverPayment($getLastDue['amount'], array('slave_id' => array('lastDue' => $getLastDue['lastDue'])));
//        }
//        $amount = 72;
//        $getBookingData = $this->MongoClass->get_one('appointments', array("_id" => (int) 6882));
//        $res = $this->settleDriverPayment($getBookingData['slave_id']['sumLastDue'], $getBookingData);
//        return array('return' => $res);

        $getLastDue = $this->getCustomerFroud(array('slave_id' => 857));
        if ($getLastDue['sumLastDue'] > 0) {
            $returnAmt = $this->settleDriverPayment(17, array('slave_id' => array('lastDue' => $getLastDue['lastDue'])));
        }
        return array('return' => $returnAmt, 'getlastDue' => $getLastDue);
    }

    protected function getCustomerFroud($args) {
        $QuerhyCustomerFrouds = "select *  from  CustomerFrouds where slave_id = '" . $args['slave_id'] . "' and status = 1 order by id asc";
        $queryRes = mysql_query($QuerhyCustomerFrouds, $this->db->conn);
        $getFroud = array();
        $sum = $overall = 0;
        if (mysql_num_rows($queryRes) > 0) {
            while ($data = mysql_fetch_assoc($queryRes)) {
                $sum += (double) $data['amount'];
                $sumAllEarning += (double) $data['totalamt'];
                $getFroud[] = array('amount' => $data['amount'], 'mas_id' => $data['mas_id'], 'mongoId' => $data['mongoId']);
            }
        }
        return array('lastDue' => $getFroud, 'sumLastDue' => round($sum, 2), 'sumAllEarning' => round($sumAllEarning, 2));
    }

    protected function settleDriverPayment($amount, $getBookingData) {
//        return $getBookingData['slave_id']['lastDue'];
//        $amount = 72;
//        $getBookingData = $this->MongoClass->get_one('appointments', array("_id" => (int) 6882));


        $queryCycleId = "select id from paymentCycle ORDER BY id DESC LIMIT 1";
        $getCycleId = mysql_fetch_assoc(mysql_query($queryCycleId, $this->db->conn));


        $insertQuery = $updateStrStatus = $updateStramount = $mongoId = "";

        foreach ($getBookingData['slave_id']['lastDue'] as $res) {
            $deductAmt = $amount - $res['amount'];

            if ($deductAmt >= 0) {
                $insertQuery .= "('" . currency . ' ' . ($amount > $res['amount'] ? $res['amount'] : $amount) . "  credited for trip " . $res['mongoId'] . "','" . $res['mongoId'] . "','Trip Adjustment',4,'" . $res['mas_id'] . "','" . $this->curr_date_time . "','" . ($amount > $res['amount'] ? $res['amount'] : $amount) . "','" . $getCycleId['id'] . "'),";
                $updateStrStatus .= " when '" . $res['mongoId'] . "' then 2 ";
                $updateStramount .= " when '" . $res['mongoId'] . "' then '" . ($amount > $res['amount'] ? $res['amount'] : $amount) . "' ";
                $mongoId .= $res['mongoId'] . ",";
            } else {
                $insertQuery .= "('" . currency . ' ' . $amount . " amount credited for trip " . $res['mongoId'] . "','" . $res['mongoId'] . "','Trip Adjustment',4,'" . $res['mas_id'] . "','" . $this->curr_date_time . "','" . $amount . "','" . $getCycleId['id'] . "'),";
                $updateStrStatus .= " when '" . $res['mongoId'] . "' then 1 ";
                $updateStramount .= " when '" . $res['mongoId'] . "' then '" . abs($deductAmt) . "' ";
                $mongoId .= $res['mongoId'] . ",";
            }
            $amount = $amount - $res['amount'];
            if ($amount < 0)
                break;
        }

        if ($mongoId != "") {
            $updateQuery = "UPDATE CustomerFrouds set status = case mongoId " . $updateStrStatus . " END, amount = case mongoId " . $updateStramount . " END WHERE mongoId IN(" . rtrim($mongoId, ',') . ")";
            mysql_query($updateQuery, $this->db->conn);
            $inserData = "insert into DriverTxn(comment,addedBy,reason,Bonusstatus,mas_id,txnDate,amount,paymentCycleId) values " . rtrim($insertQuery, ',');
            mysql_query($inserData, $this->db->conn);
        }

        return array('insert' => $inserData, 'update' => $updateQuery, 'amount' => $amount);
    }

    protected function GetWalletMoney($args) {
        if ($args['ent_sid'] == '') {
            return $this->_getStatusMessage(1, 'sid');
        }

//        $condition = "('" . customerRadiusUnit . "' * acos ( cos ( radians(ca.City_Lat) ) * cos( radians( s.latitude ) ) * cos( radians( s.longitude ) - radians(ca.City_Long) ) + sin ( radians(ca.City_Lat) ) * sin( radians( s.latitude ) ) )) < '" . customerRadius . "'";
//        $query = "select ROUND(( ifnull((select sum(CreditedAmount) from CustomerWallet where CityId = ca.City_Id or (slave_id = 0 or slave_id ='" . $args['ent_sid'] . "') and  CreditedDate > s.created_dt ),0)),2)  as walletamt from slave s,city_available ca where " . $condition . " ";
//        $query = "SELECT SUM(CreditedAmount) as walletamt FROM CustomerWallet WHERE slave_id IN (SELECT cw.slave_id FROM CustomerWallet cw,slave s WHERE cw.slave_id = '".$args['ent_sid']."' OR (cw.slave_id = 0 AND cw.CreditedDate > s.created_dt ))";
        $query = "SELECT 
ROUND((
IFNULL((SELECT SUM(CreditedAmount) FROM CustomerWallet WHERE slave_id = '" . $args['ent_sid'] . "' ),0) + 
IFNULL((SELECT SUM(CreditedAmount) FROM CustomerWallet WHERE CityId = ca.City_Id AND CreditedDate > s.ServerTime),0)),2) as walletamt FROM slave s,city_available ca WHERE s.slave_id = '" . $args['ent_sid'] . "'  AND s.city_id = ca.City_Id";

        $queryres = mysql_query($query, $this->db->conn);
        $CreditedAmount = mysql_fetch_assoc($queryres);

        if (mysql_num_rows($queryres) <= 0)
            return $this->_getStatusMessage(3, $query);

        $errorno = $this->_getStatusMessage(21, 'test');
        return array('errNum' => $errorno['errNum'], 'errFlag' => $errorno['errFlag'], 'errMsg' => $errorno['errMsg'], 'amount' => $CreditedAmount['walletamt'], 'query' => $query);
    }

    protected function GetWalletHistory($args) {
        if ($args['ent_page_index'] == '')
            return $this->_getStatusMessage(1, 'Page index');

        $pagelimit = ($args['ent_page_index'] * 10);

        //$this->curr_date_time = urldecode($args['ent_date_time']);

        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], '2');

        if (is_array($returned))
            return $returned;

//        $query = "select distinct cw.CreditedDate,cw.id,cw.TransactionType ,cw.creditedBy ,cw.txn_id,cw.CreditedAmount from CustomerWallet cw, slave s where cw.slave_id ='" . $this->User['entityId'] . "' or (cw.slave_id = 0 AND cw.CityId = s.city_id) order by cw.id DESC LIMIT " . $pagelimit . ", 11";
        $query = "SELECT  cw.CreditedDate,cw.id,cw.TransactionType,cw.creditedBy,cw.txn_id,cw.PaymentMethod,cw.pgcommission,cw.CreditedAmount FROM CustomerWallet cw,slave s WHERE  cw.CreditedAmount != 0 and (s.slave_id = '" . $this->User['entityId'] . "' AND
 cw.slave_id = s.slave_id) OR (cw.slave_id = 0  AND cw.CityId = s.city_id AND (cw.CreditedDate > s.ServerTime AND s.slave_id = '" . $this->User['entityId'] . "')) order by cw.id DESC LIMIT " . $pagelimit . ", 11";
        $queryres = mysql_query($query, $this->db->conn);

        $walletBalance = array();

        $counter = 0;
        if (mysql_num_rows($queryres) > 0) {

            while ($CreditedAmount = mysql_fetch_assoc($queryres)) {
                $counter++;
                $walletBalance[] = array(
                    'date' => $CreditedAmount['CreditedDate'],
                    'creditedBy' => ($CreditedAmount['CreditedBy'] == 1 ? 'YOU' : 'ADMIN'),
                    'amount' => (float) ($CreditedAmount['CreditedAmount'] == 0) ? 0 : $CreditedAmount['CreditedAmount'],
                    'type' => ($CreditedAmount['TransactionType'] == 1 ? 1 : 2),
                    'txn_id' => ($CreditedAmount['TransactionType'] == 1 ? "TXNCR-000-" . $CreditedAmount['id'] : "TXNDB-000-" . $CreditedAmount['id'])
                );
            }
        }
        $errorno = $this->_getStatusMessage(21, 'test');
        return array('errNum' => $errorno['errNum'], 'errFlag' => $errorno['errFlag'], 'errMsg' => $errorno['errMsg'], 'walletHistory' => $walletBalance, 'lastcount' => ($counter > 10 ? 0 : 1 ));
    }

    protected function ZendeskOperation($args) {
        if ($args['ent_action'] == '')
            return $this->_getStatusMessage(1, 'action ');
        else if (($args['ent_action'] == 'GetCommets' || $args['ent_action'] == 'RespondToTicket') && $args['ent_ticketId'] == '') {
            return $this->_getStatusMessage(1, 'ticket Id ');
        } else if ($args['ent_action'] == 'RespondToTicket' && $args['ent_text'] == '') {
            return $this->_getStatusMessage(1, 'text  ');
        }

        $result = array();
        //$this->curr_date_time = urldecode($args['ent_date_time']);
        $returned = $this->_validate_token($args['ent_sess_token'], $args['ent_dev_id'], ($args['ent_user_type'] == '1' ? '1' : '2'));

        if (is_array($returned))
            return $returned;
        switch ($args['ent_action']) {
            case "RespondToTicket":
                $json = json_encode(array("ticket" => array(
                        "comment" => array("body" => $args['ent_text'])
                )));
                $result = $this->curlWrap("/tickets/" . $args['ent_ticketId'] . ".json", $json, "PUT");
                break;

            case "GetTickets":
                $result = $this->curlWrap("/search.json?query=type:ticket%20requester:" . (($args['ent_user_type'] == '1' ? $this->User['entityId'] . '@pqup.co' : $this->User['email'])), array(), "GET");
                break;
            case "GetCommets":
                $result = $this->curlWrap("/tickets/" . $args['ent_ticketId'] . "/comments.json", array(), "GET");
                break;
        }

        if (empty($result) || $result['flag'] == '1') {
            $errorNo = 3;
        } else
            $errorNo = 21;

        $errorno = $this->_getStatusMessage($errorNo, 'test');
        if ($result['data']->error) {
            return array('errNum' => $errorno['errNum'], 'errFlag' => 1,
                'errMsg' => $result['data']->description);
        }

        return array('errNum' => $errorno['errNum'], 'errFlag' => $errorno['errFlag'],
            'errMsg' => $errorno['errMsg'], 'response' => $result['data']);
    }

    function curlWrap($url, $json, $action) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_URL, ZDURL . $url);
        curl_setopt($ch, CURLOPT_USERPWD, ZDUSER . "/token:" . ZDAPIKEY);
        switch ($action) {
            case "POST":
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
                break;
            case "GET":
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
                break;
            case "PUT":
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
                break;
            case "DELETE":
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
                break;
            default:
                break;
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
        curl_setopt($ch, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        if (curl_exec($ch) === false) {
            $return = array('flag' => 1, 'error' => curl_error($ch));
        } else {
            $output = curl_exec($ch);
            curl_close($ch);
            $decoded = json_decode($output);
            $return = array('flag' => 0, 'data' => $decoded);
        }
        return $return;
    }

}

if (!array_key_exists('HTTP_ORIGIN', $_SERVER)) {

    $_SERVER['HTTP_ORIGIN'] = $_SERVER['SERVER_NAME'];
}

try {

//    echo json_encode(array('errMsg' => 'Server is under maintainance, will get back in few minutes..!', 'errNum' => 999, 'errFlag' => 1));
//    return false;

    $API = new MyAPI($_SERVER['REQUEST_URI'], $_REQUEST, $_SERVER['HTTP_ORIGIN']);

    echo $API->processAPI();
} catch (Exception $e) {

    echo json_encode(Array('error' => $e->getMessage()));
}
